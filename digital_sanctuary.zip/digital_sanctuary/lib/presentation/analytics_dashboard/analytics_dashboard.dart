import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../../widgets/custom_tab_bar.dart';
import './widgets/achievement_badge_widget.dart';
import './widgets/empty_state_widget.dart';
import './widgets/focus_pattern_chart_widget.dart';
import './widgets/metric_card_widget.dart';
import './widgets/notification_reduction_chart_widget.dart';
import './widgets/time_period_selector_widget.dart';

/// Analytics Dashboard screen providing visual insights into focus improvement
/// and digital wellness progress through mobile-optimized charts and metrics
class AnalyticsDashboard extends StatefulWidget {
  const AnalyticsDashboard({super.key});

  @override
  State<AnalyticsDashboard> createState() => _AnalyticsDashboardState();
}

class _AnalyticsDashboardState extends State<AnalyticsDashboard>
    with TickerProviderStateMixin {
  int _selectedTimePeriod = 1; // 0: Today, 1: Week, 2: Month
  int _selectedTabIndex = 0; // Analytics tab index
  bool _hasInsufficientData = false;
  late ScrollController _scrollController;

  // Mock data for analytics
  final List<Map<String, dynamic>> _metricsData = [
    {
      "title": "Focus Time Saved",
      "value": "24.5h",
      "subtitle": "This week",
      "isPositiveTrend": true,
      "trendPercentage": 12.3,
    },
    {
      "title": "Notifications Managed",
      "value": "1,247",
      "subtitle": "This week",
      "isPositiveTrend": true,
      "trendPercentage": 8.7,
    },
    {
      "title": "Stress Reduction",
      "value": "87%",
      "subtitle": "Improvement score",
      "isPositiveTrend": true,
      "trendPercentage": 15.2,
    },
    {
      "title": "Peak Focus Time",
      "value": "2-4 PM",
      "subtitle": "Daily average",
      "isPositiveTrend": true,
      "trendPercentage": 5.1,
    },
  ];

  final List<Map<String, dynamic>> _weeklyFocusData = [
    {
      "day": "Monday",
      "date": "Aug 21",
      "hours": 3.5,
      "sessions": 4,
    },
    {
      "day": "Tuesday",
      "date": "Aug 22",
      "hours": 4.2,
      "sessions": 5,
    },
    {
      "day": "Wednesday",
      "date": "Aug 23",
      "hours": 2.8,
      "sessions": 3,
    },
    {
      "day": "Thursday",
      "date": "Aug 24",
      "hours": 5.1,
      "sessions": 6,
    },
    {
      "day": "Friday",
      "date": "Aug 25",
      "hours": 3.9,
      "sessions": 4,
    },
    {
      "day": "Saturday",
      "date": "Aug 26",
      "hours": 2.3,
      "sessions": 2,
    },
    {
      "day": "Sunday",
      "date": "Aug 27",
      "hours": 1.8,
      "sessions": 2,
    },
  ];

  final List<Map<String, dynamic>> _notificationReductionData = [
    {"day": "Monday", "before": 89, "after": 23},
    {"day": "Tuesday", "before": 95, "after": 18},
    {"day": "Wednesday", "before": 78, "after": 31},
    {"day": "Thursday", "before": 102, "after": 15},
    {"day": "Friday", "before": 87, "after": 28},
    {"day": "Saturday", "before": 65, "after": 42},
    {"day": "Sunday", "before": 71, "after": 38},
  ];

  final List<Map<String, dynamic>> _achievementsData = [
    {
      "title": "First Week",
      "description": "Complete your first week of focus sessions",
      "iconName": "calendar_today",
      "isUnlocked": true,
      "progress": 1.0,
    },
    {
      "title": "100 Hours",
      "description": "Accumulate 100 hours of focused time",
      "iconName": "timer",
      "isUnlocked": false,
      "progress": 0.24,
    },
    {
      "title": "Notification Master",
      "description": "Manage 1000 notifications successfully",
      "iconName": "notifications_off",
      "isUnlocked": true,
      "progress": 1.0,
    },
    {
      "title": "Zen Mode",
      "description": "Maintain 7-day focus streak",
      "iconName": "self_improvement",
      "isUnlocked": false,
      "progress": 0.71,
    },
    {
      "title": "Digital Detox",
      "description": "Reduce daily notifications by 80%",
      "iconName": "phone_disabled",
      "isUnlocked": false,
      "progress": 0.87,
    },
    {
      "title": "Productivity Pro",
      "description": "Complete 50 deep work sessions",
      "iconName": "work",
      "isUnlocked": false,
      "progress": 0.42,
    },
  ];

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
    _checkDataAvailability();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _checkDataAvailability() {
    // Simulate checking for insufficient data based on time period
    setState(() {
      _hasInsufficientData =
          _selectedTimePeriod == 0 && DateTime.now().hour < 12;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: CustomAppBar.analyticsDashboard(
        timePeriod: _getTimePeriodText(),
        onTimePeriodTap: _showTimePeriodSelector,
      ),
      body: Column(
        children: [
          // Tab bar for analytics categories
          CustomTabBar.forAnalytics(
            selectedIndex: _selectedTabIndex,
            onTabSelected: (index) {
              setState(() {
                _selectedTabIndex = index;
              });
            },
          ),
          // Time period selector
          TimePeriodSelectorWidget(
            periods: const ['Today', 'Week', 'Month'],
            selectedIndex: _selectedTimePeriod,
            onPeriodChanged: (index) {
              setState(() {
                _selectedTimePeriod = index;
                _checkDataAvailability();
              });
            },
          ),
          // Main content
          Expanded(
            child: _hasInsufficientData
                ? _buildEmptyState()
                : _buildAnalyticsContent(),
          ),
        ],
      ),
      bottomNavigationBar: CustomBottomBar.forAnalytics(
        onTap: (index) {
          _handleBottomNavigation(index);
        },
      ),
    );
  }

  Widget _buildEmptyState() {
    return SingleChildScrollView(
      child: EmptyStateWidget(
        title: 'Not Enough Data Yet',
        subtitle:
            'Start using focus modes and managing notifications to see your analytics',
        iconName: 'analytics',
        tips: const [
          'Enable at least one focus mode session',
          'Use notification management features',
          'Complete your first day of tracking',
          'Check back after 24 hours of usage',
        ],
        actionText: 'Start Focus Session',
        onActionTap: () {
          Navigator.pushNamed(context, '/focus-mode-selection');
        },
      ),
    );
  }

  Widget _buildAnalyticsContent() {
    return RefreshIndicator(
      onRefresh: _refreshAnalytics,
      color: Theme.of(context).colorScheme.primary,
      child: SingleChildScrollView(
        controller: _scrollController,
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_selectedTabIndex == 0) ...[
              // Overview tab content
              _buildMetricsGrid(),
              _buildFocusPatternChart(),
              _buildNotificationReductionChart(),
              _buildAchievementsBadges(),
            ] else if (_selectedTabIndex == 1) ...[
              // Focus Time tab content
              _buildFocusTimeDetails(),
            ] else if (_selectedTabIndex == 2) ...[
              // Notifications tab content
              _buildNotificationDetails(),
            ] else if (_selectedTabIndex == 3) ...[
              // Wellness tab content
              _buildWellnessDetails(),
            ],
            SizedBox(height: 10.h), // Bottom padding
          ],
        ),
      ),
    );
  }

  Widget _buildMetricsGrid() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 2.h),
      child: Wrap(
        alignment: WrapAlignment.spaceEvenly,
        children: _metricsData.map((metric) {
          return MetricCardWidget(
            title: metric["title"] as String,
            value: metric["value"] as String,
            subtitle: metric["subtitle"] as String,
            isPositiveTrend: metric["isPositiveTrend"] as bool,
            trendPercentage: metric["trendPercentage"] as double,
            onTap: () => _showMetricDetails(metric),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildFocusPatternChart() {
    return FocusPatternChartWidget(
      weeklyData: _weeklyFocusData,
      onBarTap: (index) {
        _showDayDetails(index);
      },
    );
  }

  Widget _buildNotificationReductionChart() {
    return NotificationReductionChartWidget(
      reductionData: _notificationReductionData,
      onSpotTap: (spot) {
        _showNotificationDetails(spot);
      },
    );
  }

  Widget _buildAchievementsBadges() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Achievements',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onSurface,
                      fontWeight: FontWeight.w600,
                    ),
              ),
              TextButton(
                onPressed: _showAllAchievements,
                child: Text(
                  'View All',
                  style: Theme.of(context).textTheme.labelMedium?.copyWith(
                        color: Theme.of(context).colorScheme.primary,
                        fontWeight: FontWeight.w500,
                      ),
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          SizedBox(
            height: 22.h,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _achievementsData.length,
              itemBuilder: (context, index) {
                final achievement = _achievementsData[index];
                return AchievementBadgeWidget(
                  title: achievement["title"] as String,
                  description: achievement["description"] as String,
                  iconName: achievement["iconName"] as String,
                  isUnlocked: achievement["isUnlocked"] as bool,
                  progress: achievement["progress"] as double,
                  onTap: () => _showAchievementDetails(achievement),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFocusTimeDetails() {
    return Container(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Focus Time Analysis',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 2.h),
          _buildFocusPatternChart(),
          _buildFocusSessionsList(),
        ],
      ),
    );
  }

  Widget _buildNotificationDetails() {
    return Container(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Notification Management',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 2.h),
          _buildNotificationReductionChart(),
          _buildNotificationBreakdown(),
        ],
      ),
    );
  }

  Widget _buildWellnessDetails() {
    return Container(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Digital Wellness Score',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 2.h),
          _buildWellnessScore(),
          _buildWellnessTips(),
        ],
      ),
    );
  }

  Widget _buildFocusSessionsList() {
    final sessions = [
      {"time": "9:00 AM - 10:30 AM", "duration": "1h 30m", "type": "Deep Work"},
      {"time": "2:00 PM - 3:15 PM", "duration": "1h 15m", "type": "Study"},
      {"time": "7:30 PM - 8:00 PM", "duration": "30m", "type": "Personal"},
    ];

    return Container(
      margin: EdgeInsets.symmetric(vertical: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Recent Focus Sessions',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 2.h),
          ...sessions.map((session) => Container(
                margin: EdgeInsets.only(bottom: 2.h),
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: Theme.of(context)
                        .colorScheme
                        .outline
                        .withValues(alpha: 0.2),
                    width: 0.5,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          session["time"] as String,
                          style: Theme.of(context)
                              .textTheme
                              .titleSmall
                              ?.copyWith(
                                color: Theme.of(context).colorScheme.onSurface,
                                fontWeight: FontWeight.w600,
                              ),
                        ),
                        Text(
                          session["type"] as String,
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurface
                                        .withValues(alpha: 0.6),
                                  ),
                        ),
                      ],
                    ),
                    Text(
                      session["duration"] as String,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            color: Theme.of(context).colorScheme.primary,
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }

  Widget _buildNotificationBreakdown() {
    final breakdown = [
      {"category": "Work", "count": 342, "percentage": 27.4},
      {"category": "Social", "count": 289, "percentage": 23.2},
      {"category": "News", "count": 156, "percentage": 12.5},
      {"category": "Entertainment", "count": 234, "percentage": 18.8},
      {"category": "Other", "count": 226, "percentage": 18.1},
    ];

    return Container(
      margin: EdgeInsets.symmetric(vertical: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Notification Breakdown',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 2.h),
          ...breakdown.map((item) => Container(
                margin: EdgeInsets.only(bottom: 2.h),
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: Theme.of(context)
                        .colorScheme
                        .outline
                        .withValues(alpha: 0.2),
                    width: 0.5,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      item["category"] as String,
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            color: Theme.of(context).colorScheme.onSurface,
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                    Row(
                      children: [
                        Text(
                          '${item["count"]}',
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium
                              ?.copyWith(
                                color: Theme.of(context).colorScheme.primary,
                                fontWeight: FontWeight.w700,
                              ),
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          '(${(item["percentage"] as double).toStringAsFixed(1)}%)',
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurface
                                        .withValues(alpha: 0.6),
                                  ),
                        ),
                      ],
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }

  Widget _buildWellnessScore() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 2.h),
      padding: EdgeInsets.all(6.w),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).colorScheme.shadow.withValues(alpha: 0.08),
            offset: const Offset(0, 2),
            blurRadius: 8,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            'Overall Wellness Score',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 4.h),
          Stack(
            alignment: Alignment.center,
            children: [
              SizedBox(
                width: 40.w,
                height: 20.h,
                child: CircularProgressIndicator(
                  value: 0.87,
                  strokeWidth: 8,
                  backgroundColor: Theme.of(context)
                      .colorScheme
                      .outline
                      .withValues(alpha: 0.2),
                  valueColor:
                      AlwaysStoppedAnimation<Color>(AppTheme.successLight),
                ),
              ),
              Column(
                children: [
                  Text(
                    '87',
                    style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                          color: Theme.of(context).colorScheme.onSurface,
                          fontWeight: FontWeight.w700,
                        ),
                  ),
                  Text(
                    'Excellent',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: AppTheme.successLight,
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: 4.h),
          Text(
            'Your digital wellness has improved significantly this week!',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context)
                      .colorScheme
                      .onSurface
                      .withValues(alpha: 0.7),
                ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildWellnessTips() {
    final tips = [
      "Take regular breaks during focus sessions",
      "Maintain consistent sleep schedule",
      "Limit social media during work hours",
      "Practice mindful notification management",
    ];

    return Container(
      margin: EdgeInsets.symmetric(vertical: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Wellness Tips',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 2.h),
          ...tips.map((tip) => Container(
                margin: EdgeInsets.only(bottom: 2.h),
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: Theme.of(context)
                        .colorScheme
                        .outline
                        .withValues(alpha: 0.2),
                    width: 0.5,
                  ),
                ),
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'lightbulb_outline',
                      color: Theme.of(context).colorScheme.primary,
                      size: 20,
                    ),
                    SizedBox(width: 3.w),
                    Expanded(
                      child: Text(
                        tip,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Theme.of(context).colorScheme.onSurface,
                            ),
                      ),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }

  String _getTimePeriodText() {
    switch (_selectedTimePeriod) {
      case 0:
        return 'Today';
      case 1:
        return 'This Week';
      case 2:
        return 'This Month';
      default:
        return 'This Week';
    }
  }

  void _showTimePeriodSelector() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Select Time Period',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface,
                    fontWeight: FontWeight.w600,
                  ),
            ),
            SizedBox(height: 4.h),
            ...['Today', 'This Week', 'This Month', 'Last 3 Months']
                .asMap()
                .entries
                .map(
                  (entry) => ListTile(
                    title: Text(entry.value),
                    selected: entry.key == _selectedTimePeriod,
                    onTap: () {
                      setState(() {
                        _selectedTimePeriod = entry.key > 2 ? 2 : entry.key;
                        _checkDataAvailability();
                      });
                      Navigator.pop(context);
                    },
                  ),
                ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  void _showMetricDetails(Map<String, dynamic> metric) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(metric["title"] as String),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Current Value: ${metric["value"]}'),
            SizedBox(height: 2.h),
            Text(
                'Trend: ${metric["isPositiveTrend"] ? "↗" : "↘"} ${metric["trendPercentage"]}%'),
            SizedBox(height: 2.h),
            Text('Period: ${metric["subtitle"]}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showDayDetails(int dayIndex) {
    if (dayIndex >= 0 && dayIndex < _weeklyFocusData.length) {
      final dayData = _weeklyFocusData[dayIndex];
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('${dayData["day"]} Details'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Date: ${dayData["date"]}'),
              SizedBox(height: 1.h),
              Text('Focus Time: ${dayData["hours"]}h'),
              SizedBox(height: 1.h),
              Text('Sessions: ${dayData["sessions"]}'),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
          ],
        ),
      );
    }
  }

  void _showNotificationDetails(FlSpot spot) {
    final dayIndex = spot.x.toInt();
    if (dayIndex >= 0 && dayIndex < _notificationReductionData.length) {
      final data = _notificationReductionData[dayIndex];
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('${data["day"]} Notifications'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Before: ${data["before"]} notifications'),
              SizedBox(height: 1.h),
              Text('After: ${data["after"]} notifications'),
              SizedBox(height: 1.h),
              Text(
                  'Reduction: ${((data["before"] - data["after"]) / data["before"] * 100).toStringAsFixed(1)}%'),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
          ],
        ),
      );
    }
  }

  void _showAchievementDetails(Map<String, dynamic> achievement) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(achievement["title"] as String),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(achievement["description"] as String),
            SizedBox(height: 2.h),
            if (achievement["isUnlocked"] as bool)
              const Text('🎉 Achievement Unlocked!')
            else
              Text(
                  'Progress: ${((achievement["progress"] as double) * 100).toInt()}%'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showAllAchievements() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Scaffold(
          appBar: const CustomAppBar(title: 'All Achievements'),
          body: GridView.builder(
            padding: EdgeInsets.all(4.w),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 0.8,
              crossAxisSpacing: 4.w,
              mainAxisSpacing: 2.h,
            ),
            itemCount: _achievementsData.length,
            itemBuilder: (context, index) {
              final achievement = _achievementsData[index];
              return AchievementBadgeWidget(
                title: achievement["title"] as String,
                description: achievement["description"] as String,
                iconName: achievement["iconName"] as String,
                isUnlocked: achievement["isUnlocked"] as bool,
                progress: achievement["progress"] as double,
                onTap: () => _showAchievementDetails(achievement),
              );
            },
          ),
        ),
      ),
    );
  }

  Future<void> _refreshAnalytics() async {
    // Simulate data refresh
    await Future.delayed(const Duration(seconds: 1));
    setState(() {
      _checkDataAvailability();
    });
  }

  void _handleBottomNavigation(int index) {
    final routes = [
      '/notification-hub',
      '/focus-mode-selection',
      '/analytics-dashboard',
      '/settings',
    ];

    if (index != 2) {
      // Don't navigate if already on analytics
      Navigator.pushReplacementNamed(context, routes[index]);
    }
  }
}
