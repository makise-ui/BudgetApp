import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

/// Line chart showing notification reduction over time
class NotificationReductionChartWidget extends StatefulWidget {
  final List<Map<String, dynamic>> reductionData;
  final Function(FlSpot)? onSpotTap;

  const NotificationReductionChartWidget({
    super.key,
    required this.reductionData,
    this.onSpotTap,
  });

  @override
  State<NotificationReductionChartWidget> createState() =>
      _NotificationReductionChartWidgetState();
}

class _NotificationReductionChartWidgetState
    extends State<NotificationReductionChartWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _animation;
  int touchedIndex = -1;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _animation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      width: double.infinity,
      height: 32.h,
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.08),
            offset: const Offset(0, 2),
            blurRadius: 8,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Notification Reduction',
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: colorScheme.onSurface,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 0.5.h),
                  Text(
                    'Before vs After comparison',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: colorScheme.onSurface.withValues(alpha: 0.6),
                    ),
                  ),
                ],
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                decoration: BoxDecoration(
                  color: AppTheme.successLight.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CustomIconWidget(
                      iconName: 'trending_down',
                      color: AppTheme.successLight,
                      size: 16,
                    ),
                    SizedBox(width: 1.w),
                    Text(
                      '${_calculateReduction().toStringAsFixed(0)}% less',
                      style: theme.textTheme.labelMedium?.copyWith(
                        color: AppTheme.successLight,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          _buildLegend(theme, colorScheme),
          SizedBox(height: 2.h),
          Expanded(
            child: AnimatedBuilder(
              animation: _animation,
              builder: (context, child) {
                return LineChart(
                  LineChartData(
                    gridData: FlGridData(
                      show: true,
                      drawVerticalLine: false,
                      horizontalInterval: 20,
                      getDrawingHorizontalLine: (value) {
                        return FlLine(
                          color: colorScheme.outline.withValues(alpha: 0.2),
                          strokeWidth: 0.5,
                        );
                      },
                    ),
                    titlesData: FlTitlesData(
                      show: true,
                      rightTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      topTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 4.h,
                          interval: 1,
                          getTitlesWidget: (double value, TitleMeta meta) {
                            if (value.toInt() >= 0 &&
                                value.toInt() < widget.reductionData.length) {
                              final data = widget.reductionData[value.toInt()];
                              return Padding(
                                padding: EdgeInsets.only(top: 1.h),
                                child: Text(
                                  (data["day"] as String).substring(0, 3),
                                  style: theme.textTheme.bodySmall?.copyWith(
                                    color: colorScheme.onSurface
                                        .withValues(alpha: 0.7),
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              );
                            }
                            return const Text('');
                          },
                        ),
                      ),
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          interval: 20,
                          reservedSize: 10.w,
                          getTitlesWidget: (double value, TitleMeta meta) {
                            return Text(
                              value.toInt().toString(),
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: colorScheme.onSurface
                                    .withValues(alpha: 0.7),
                                fontWeight: FontWeight.w400,
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                    borderData: FlBorderData(show: false),
                    minX: 0,
                    maxX: (widget.reductionData.length - 1).toDouble(),
                    minY: 0,
                    maxY: _getMaxValue() * 1.1,
                    lineTouchData: LineTouchData(
                      touchTooltipData: LineTouchTooltipData(
                        tooltipBgColor: colorScheme.inverseSurface,
                        tooltipRoundedRadius: 8,
                        getTooltipItems: (List<LineBarSpot> touchedBarSpots) {
                          return touchedBarSpots.map((barSpot) {
                            final data =
                                widget.reductionData[barSpot.x.toInt()];
                            final isBeforeLine = barSpot.barIndex == 0;
                            return LineTooltipItem(
                              '${data["day"]}\n${isBeforeLine ? "Before" : "After"}: ${barSpot.y.toInt()}',
                              theme.textTheme.bodySmall!.copyWith(
                                color: colorScheme.onInverseSurface,
                                fontWeight: FontWeight.w500,
                              ),
                            );
                          }).toList();
                        },
                      ),
                      touchCallback: (FlTouchEvent event,
                          LineTouchResponse? touchResponse) {
                        if (touchResponse != null &&
                            touchResponse.lineBarSpots != null) {
                          final spot = touchResponse.lineBarSpots!.first;
                          widget.onSpotTap?.call(FlSpot(spot.x, spot.y));
                        }
                      },
                    ),
                    lineBarsData: [
                      // Before line
                      LineChartBarData(
                        spots: _buildBeforeSpots(),
                        isCurved: true,
                        color: AppTheme.warningLight,
                        barWidth: 3,
                        isStrokeCapRound: true,
                        dotData: FlDotData(
                          show: true,
                          getDotPainter: (spot, percent, barData, index) {
                            return FlDotCirclePainter(
                              radius: 4,
                              color: AppTheme.warningLight,
                              strokeWidth: 2,
                              strokeColor: colorScheme.surface,
                            );
                          },
                        ),
                        belowBarData: BarAreaData(
                          show: true,
                          color: AppTheme.warningLight
                              .withValues(alpha: 0.1 * _animation.value),
                        ),
                      ),
                      // After line
                      LineChartBarData(
                        spots: _buildAfterSpots(),
                        isCurved: true,
                        color: AppTheme.successLight,
                        barWidth: 3,
                        isStrokeCapRound: true,
                        dotData: FlDotData(
                          show: true,
                          getDotPainter: (spot, percent, barData, index) {
                            return FlDotCirclePainter(
                              radius: 4,
                              color: AppTheme.successLight,
                              strokeWidth: 2,
                              strokeColor: colorScheme.surface,
                            );
                          },
                        ),
                        belowBarData: BarAreaData(
                          show: true,
                          color: AppTheme.successLight
                              .withValues(alpha: 0.1 * _animation.value),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLegend(ThemeData theme, ColorScheme colorScheme) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildLegendItem(
          theme,
          colorScheme,
          'Before',
          AppTheme.warningLight,
        ),
        SizedBox(width: 6.w),
        _buildLegendItem(
          theme,
          colorScheme,
          'After',
          AppTheme.successLight,
        ),
      ],
    );
  }

  Widget _buildLegendItem(
    ThemeData theme,
    ColorScheme colorScheme,
    String label,
    Color color,
  ) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 4.w,
          height: 0.5.h,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        SizedBox(width: 2.w),
        Text(
          label,
          style: theme.textTheme.bodySmall?.copyWith(
            color: colorScheme.onSurface.withValues(alpha: 0.7),
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  List<FlSpot> _buildBeforeSpots() {
    return widget.reductionData.asMap().entries.map((entry) {
      final index = entry.key;
      final data = entry.value;
      return FlSpot(
        index.toDouble(),
        (data["before"] as num).toDouble() * _animation.value,
      );
    }).toList();
  }

  List<FlSpot> _buildAfterSpots() {
    return widget.reductionData.asMap().entries.map((entry) {
      final index = entry.key;
      final data = entry.value;
      return FlSpot(
        index.toDouble(),
        (data["after"] as num).toDouble() * _animation.value,
      );
    }).toList();
  }

  double _getMaxValue() {
    if (widget.reductionData.isEmpty) return 100.0;
    double maxBefore = widget.reductionData
        .map((data) => (data["before"] as num).toDouble())
        .reduce((a, b) => a > b ? a : b);
    double maxAfter = widget.reductionData
        .map((data) => (data["after"] as num).toDouble())
        .reduce((a, b) => a > b ? a : b);
    return maxBefore > maxAfter ? maxBefore : maxAfter;
  }

  double _calculateReduction() {
    if (widget.reductionData.isEmpty) return 0.0;
    double avgBefore = widget.reductionData
            .map((data) => (data["before"] as num).toDouble())
            .reduce((a, b) => a + b) /
        widget.reductionData.length;
    double avgAfter = widget.reductionData
            .map((data) => (data["after"] as num).toDouble())
            .reduce((a, b) => a + b) /
        widget.reductionData.length;
    return ((avgBefore - avgAfter) / avgBefore) * 100;
  }
}