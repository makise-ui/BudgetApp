import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import './widgets/active_mode_header.dart';
import './widgets/duration_selector_bottom_sheet.dart';
import './widgets/focus_mode_card.dart';
import './widgets/premium_upgrade_prompt.dart';
import './widgets/trial_code_dialog.dart';

/// Focus Mode Selection screen for quick activation of concentration modes
class FocusModeSelection extends StatefulWidget {
  const FocusModeSelection({super.key});

  @override
  State<FocusModeSelection> createState() => _FocusModeSelectionState();
}

class _FocusModeSelectionState extends State<FocusModeSelection> {
  String? _activeFocusMode;
  Duration? _remainingTime;
  double _progress = 0.0;
  bool _isPremiumUser = false;
  DateTime? _trialExpiryTime;

  // Mock focus modes data
  final List<Map<String, dynamic>> _focusModes = [
    {
      'id': 'deep_work',
      'title': 'Deep Work',
      'description': 'Block all distractions for focused productivity sessions',
      'icon': 'work_outline',
      'reduction': '85',
      'isPremium': false,
      'defaultDuration': const Duration(hours: 2),
      'allowedApps': ['com.android.phone', 'emergency.alerts'],
      'autoTriggers': true,
    },
    {
      'id': 'personal_time',
      'title': 'Personal Time',
      'description': 'Silence work notifications during personal moments',
      'icon': 'person_outline',
      'reduction': '70',
      'isPremium': false,
      'defaultDuration': const Duration(hours: 1),
      'allowedApps': ['com.android.phone', 'com.android.messages'],
      'autoTriggers': false,
    },
    {
      'id': 'driving',
      'title': 'Driving',
      'description': 'Auto-reply and silence notifications while driving',
      'icon': 'directions_car_outlined',
      'reduction': '95',
      'isPremium': false,
      'defaultDuration': const Duration(minutes: 30),
      'allowedApps': ['com.android.phone', 'emergency.alerts'],
      'autoTriggers': true,
    },
    {
      'id': 'sleep',
      'title': 'Sleep',
      'description': 'Complete silence for restful sleep periods',
      'icon': 'bedtime_outlined',
      'reduction': '100',
      'isPremium': true,
      'defaultDuration': const Duration(hours: 8),
      'allowedApps': ['emergency.alerts'],
      'autoTriggers': true,
    },
    {
      'id': 'study',
      'title': 'Study',
      'description': 'Minimize distractions during learning sessions',
      'icon': 'school_outlined',
      'reduction': '80',
      'isPremium': true,
      'defaultDuration': const Duration(hours: 1, minutes: 30),
      'allowedApps': ['com.android.phone', 'com.android.calendar'],
      'autoTriggers': false,
    },
    {
      'id': 'custom',
      'title': 'Custom Mode',
      'description': 'Create your own personalized focus experience',
      'icon': 'tune_outlined',
      'reduction': '90',
      'isPremium': true,
      'defaultDuration': const Duration(hours: 1),
      'allowedApps': [],
      'autoTriggers': false,
    },
  ];

  @override
  void initState() {
    super.initState();
    _checkTrialStatus();
    _simulateActiveFocusMode();
  }

  void _checkTrialStatus() {
    // Check if user has active premium trial
    if (_trialExpiryTime != null &&
        DateTime.now().isBefore(_trialExpiryTime!)) {
      setState(() => _isPremiumUser = true);
    }
  }

  void _simulateActiveFocusMode() {
    // Simulate an active focus mode for demo purposes
    setState(() {
      _activeFocusMode = 'Deep Work';
      _remainingTime = const Duration(hours: 1, minutes: 23);
      _progress = 0.35; // 35% complete
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar.focusModeSelection(),
      body: SafeArea(
        child: Column(
          children: [
            // Active mode header
            ActiveModeHeader(
              activeModeName: _activeFocusMode,
              remainingTime: _remainingTime,
              progress: _progress,
              onEmergencyOverride: _handleEmergencyOverride,
            ),

            // Focus modes grid
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 2.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.h),
                      child: Text(
                        'Choose Your Focus Mode',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                      ),
                    ),

                    SizedBox(height: 1.h),

                    // Focus modes grid
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 0.85,
                        crossAxisSpacing: 1.w,
                        mainAxisSpacing: 1.h,
                      ),
                      itemCount: _focusModes.length,
                      itemBuilder: (context, index) {
                        final mode = _focusModes[index];
                        final isActive = _activeFocusMode == mode['title'];
                        final isPremiumMode = mode['isPremium'] as bool;
                        final canAccess = !isPremiumMode || _isPremiumUser;

                        return FocusModeCard(
                          title: mode['title'],
                          description: mode['description'],
                          iconName: mode['icon'],
                          reductionPercentage: mode['reduction'],
                          isActive: isActive,
                          isPremium: isPremiumMode && !_isPremiumUser,
                          onTap: () => _handleModeSelection(mode, canAccess),
                          onLongPress: canAccess
                              ? () => _showCustomizationSheet(mode)
                              : null,
                        );
                      },
                    ),

                    SizedBox(height: 2.h),

                    // Premium trial info
                    if (!_isPremiumUser) _buildTrialInfo(),

                    SizedBox(height: 10.h), // Bottom padding for navigation
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: CustomBottomBar.forFocusMode(
        onTap: (index) => _handleBottomNavigation(index),
      ),
    );
  }

  Widget _buildTrialInfo() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.warningLight.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.warningLight.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          CustomIconWidget(
            iconName: 'workspace_premium',
            color: AppTheme.warningLight,
            size: 6.w,
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Try Premium Free',
                  style: theme.textTheme.titleSmall?.copyWith(
                    color: AppTheme.warningLight,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  'Use code "KUR1SU" for 24-hour access',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.warningLight.withValues(alpha: 0.8),
                  ),
                ),
              ],
            ),
          ),
          TextButton(
            onPressed: _showTrialCodeDialog,
            style: TextButton.styleFrom(
              foregroundColor: AppTheme.warningLight,
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
            ),
            child: Text(
              'Try Now',
              style: theme.textTheme.labelMedium?.copyWith(
                color: AppTheme.warningLight,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _handleModeSelection(Map<String, dynamic> mode, bool canAccess) {
    if (!canAccess) {
      _showPremiumUpgradePrompt(mode['title']);
      return;
    }

    // Activate the focus mode immediately
    setState(() {
      _activeFocusMode = mode['title'];
      _remainingTime = mode['defaultDuration'];
      _progress = 0.0;
    });

    // Show confirmation with haptic feedback
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${mode['title']} mode activated'),
        backgroundColor: AppTheme.successLight,
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showCustomizationSheet(Map<String, dynamic> mode) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DurationSelectorBottomSheet(
        modeName: mode['title'],
        initialDuration: mode['defaultDuration'],
        allowedApps: List<String>.from(mode['allowedApps']),
        hasAutoTriggers: mode['autoTriggers'],
        onSave: (duration, apps, autoTriggers) {
          _handleCustomModeActivation(mode, duration, apps, autoTriggers);
        },
      ),
    );
  }

  void _handleCustomModeActivation(
    Map<String, dynamic> mode,
    Duration duration,
    List<String> allowedApps,
    bool autoTriggers,
  ) {
    setState(() {
      _activeFocusMode = mode['title'];
      _remainingTime = duration;
      _progress = 0.0;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Custom ${mode['title']} mode activated'),
        backgroundColor: AppTheme.successLight,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showPremiumUpgradePrompt(String featureName) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => PremiumUpgradePrompt(
        featureName: featureName,
        benefits: const [
          'Unlimited custom focus modes',
          'Advanced scheduling and automation',
          'Granular per-app notification controls',
          'Visual theme customization',
          'Home screen widget access',
          'Priority customer support',
        ],
        onUpgrade: () {
          Navigator.pop(context);
          Navigator.pushNamed(context, '/premium-upgrade');
        },
        onTryCode: () {
          Navigator.pop(context);
          _showTrialCodeDialog();
        },
      ),
    );
  }

  void _showTrialCodeDialog() {
    showDialog(
      context: context,
      builder: (context) => TrialCodeDialog(
        onCodeSubmit: (code) {
          if (code.toUpperCase() == 'KUR1SU') {
            setState(() {
              _isPremiumUser = true;
              _trialExpiryTime = DateTime.now().add(const Duration(hours: 24));
            });
          }
        },
      ),
    );
  }

  void _handleEmergencyOverride() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Emergency Override'),
        content: const Text(
          'This will temporarily allow all notifications through. '
          'Focus mode will resume in 10 minutes.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Emergency override activated for 10 minutes'),
                  duration: Duration(seconds: 3),
                ),
              );
            },
            child: const Text('Override'),
          ),
        ],
      ),
    );
  }

  void _handleBottomNavigation(int index) {
    final routes = [
      '/notification-hub',
      '/focus-mode-selection',
      '/analytics-dashboard',
      '/settings',
    ];

    if (index != 1) {
      // Don't navigate if already on focus mode selection
      Navigator.pushReplacementNamed(context, routes[index]);
    }
  }
}
