import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

/// Bottom sheet modal for focus mode customization and duration selection
class DurationSelectorBottomSheet extends StatefulWidget {
  final String modeName;
  final Duration initialDuration;
  final List<String> allowedApps;
  final bool hasAutoTriggers;
  final Function(Duration, List<String>, bool) onSave;

  const DurationSelectorBottomSheet({
    super.key,
    required this.modeName,
    required this.initialDuration,
    required this.allowedApps,
    required this.hasAutoTriggers,
    required this.onSave,
  });

  @override
  State<DurationSelectorBottomSheet> createState() =>
      _DurationSelectorBottomSheetState();
}

class _DurationSelectorBottomSheetState
    extends State<DurationSelectorBottomSheet> {
  late Duration selectedDuration;
  late List<String> selectedApps;
  late bool autoTriggersEnabled;

  final List<Duration> presetDurations = [
    const Duration(minutes: 30),
    const Duration(hours: 1),
    const Duration(hours: 2),
    const Duration(hours: 8), // Until I turn off equivalent
  ];

  @override
  void initState() {
    super.initState();
    selectedDuration = widget.initialDuration;
    selectedApps = List.from(widget.allowedApps);
    autoTriggersEnabled = widget.hasAutoTriggers;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle bar
          Container(
            width: 12.w,
            height: 0.5.h,
            margin: EdgeInsets.symmetric(vertical: 2.h),
            decoration: BoxDecoration(
              color: colorScheme.onSurface.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Header
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Customize ${widget.modeName}',
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: CustomIconWidget(
                    iconName: 'close',
                    color: colorScheme.onSurface,
                    size: 6.w,
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 2.h),

                  // Duration Selection
                  _buildSectionTitle('Duration'),
                  SizedBox(height: 1.h),
                  _buildQuickDurationButtons(),
                  SizedBox(height: 2.h),
                  _buildCustomDurationPicker(),

                  SizedBox(height: 3.h),

                  // App Exceptions
                  _buildSectionTitle('Allow Notifications From'),
                  SizedBox(height: 1.h),
                  _buildAppExceptions(),

                  SizedBox(height: 3.h),

                  // Auto Triggers
                  _buildSectionTitle('Smart Activation'),
                  SizedBox(height: 1.h),
                  _buildAutoTriggers(),

                  SizedBox(height: 4.h),
                ],
              ),
            ),
          ),

          // Save Button
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: colorScheme.surface,
              border: Border(
                top: BorderSide(
                  color: colorScheme.outline.withValues(alpha: 0.2),
                  width: 1,
                ),
              ),
            ),
            child: SafeArea(
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _handleSave,
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 2.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    'Save & Activate',
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: colorScheme.onPrimary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    final theme = Theme.of(context);
    return Text(
      title,
      style: theme.textTheme.titleMedium?.copyWith(
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _buildQuickDurationButtons() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Wrap(
      spacing: 2.w,
      runSpacing: 1.h,
      children: presetDurations.map((duration) {
        final isSelected = selectedDuration == duration;
        final label = duration.inHours >= 8
            ? 'Until I turn off'
            : duration.inHours > 0
                ? '${duration.inHours}hr'
                : '${duration.inMinutes}min';

        return GestureDetector(
          onTap: () => setState(() => selectedDuration = duration),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
            decoration: BoxDecoration(
              color: isSelected ? colorScheme.primary : colorScheme.surface,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: isSelected
                    ? colorScheme.primary
                    : colorScheme.outline.withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: Text(
              label,
              style: theme.textTheme.labelLarge?.copyWith(
                color:
                    isSelected ? colorScheme.onPrimary : colorScheme.onSurface,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildCustomDurationPicker() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Custom Duration',
            style: theme.textTheme.labelLarge?.copyWith(
              fontWeight: FontWeight.w500,
            ),
          ),
          SizedBox(height: 1.h),
          Theme.of(context).platform == TargetPlatform.iOS
              ? _buildIOSTimePicker()
              : _buildAndroidTimePicker(),
        ],
      ),
    );
  }

  Widget _buildIOSTimePicker() {
    return SizedBox(
      height: 20.h,
      child: CupertinoTimerPicker(
        mode: CupertinoTimerPickerMode.hm,
        initialTimerDuration: selectedDuration,
        onTimerDurationChanged: (duration) {
          setState(() => selectedDuration = duration);
        },
      ),
    );
  }

  Widget _buildAndroidTimePicker() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return GestureDetector(
      onTap: () async {
        final TimeOfDay? picked = await showTimePicker(
          context: context,
          initialTime: TimeOfDay(
            hour: selectedDuration.inHours,
            minute: selectedDuration.inMinutes.remainder(60),
          ),
        );
        if (picked != null) {
          setState(() {
            selectedDuration = Duration(
              hours: picked.hour,
              minutes: picked.minute,
            );
          });
        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
        decoration: BoxDecoration(
          color: colorScheme.primary.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: colorScheme.primary.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              '${selectedDuration.inHours}h ${selectedDuration.inMinutes.remainder(60)}m',
              style: theme.textTheme.titleMedium?.copyWith(
                color: colorScheme.primary,
                fontWeight: FontWeight.w600,
              ),
            ),
            CustomIconWidget(
              iconName: 'schedule',
              color: colorScheme.primary,
              size: 5.w,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppExceptions() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final List<Map<String, dynamic>> availableApps = [
      {'name': 'Phone', 'icon': 'phone', 'package': 'com.android.phone'},
      {
        'name': 'Messages',
        'icon': 'message',
        'package': 'com.android.messages'
      },
      {
        'name': 'Calendar',
        'icon': 'calendar_today',
        'package': 'com.android.calendar'
      },
      {
        'name': 'Emergency Alerts',
        'icon': 'warning',
        'package': 'emergency.alerts'
      },
    ];

    return Column(
      children: availableApps.map((app) {
        final isSelected = selectedApps.contains(app['package']);

        return Container(
          margin: EdgeInsets.only(bottom: 1.h),
          child: ListTile(
            leading: Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: colorScheme.primary.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: CustomIconWidget(
                iconName: app['icon'],
                color: colorScheme.primary,
                size: 5.w,
              ),
            ),
            title: Text(
              app['name'],
              style: theme.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w500,
              ),
            ),
            trailing: Switch(
              value: isSelected,
              onChanged: (value) {
                setState(() {
                  if (value) {
                    selectedApps.add(app['package']);
                  } else {
                    selectedApps.remove(app['package']);
                  }
                });
              },
            ),
            contentPadding: EdgeInsets.symmetric(horizontal: 2.w),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            tileColor: colorScheme.surface,
          ),
        );
      }).toList(),
    );
  }

  Widget _buildAutoTriggers() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Calendar Integration',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      'Auto-activate based on calendar events',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: colorScheme.onSurface.withValues(alpha: 0.7),
                      ),
                    ),
                  ],
                ),
              ),
              Switch(
                value: autoTriggersEnabled,
                onChanged: (value) {
                  setState(() => autoTriggersEnabled = value);
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _handleSave() {
    widget.onSave(selectedDuration, selectedApps, autoTriggersEnabled);
    Navigator.pop(context);
  }
}
