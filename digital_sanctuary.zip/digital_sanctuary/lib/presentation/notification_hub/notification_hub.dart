import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../../widgets/custom_icon_widget.dart';
import '../../widgets/custom_tab_bar.dart';
import './widgets/category_section_widget.dart';
import './widgets/empty_state_widget.dart';
import './widgets/focus_mode_indicator_widget.dart';
import './widgets/quick_actions_widget.dart';
import 'widgets/category_section_widget.dart';
import 'widgets/empty_state_widget.dart';
import 'widgets/focus_mode_indicator_widget.dart';
import 'widgets/notification_card_widget.dart';
import 'widgets/quick_actions_widget.dart';

class NotificationHub extends StatefulWidget {
  const NotificationHub({super.key});

  @override
  State<NotificationHub> createState() => _NotificationHubState();
}

class _NotificationHubState extends State<NotificationHub>
    with TickerProviderStateMixin {
  late TabController _tabController;
  bool _isFocusModeActive = false;
  String? _activeFocusMode;
  bool _isSelectionMode = false;
  Set<String> _selectedNotifications = {};
  bool _isRefreshing = false;
  int _selectedTabIndex = 0;
  int _notificationCount = 0;
  bool _isPremiumUser = false;

  // Mock notification data
  final List<Map<String, dynamic>> _allNotifications = [
    {
      "id": "1",
      "appName": "Slack",
      "appIcon":
          "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=100&h=100&fit=crop",
      "title": "New message from Sarah",
      "content": "Hey, can you review the project proposal by EOD? Thanks!",
      "timestamp": "2 min ago",
      "category": "Important",
      "priority": "important",
      "isRead": false,
    },
    {
      "id": "2",
      "appName": "WhatsApp",
      "appIcon":
          "https://images.unsplash.com/photo-1611262588024-d12430b98920?w=100&h=100&fit=crop",
      "title": "Mom",
      "content": "Don't forget about dinner tonight at 7 PM. Love you!",
      "timestamp": "5 min ago",
      "category": "Social",
      "priority": "normal",
      "isRead": false,
    },
    {
      "id": "3",
      "appName": "Gmail",
      "appIcon":
          "https://images.unsplash.com/photo-1596526131083-e8c633c948d2?w=100&h=100&fit=crop",
      "title": "Meeting Reminder",
      "content": "Your meeting with the design team starts in 15 minutes.",
      "timestamp": "10 min ago",
      "category": "Urgent",
      "priority": "urgent",
      "isRead": false,
    },
    {
      "id": "4",
      "appName": "Instagram",
      "appIcon":
          "https://images.unsplash.com/photo-1611262588019-db6cc2032da3?w=100&h=100&fit=crop",
      "title": "New follower",
      "content": "john_doe started following you. Check out their profile!",
      "timestamp": "1 hour ago",
      "category": "Social",
      "priority": "normal",
      "isRead": true,
    },
    {
      "id": "5",
      "appName": "Amazon",
      "appIcon":
          "https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?w=100&h=100&fit=crop",
      "title": "Flash Sale Alert",
      "content": "Up to 70% off on electronics. Limited time offer!",
      "timestamp": "2 hours ago",
      "category": "Promotional",
      "priority": "normal",
      "isRead": false,
    },
    {
      "id": "6",
      "appName": "Calendar",
      "appIcon":
          "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=100&h=100&fit=crop",
      "title": "Upcoming Event",
      "content": "Team standup meeting in 30 minutes in Conference Room A",
      "timestamp": "15 min ago",
      "category": "Important",
      "priority": "important",
      "isRead": false,
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
    _tabController.addListener(_handleTabChange);
    _updateNotificationCount();
    _checkPremiumStatus();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _handleTabChange() {
    if (_tabController.indexIsChanging) {
      setState(() {
        _selectedTabIndex = _tabController.index;
      });
    }
  }

  void _updateNotificationCount() {
    setState(() {
      _notificationCount = _getFilteredNotifications().length;
    });
  }

  void _checkPremiumStatus() {
    // Mock premium check - in real app, check user subscription
    setState(() {
      _isPremiumUser = false; // Default to free tier
    });
  }

  List<Map<String, dynamic>> _getFilteredNotifications() {
    switch (_selectedTabIndex) {
      case 0: // All
        return _allNotifications;
      case 1: // Work
        return _allNotifications
            .where((n) =>
                (n["category"] as String).toLowerCase() == "important" ||
                (n["category"] as String).toLowerCase() == "urgent")
            .toList();
      case 2: // Social
        return _allNotifications
            .where((n) => (n["category"] as String).toLowerCase() == "social")
            .toList();
      case 3: // News
        return []; // No news notifications in mock data
      case 4: // Other
        return _allNotifications
            .where(
                (n) => (n["category"] as String).toLowerCase() == "promotional")
            .toList();
      default:
        return _allNotifications;
    }
  }

  Map<String, List<Map<String, dynamic>>> _getCategorizedNotifications() {
    final filtered = _getFilteredNotifications();
    final Map<String, List<Map<String, dynamic>>> categorized = {
      'Urgent': [],
      'Important': [],
      'Social': [],
      'Promotional': [],
    };

    for (final notification in filtered) {
      final category = (notification["category"] as String?) ?? "Other";
      if (categorized.containsKey(category)) {
        categorized[category]!.add(notification);
      }
    }

    // Remove empty categories
    categorized.removeWhere((key, value) => value.isEmpty);
    return categorized;
  }

  void _handleDigestLater(Map<String, dynamic> notification) {
    setState(() {
      // In real app, move to digest queue
      _allNotifications.removeWhere((n) => n["id"] == notification["id"]);
      _updateNotificationCount();
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Notification added to digest queue'),
        action: SnackBarAction(
          label: 'Undo',
          onPressed: () {
            setState(() {
              _allNotifications.add(notification);
              _updateNotificationCount();
            });
          },
        ),
      ),
    );
  }

  void _handleSilenceApp(Map<String, dynamic> notification) {
    final appName = notification["appName"] as String;
    setState(() {
      // In real app, add app to silence list
      _allNotifications.removeWhere((n) => n["appName"] == appName);
      _updateNotificationCount();
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$appName notifications silenced'),
        action: SnackBarAction(
          label: 'Undo',
          onPressed: () {
            // In real app, restore notifications from this app
          },
        ),
      ),
    );
  }

  void _handleNotificationTap(Map<String, dynamic> notification) {
    if (_isSelectionMode) {
      _toggleNotificationSelection(notification["id"] as String);
    } else {
      // Mark as read and open app
      setState(() {
        notification["isRead"] = true;
      });
    }
  }

  void _handleNotificationLongPress(Map<String, dynamic> notification) {
    if (!_isSelectionMode) {
      setState(() {
        _isSelectionMode = true;
        _selectedNotifications.add(notification["id"] as String);
      });
    }
  }

  void _toggleNotificationSelection(String id) {
    setState(() {
      if (_selectedNotifications.contains(id)) {
        _selectedNotifications.remove(id);
        if (_selectedNotifications.isEmpty) {
          _isSelectionMode = false;
        }
      } else {
        _selectedNotifications.add(id);
      }
    });
  }

  void _handleSelectAll() {
    setState(() {
      _selectedNotifications =
          _getFilteredNotifications().map((n) => n["id"] as String).toSet();
    });
  }

  void _handleDeselectAll() {
    setState(() {
      _selectedNotifications.clear();
      _isSelectionMode = false;
    });
  }

  void _handleDigestSelected() {
    final selectedIds = Set<String>.from(_selectedNotifications);
    setState(() {
      _allNotifications.removeWhere((n) => selectedIds.contains(n["id"]));
      _selectedNotifications.clear();
      _isSelectionMode = false;
      _updateNotificationCount();
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${selectedIds.length} notifications added to digest'),
      ),
    );
  }

  void _handleSilenceSelected() {
    final selectedNotifications = _allNotifications
        .where((n) => _selectedNotifications.contains(n["id"]))
        .toList();

    final appNames =
        selectedNotifications.map((n) => n["appName"] as String).toSet();

    setState(() {
      _allNotifications.removeWhere((n) => appNames.contains(n["appName"]));
      _selectedNotifications.clear();
      _isSelectionMode = false;
      _updateNotificationCount();
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${appNames.length} apps silenced'),
      ),
    );
  }

  Future<void> _handleRefresh() async {
    setState(() {
      _isRefreshing = true;
    });

    // Simulate network refresh
    await Future.delayed(const Duration(seconds: 1));

    setState(() {
      _isRefreshing = false;
      // In real app, fetch latest notifications
    });
  }

  void _toggleFocusMode() {
    if (_isFocusModeActive) {
      setState(() {
        _isFocusModeActive = false;
        _activeFocusMode = null;
      });
    } else {
      Navigator.pushNamed(context, '/focus-mode-selection');
    }
  }

  void _showUpgradePrompt() {
    if (!_isPremiumUser && _notificationCount >= 50) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text(
            'Daily Limit Reached',
            style: GoogleFonts.inter(
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          content: Text(
            'You\'ve reached your daily limit of 50 notifications. Upgrade to Premium for unlimited notifications and advanced features.',
            style: GoogleFonts.inter(
              fontSize: 14,
              fontWeight: FontWeight.w400,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Later'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/premium-upgrade');
              },
              child: Text('Upgrade'),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final categorizedNotifications = _getCategorizedNotifications();
    final hasNotifications = _getFilteredNotifications().isNotEmpty;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: CustomAppBar.notificationHub(
        onFocusModeToggle: _toggleFocusMode,
        isFocusModeActive: _isFocusModeActive,
      ),
      body: Column(
        children: [
          // Header with time and focus mode indicator
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            decoration: BoxDecoration(
              color: colorScheme.surface,
              border: Border(
                bottom: BorderSide(
                  color: colorScheme.outline.withValues(alpha: 0.2),
                  width: 0.5,
                ),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Good ${_getTimeOfDay()}',
                        style: GoogleFonts.inter(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w400,
                          color: colorScheme.onSurface.withValues(alpha: 0.7),
                        ),
                      ),
                      Text(
                        _getCurrentTime(),
                        style: GoogleFonts.inter(
                          fontSize: 20.sp,
                          fontWeight: FontWeight.w600,
                          color: colorScheme.onSurface,
                        ),
                      ),
                    ],
                  ),
                ),
                FocusModeIndicatorWidget(
                  isFocusModeActive: _isFocusModeActive,
                  activeFocusMode: _activeFocusMode,
                  onTap: _toggleFocusMode,
                ),
              ],
            ),
          ),

          // Category tabs
          CustomTabBar.forNotificationCategories(
            selectedIndex: _selectedTabIndex,
            onTabSelected: (index) {
              setState(() {
                _selectedTabIndex = index;
                _tabController.animateTo(index);
                _updateNotificationCount();
              });
            },
            categoryBadges: {
              'all': _allNotifications.length,
              'work': _allNotifications
                  .where((n) =>
                      (n["category"] as String).toLowerCase() == "important" ||
                      (n["category"] as String).toLowerCase() == "urgent")
                  .length,
              'social': _allNotifications
                  .where((n) =>
                      (n["category"] as String).toLowerCase() == "social")
                  .length,
              'news': 0,
              'other': _allNotifications
                  .where((n) =>
                      (n["category"] as String).toLowerCase() == "promotional")
                  .length,
            },
          ),

          // Main content
          Expanded(
            child: hasNotifications
                ? RefreshIndicator(
                    onRefresh: _handleRefresh,
                    child: ListView(
                      padding: EdgeInsets.symmetric(vertical: 2.h),
                      children: [
                        // Show upgrade prompt for free users
                        if (!_isPremiumUser && _notificationCount >= 40)
                          Container(
                            margin: EdgeInsets.symmetric(
                                horizontal: 4.w, vertical: 1.h),
                            padding: EdgeInsets.all(4.w),
                            decoration: BoxDecoration(
                              color: colorScheme.primary.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color:
                                    colorScheme.primary.withValues(alpha: 0.3),
                                width: 1,
                              ),
                            ),
                            child: Row(
                              children: [
                                CustomIconWidget(
                                  iconName: 'star',
                                  color: colorScheme.primary,
                                  size: 20,
                                ),
                                SizedBox(width: 3.w),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Approaching Daily Limit',
                                        style: GoogleFonts.inter(
                                          fontSize: 14.sp,
                                          fontWeight: FontWeight.w600,
                                          color: colorScheme.onSurface,
                                        ),
                                      ),
                                      Text(
                                        'Upgrade to Premium for unlimited notifications',
                                        style: GoogleFonts.inter(
                                          fontSize: 12.sp,
                                          fontWeight: FontWeight.w400,
                                          color: colorScheme.onSurface
                                              .withValues(alpha: 0.7),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                TextButton(
                                  onPressed: () => Navigator.pushNamed(
                                      context, '/premium-upgrade'),
                                  child: Text('Upgrade'),
                                ),
                              ],
                            ),
                          ),

                        // Notification categories
                        ...categorizedNotifications.entries.map((entry) {
                          return CategorySectionWidget(
                            categoryTitle: entry.key,
                            notifications: entry.value,
                            onDigestLater: _handleDigestLater,
                            onSilenceApp: _handleSilenceApp,
                            onNotificationTap: _handleNotificationTap,
                            onNotificationLongPress:
                                _handleNotificationLongPress,
                          );
                        }).toList(),
                      ],
                    ),
                  )
                : EmptyStateWidget(
                    onRefresh: _handleRefresh,
                  ),
          ),

          // Quick actions bar
          QuickActionsWidget(
            isSelectionMode: _isSelectionMode,
            selectedCount: _selectedNotifications.length,
            onSelectAll: _handleSelectAll,
            onDeselectAll: _handleDeselectAll,
            onDigestSelected: _handleDigestSelected,
            onSilenceSelected: _handleSilenceSelected,
          ),
        ],
      ),
      bottomNavigationBar: CustomBottomBar.forNotificationHub(
        onTap: (index) {
          final routes = [
            '/notification-hub',
            '/focus-mode-selection',
            '/analytics-dashboard',
            '/settings',
          ];
          if (index != 0) {
            Navigator.pushReplacementNamed(context, routes[index]);
          }
        },
      ),
      floatingActionButton: !hasNotifications
          ? null
          : FloatingActionButton(
              onPressed: _toggleFocusMode,
              tooltip: 'Quick Focus',
              child: CustomIconWidget(
                iconName:
                    _isFocusModeActive ? 'do_not_disturb_on' : 'psychology',
                color: colorScheme.onPrimary,
                size: 24,
              ),
            ),
    );
  }

  String _getTimeOfDay() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Morning';
    if (hour < 17) return 'Afternoon';
    return 'Evening';
  }

  String _getCurrentTime() {
    final now = DateTime.now();
    final hour =
        now.hour > 12 ? now.hour - 12 : (now.hour == 0 ? 12 : now.hour);
    final minute = now.minute.toString().padLeft(2, '0');
    final period = now.hour >= 12 ? 'PM' : 'AM';
    return '$hour:$minute $period';
  }
}