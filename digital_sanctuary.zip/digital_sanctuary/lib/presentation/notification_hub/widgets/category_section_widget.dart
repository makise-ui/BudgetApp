import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';
import './notification_card_widget.dart';
import 'notification_card_widget.dart';

/// Category section widget for grouping notifications
class CategorySectionWidget extends StatelessWidget {
  final String categoryTitle;
  final List<Map<String, dynamic>> notifications;
  final Function(Map<String, dynamic>) onDigestLater;
  final Function(Map<String, dynamic>) onSilenceApp;
  final Function(Map<String, dynamic>) onNotificationTap;
  final Function(Map<String, dynamic>) onNotificationLongPress;
  final bool isExpanded;
  final VoidCallback? onToggleExpanded;

  const CategorySectionWidget({
    super.key,
    required this.categoryTitle,
    required this.notifications,
    required this.onDigestLater,
    required this.onSilenceApp,
    required this.onNotificationTap,
    required this.onNotificationLongPress,
    this.isExpanded = true,
    this.onToggleExpanded,
  });

  Color _getCategoryColor(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    switch (categoryTitle.toLowerCase()) {
      case 'urgent':
        return colorScheme.error;
      case 'important':
        return colorScheme.primary;
      case 'social':
        return colorScheme.secondary;
      case 'promotional':
        return colorScheme.tertiary;
      default:
        return colorScheme.onSurface.withValues(alpha: 0.6);
    }
  }

  IconData _getCategoryIcon() {
    switch (categoryTitle.toLowerCase()) {
      case 'urgent':
        return Icons.priority_high_rounded;
      case 'important':
        return Icons.star_rounded;
      case 'social':
        return Icons.people_rounded;
      case 'promotional':
        return Icons.local_offer_rounded;
      default:
        return Icons.notifications_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final categoryColor = _getCategoryColor(context);

    if (notifications.isEmpty) {
      return const SizedBox.shrink();
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Category Header
          GestureDetector(
            onTap: onToggleExpanded,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: categoryColor.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: CustomIconWidget(
                      iconName: _getCategoryIcon().codePoint.toString(),
                      color: categoryColor,
                      size: 16,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      categoryTitle,
                      style: GoogleFonts.inter(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: colorScheme.onSurface,
                      ),
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: categoryColor.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      notifications.length.toString(),
                      style: GoogleFonts.inter(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: categoryColor,
                      ),
                    ),
                  ),
                  if (onToggleExpanded != null) ...[
                    const SizedBox(width: 8),
                    AnimatedRotation(
                      turns: isExpanded ? 0.5 : 0,
                      duration: const Duration(milliseconds: 200),
                      child: CustomIconWidget(
                        iconName: 'keyboard_arrow_down',
                        color: colorScheme.onSurface.withValues(alpha: 0.6),
                        size: 20,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),

          // Notifications List
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeInOut,
            height: isExpanded ? null : 0,
            child: isExpanded
                ? Column(
                    children: notifications.map((notification) {
                      return NotificationCardWidget(
                        notification: notification,
                        onDigestLater: () => onDigestLater(notification),
                        onSilenceApp: () => onSilenceApp(notification),
                        onTap: () => onNotificationTap(notification),
                        onLongPress: () =>
                            onNotificationLongPress(notification),
                      );
                    }).toList(),
                  )
                : const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}