import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

/// Focus mode indicator widget showing current active mode
class FocusModeIndicatorWidget extends StatelessWidget {
  final bool isFocusModeActive;
  final String? activeFocusMode;
  final VoidCallback? onTap;

  const FocusModeIndicatorWidget({
    super.key,
    required this.isFocusModeActive,
    this.activeFocusMode,
    this.onTap,
  });

  IconData _getFocusModeIcon() {
    if (!isFocusModeActive) return Icons.do_not_disturb_off_rounded;

    switch (activeFocusMode?.toLowerCase()) {
      case 'deep work':
        return Icons.work_outline_rounded;
      case 'personal time':
        return Icons.person_outline_rounded;
      case 'driving':
        return Icons.directions_car_outlined;
      case 'sleep':
        return Icons.bedtime_outlined;
      case 'study':
        return Icons.school_outlined;
      default:
        return Icons.do_not_disturb_on_rounded;
    }
  }

  Color _getFocusModeColor(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    if (!isFocusModeActive) return colorScheme.onSurface.withValues(alpha: 0.6);

    switch (activeFocusMode?.toLowerCase()) {
      case 'deep work':
        return colorScheme.primary;
      case 'personal time':
        return colorScheme.secondary;
      case 'driving':
        return colorScheme.error;
      case 'sleep':
        return const Color(0xFF6B46C1); // Purple
      case 'study':
        return const Color(0xFF059669); // Green
      default:
        return colorScheme.primary;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final focusColor = _getFocusModeColor(context);

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isFocusModeActive
              ? focusColor.withValues(alpha: 0.1)
              : colorScheme.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isFocusModeActive
                ? focusColor.withValues(alpha: 0.3)
                : colorScheme.outline.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedScale(
              scale: isFocusModeActive ? 1.1 : 1.0,
              duration: const Duration(milliseconds: 200),
              child: CustomIconWidget(
                iconName: _getFocusModeIcon().codePoint.toString(),
                color: focusColor,
                size: 16,
              ),
            ),
            const SizedBox(width: 6),
            AnimatedDefaultTextStyle(
              duration: const Duration(milliseconds: 200),
              style: GoogleFonts.inter(
                fontSize: 12,
                fontWeight:
                    isFocusModeActive ? FontWeight.w600 : FontWeight.w500,
                color: focusColor,
              ),
              child: Text(
                isFocusModeActive
                    ? (activeFocusMode ?? 'Focus Mode')
                    : 'Focus Mode',
              ),
            ),
            if (isFocusModeActive) ...[
              const SizedBox(width: 4),
              Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(
                  color: focusColor,
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}