import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

/// Quick actions widget for batch operations and shortcuts
class QuickActionsWidget extends StatelessWidget {
  final bool isSelectionMode;
  final int selectedCount;
  final VoidCallback? onSelectAll;
  final VoidCallback? onDeselectAll;
  final VoidCallback? onDigestSelected;
  final VoidCallback? onSilenceSelected;
  final VoidCallback? onMarkAllRead;
  final VoidCallback? onClearAll;

  const QuickActionsWidget({
    super.key,
    required this.isSelectionMode,
    required this.selectedCount,
    this.onSelectAll,
    this.onDeselectAll,
    this.onDigestSelected,
    this.onSilenceSelected,
    this.onMarkAllRead,
    this.onClearAll,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      height: isSelectionMode ? 60 : 0,
      child: isSelectionMode
          ? Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: colorScheme.surface,
                border: Border(
                  top: BorderSide(
                    color: colorScheme.outline.withValues(alpha: 0.2),
                    width: 0.5,
                  ),
                ),
              ),
              child: Row(
                children: [
                  // Selection info
                  Expanded(
                    child: Text(
                      selectedCount > 0
                          ? '$selectedCount selected'
                          : 'Select notifications',
                      style: GoogleFonts.inter(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: colorScheme.onSurface,
                      ),
                    ),
                  ),

                  // Quick action buttons
                  if (selectedCount > 0) ...[
                    // Digest selected
                    IconButton(
                      onPressed: onDigestSelected,
                      icon: CustomIconWidget(
                        iconName: 'schedule',
                        color: colorScheme.primary,
                        size: 20,
                      ),
                      tooltip: 'Digest Selected',
                      style: IconButton.styleFrom(
                        backgroundColor:
                            colorScheme.primary.withValues(alpha: 0.1),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                    ),

                    const SizedBox(width: 8),

                    // Silence selected
                    IconButton(
                      onPressed: onSilenceSelected,
                      icon: CustomIconWidget(
                        iconName: 'volume_off',
                        color: colorScheme.error,
                        size: 20,
                      ),
                      tooltip: 'Silence Selected',
                      style: IconButton.styleFrom(
                        backgroundColor:
                            colorScheme.error.withValues(alpha: 0.1),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                    ),
                  ] else ...[
                    // Select all
                    TextButton.icon(
                      onPressed: onSelectAll,
                      icon: CustomIconWidget(
                        iconName: 'select_all',
                        color: colorScheme.primary,
                        size: 16,
                      ),
                      label: Text(
                        'Select All',
                        style: GoogleFonts.inter(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                      ),
                    ),
                  ],
                ],
              ),
            )
          : const SizedBox.shrink(),
    );
  }
}