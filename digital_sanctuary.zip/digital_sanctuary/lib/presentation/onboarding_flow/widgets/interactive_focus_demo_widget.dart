import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

/// Interactive focus mode buttons demo
class InteractiveFocusDemoWidget extends StatefulWidget {
  const InteractiveFocusDemoWidget({super.key});

  @override
  State<InteractiveFocusDemoWidget> createState() =>
      _InteractiveFocusDemoWidgetState();
}

class _InteractiveFocusDemoWidgetState
    extends State<InteractiveFocusDemoWidget> {
  int _selectedMode = -1;

  final List<Map<String, dynamic>> _focusModes = [
    {
      'name': 'Work',
      'icon': 'work',
      'color': Color(0xFF4A90E2),
    },
    {
      'name': 'Study',
      'icon': 'school',
      'color': Color(0xFF7ED321),
    },
    {
      'name': 'Sleep',
      'icon': 'bedtime',
      'color': Color(0xFF9B59B6),
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 85.w,
      height: 10.h,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: _focusModes.asMap().entries.map((entry) {
          final index = entry.key;
          final mode = entry.value;
          final isSelected = _selectedMode == index;

          return GestureDetector(
            onTap: () {
              setState(() {
                _selectedMode = isSelected ? -1 : index;
              });

              // Reset selection after demonstration
              if (!isSelected) {
                Future.delayed(const Duration(milliseconds: 1500), () {
                  if (mounted) {
                    setState(() {
                      _selectedMode = -1;
                    });
                  }
                });
              }
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeInOut,
              width: 20.w,
              height: 8.h,
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: isSelected
                    ? (mode['color'] as Color).withValues(alpha: 0.2)
                    : AppTheme.lightTheme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isSelected
                      ? (mode['color'] as Color)
                      : AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.3),
                  width: isSelected ? 2 : 1,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AnimatedScale(
                    scale: isSelected ? 1.2 : 1.0,
                    duration: const Duration(milliseconds: 200),
                    child: CustomIconWidget(
                      iconName: mode['icon'] as String,
                      color: isSelected
                          ? (mode['color'] as Color)
                          : AppTheme.lightTheme.colorScheme.onSurface
                              .withValues(alpha: 0.6),
                      size: 20,
                    ),
                  ),
                  SizedBox(height: 1.h),
                  Text(
                    mode['name'] as String,
                    style: AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                      color: isSelected
                          ? (mode['color'] as Color)
                          : AppTheme.lightTheme.colorScheme.onSurface
                              .withValues(alpha: 0.6),
                      fontWeight:
                          isSelected ? FontWeight.w600 : FontWeight.w400,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
