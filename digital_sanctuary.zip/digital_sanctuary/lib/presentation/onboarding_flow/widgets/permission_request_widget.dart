import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

/// Permission request widget with benefit explanations
class PermissionRequestWidget extends StatefulWidget {
  final VoidCallback? onPermissionsGranted;

  const PermissionRequestWidget({
    super.key,
    this.onPermissionsGranted,
  });

  @override
  State<PermissionRequestWidget> createState() =>
      _PermissionRequestWidgetState();
}

class _PermissionRequestWidgetState extends State<PermissionRequestWidget> {
  final List<Map<String, dynamic>> _permissions = [
    {
      'title': 'Notification Access',
      'description': 'Consolidate all your notifications in one place',
      'icon': 'notifications',
      'granted': false,
      'required': true,
    },
    {
      'title': 'Calendar Sync',
      'description': 'Auto-activate focus modes during meetings',
      'icon': 'calendar_today',
      'granted': false,
      'required': false,
    },
    {
      'title': 'Location Services',
      'description': 'Smart focus modes based on your location',
      'icon': 'location_on',
      'granted': false,
      'required': false,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 90.w,
      padding: EdgeInsets.all(4.w),
      child: Column(
        children: [
          Text(
            'Grant Permissions',
            style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurface,
              fontWeight: FontWeight.w700,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 2.h),
          Text(
            'These permissions help us provide the best experience',
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurface
                  .withValues(alpha: 0.7),
            ),
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          SizedBox(height: 4.h),
          Expanded(
            child: ListView.separated(
              itemCount: _permissions.length,
              separatorBuilder: (context, index) => SizedBox(height: 2.h),
              itemBuilder: (context, index) {
                final permission = _permissions[index];
                return _buildPermissionCard(permission, index);
              },
            ),
          ),
          SizedBox(height: 3.h),
          _buildActionButtons(),
        ],
      ),
    );
  }

  Widget _buildPermissionCard(Map<String, dynamic> permission, int index) {
    final isGranted = permission['granted'] as bool;
    final isRequired = permission['required'] as bool;

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: isGranted
            ? AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1)
            : AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isGranted
              ? AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.3)
              : AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 12.w,
            height: 12.w,
            decoration: BoxDecoration(
              color: isGranted
                  ? AppTheme.lightTheme.colorScheme.primary
                      .withValues(alpha: 0.2)
                  : AppTheme.lightTheme.colorScheme.onSurface
                      .withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: CustomIconWidget(
              iconName: permission['icon'] as String,
              color: isGranted
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.onSurface
                      .withValues(alpha: 0.6),
              size: 24,
            ),
          ),
          SizedBox(width: 4.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        permission['title'] as String,
                        style:
                            AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                          color: AppTheme.lightTheme.colorScheme.onSurface,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (isRequired) ...[
                      SizedBox(width: 2.w),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 2.w, vertical: 0.5.h),
                        decoration: BoxDecoration(
                          color: AppTheme.lightTheme.colorScheme.error
                              .withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          'Required',
                          style: AppTheme.lightTheme.textTheme.labelSmall
                              ?.copyWith(
                            color: AppTheme.lightTheme.colorScheme.error,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                SizedBox(height: 1.h),
                Text(
                  permission['description'] as String,
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurface
                        .withValues(alpha: 0.6),
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          SizedBox(width: 3.w),
          GestureDetector(
            onTap: () => _requestPermission(index),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
              decoration: BoxDecoration(
                color: isGranted
                    ? AppTheme.lightTheme.colorScheme.primary
                    : AppTheme.lightTheme.colorScheme.primary
                        .withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
                border: isGranted
                    ? null
                    : Border.all(
                        color: AppTheme.lightTheme.colorScheme.primary,
                        width: 1,
                      ),
              ),
              child: Text(
                isGranted ? 'Granted' : 'Grant',
                style: AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
                  color: isGranted
                      ? AppTheme.lightTheme.colorScheme.onPrimary
                      : AppTheme.lightTheme.colorScheme.primary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    final hasRequiredPermissions = _permissions
        .where((p) => p['required'] as bool)
        .every((p) => p['granted'] as bool);

    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: hasRequiredPermissions ? _completeOnboarding : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: hasRequiredPermissions
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.onSurface
                      .withValues(alpha: 0.3),
              foregroundColor: hasRequiredPermissions
                  ? AppTheme.lightTheme.colorScheme.onPrimary
                  : AppTheme.lightTheme.colorScheme.onSurface
                      .withValues(alpha: 0.6),
              padding: EdgeInsets.symmetric(vertical: 2.h),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: Text(
              'Continue to Digital Sanctuary',
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                color: hasRequiredPermissions
                    ? AppTheme.lightTheme.colorScheme.onPrimary
                    : AppTheme.lightTheme.colorScheme.onSurface
                        .withValues(alpha: 0.6),
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
        SizedBox(height: 2.h),
        TextButton(
          onPressed: _skipOptionalPermissions,
          child: Text(
            'Skip optional permissions',
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurface
                  .withValues(alpha: 0.6),
            ),
          ),
        ),
      ],
    );
  }

  void _requestPermission(int index) {
    setState(() {
      _permissions[index]['granted'] = true;
    });

    // Show success feedback
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${_permissions[index]['title']} permission granted'),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _completeOnboarding() {
    widget.onPermissionsGranted?.call();
  }

  void _skipOptionalPermissions() {
    // Grant required permissions if not already granted
    for (int i = 0; i < _permissions.length; i++) {
      if (_permissions[i]['required'] as bool &&
          !(_permissions[i]['granted'] as bool)) {
        setState(() {
          _permissions[i]['granted'] = true;
        });
      }
    }

    Future.delayed(const Duration(milliseconds: 300), () {
      _completeOnboarding();
    });
  }
}
