import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/faq_section.dart';
import './widgets/feature_comparison_table.dart';
import './widgets/premium_feature_card.dart';
import './widgets/pricing_card.dart';
import './widgets/testimonial_card.dart';
import './widgets/trial_activation_card.dart';

class PremiumUpgrade extends StatefulWidget {
  const PremiumUpgrade({super.key});

  @override
  State<PremiumUpgrade> createState() => _PremiumUpgradeState();
}

class _PremiumUpgradeState extends State<PremiumUpgrade>
    with TickerProviderStateMixin {
  final PageController _featurePageController = PageController();
  final PageController _testimonialPageController = PageController();

  bool _isMonthlyLoading = false;
  bool _isAnnualLoading = false;
  bool _isTrialLoading = false;
  String? _trialErrorMessage;
  bool _isTrialSuccess = false;

  late AnimationController _confettiController;
  late Animation<double> _fadeAnimation;

  int _currentFeaturePage = 0;
  int _currentTestimonialPage = 0;

  final List<Map<String, dynamic>> _premiumFeatures = [
    {
      'title': 'Unlimited Notifications',
      'description':
          'Process unlimited notifications daily without restrictions. Perfect for power users managing multiple apps and accounts.',
      'iconName': 'all_inclusive',
    },
    {
      'title': 'Custom Focus Modes',
      'description':
          'Create unlimited personalized focus modes tailored to your specific needs and workflows.',
      'iconName': 'tune',
    },
    {
      'title': 'Advanced Analytics',
      'description':
          'Deep insights into your digital wellness journey with detailed reports and productivity metrics.',
      'iconName': 'analytics',
    },
    {
      'title': 'Theme Customization',
      'description':
          'Personalize your experience with beautiful themes designed to reduce digital stress.',
      'iconName': 'palette',
    },
    {
      'title': 'Home Screen Widgets',
      'description':
          'Quick access to focus modes and notification summaries right from your home screen.',
      'iconName': 'widgets',
    },
  ];

  final List<Map<String, dynamic>> _testimonials = [
    {
      'name': 'Sarah Chen',
      'role': 'Product Manager',
      'testimonial':
          'Digital Sanctuary transformed my work-life balance. I\'ve reduced notification stress by 80% and increased my focus time significantly.',
      'rating': 5.0,
      'avatarUrl':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
    },
    {
      'name': 'Michael Rodriguez',
      'role': 'Software Engineer',
      'testimonial':
          'The custom focus modes are game-changing. I can finally code without constant interruptions from social media and news apps.',
      'rating': 5.0,
      'avatarUrl':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
    },
    {
      'name': 'Emily Johnson',
      'role': 'Graduate Student',
      'testimonial':
          'As a student, this app helped me create distraction-free study sessions. My productivity has improved dramatically.',
      'rating': 4.0,
      'avatarUrl':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
    },
  ];

  @override
  void initState() {
    super.initState();
    _confettiController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _confettiController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _featurePageController.dispose();
    _testimonialPageController.dispose();
    _confettiController.dispose();
    super.dispose();
  }

  void _handleTrialCodeSubmit(String code) async {
    setState(() {
      _isTrialLoading = true;
      _trialErrorMessage = null;
      _isTrialSuccess = false;
    });

    // Simulate API call delay
    await Future.delayed(const Duration(seconds: 1));

    if (code.toUpperCase() == 'KUR1SU') {
      setState(() {
        _isTrialLoading = false;
        _isTrialSuccess = true;
      });

      // Trigger success animation
      _confettiController.forward();

      // Show success dialog
      _showTrialSuccessDialog();
    } else {
      setState(() {
        _isTrialLoading = false;
        _trialErrorMessage = 'Invalid trial code. Please check and try again.';
      });

      // Trigger haptic feedback for error
      HapticFeedback.lightImpact();
    }
  }

  void _handleMonthlySubscription() async {
    setState(() {
      _isMonthlyLoading = true;
    });

    try {
      // Simulate subscription process
      await Future.delayed(const Duration(seconds: 2));

      // Show purchase confirmation
      _showPurchaseConfirmation('Monthly', '\$4.99/month');
    } catch (e) {
      _showErrorDialog('Purchase failed. Please try again.');
    } finally {
      setState(() {
        _isMonthlyLoading = false;
      });
    }
  }

  void _handleAnnualSubscription() async {
    setState(() {
      _isAnnualLoading = true;
    });

    try {
      // Simulate subscription process
      await Future.delayed(const Duration(seconds: 2));

      // Show purchase confirmation
      _showPurchaseConfirmation('Annual', '\$39.99/year');
    } catch (e) {
      _showErrorDialog('Purchase failed. Please try again.');
    } finally {
      setState(() {
        _isAnnualLoading = false;
      });
    }
  }

  void _showTrialSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'celebration',
              color: AppTheme.successLight,
              size: 24,
            ),
            SizedBox(width: 2.w),
            Text(
              'Trial Activated!',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ],
        ),
        content: Text(
          'Congratulations! You now have 24 hours of premium access. Enjoy unlimited notifications, custom focus modes, and advanced analytics.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.pushReplacementNamed(context, '/notification-hub');
            },
            child: const Text('Start Exploring'),
          ),
        ],
      ),
    );
  }

  void _showPurchaseConfirmation(String plan, String price) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Text(
          'Confirm Purchase',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'You are about to subscribe to:',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            SizedBox(height: 2.h),
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: Theme.of(context)
                    .colorScheme
                    .primary
                    .withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '$plan Plan',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  Text(
                    price,
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: Theme.of(context).colorScheme.primary,
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              'Subscription will auto-renew unless cancelled. You can manage your subscription in your device settings.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withValues(alpha: 0.6),
                  ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              _showSuccessDialog();
            },
            child: const Text('Confirm'),
          ),
        ],
      ),
    );
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'check_circle',
              color: AppTheme.successLight,
              size: 24,
            ),
            SizedBox(width: 2.w),
            Text(
              'Welcome to Premium!',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ],
        ),
        content: Text(
          'Thank you for upgrading! All premium features are now unlocked. Start creating custom focus modes and enjoy unlimited notifications.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.pushReplacementNamed(context, '/notification-hub');
            },
            child: const Text('Get Started'),
          ),
        ],
      ),
    );
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'error_outline',
              color: Theme.of(context).colorScheme.error,
              size: 24,
            ),
            SizedBox(width: 2.w),
            const Text('Error'),
          ],
        ),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _handleRestorePurchases() async {
    // Show loading indicator
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: CircularProgressIndicator(),
      ),
    );

    // Simulate restore process
    await Future.delayed(const Duration(seconds: 2));

    Navigator.of(context).pop(); // Close loading dialog

    // Show result
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('No previous purchases found'),
        duration: Duration(seconds: 3),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Stack(
          children: [
            // Main content
            CustomScrollView(
              slivers: [
                // App bar
                SliverAppBar(
                  backgroundColor: Colors.transparent,
                  elevation: 0,
                  leading: IconButton(
                    icon: CustomIconWidget(
                      iconName: 'close',
                      color: colorScheme.onSurface,
                      size: 24,
                    ),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                  actions: [
                    TextButton(
                      onPressed: _handleRestorePurchases,
                      child: Text(
                        'Restore',
                        style: theme.textTheme.labelLarge?.copyWith(
                          color: colorScheme.primary,
                        ),
                      ),
                    ),
                    SizedBox(width: 2.w),
                  ],
                  floating: true,
                  snap: true,
                ),

                // Hero section
                SliverToBoxAdapter(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    child: Column(
                      children: [
                        // Premium badge
                        Container(
                          padding: EdgeInsets.all(4.w),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                colorScheme.primary,
                                colorScheme.secondary,
                              ],
                            ),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: CustomIconWidget(
                            iconName: 'workspace_premium',
                            color: Colors.white,
                            size: 48,
                          ),
                        ),
                        SizedBox(height: 3.h),
                        Text(
                          'Unlock Premium Features',
                          style: theme.textTheme.headlineMedium?.copyWith(
                            fontWeight: FontWeight.w700,
                            color: colorScheme.onSurface,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: 2.h),
                        Text(
                          'Take control of your digital wellness with unlimited notifications, custom focus modes, and advanced analytics.',
                          style: theme.textTheme.bodyLarge?.copyWith(
                            color: colorScheme.onSurface.withValues(alpha: 0.7),
                            height: 1.4,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: 4.h),
                      ],
                    ),
                  ),
                ),

                // Feature carousel
                SliverToBoxAdapter(
                  child: Column(
                    children: [
                      SizedBox(
                        height: 35.h,
                        child: PageView.builder(
                          controller: _featurePageController,
                          onPageChanged: (index) {
                            setState(() {
                              _currentFeaturePage = index;
                            });
                          },
                          itemCount: _premiumFeatures.length,
                          itemBuilder: (context, index) {
                            final feature = _premiumFeatures[index];
                            return PremiumFeatureCard(
                              title: feature['title'],
                              description: feature['description'],
                              iconName: feature['iconName'],
                              isHighlighted:
                                  index == 1, // Highlight custom focus modes
                              onTryNow: () {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                        '${feature['title']} preview coming soon!'),
                                    duration: const Duration(seconds: 2),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                      SizedBox(height: 2.h),
                      // Page indicators
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(
                          _premiumFeatures.length,
                          (index) => Container(
                            width: 8,
                            height: 8,
                            margin: const EdgeInsets.symmetric(horizontal: 4),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: index == _currentFeaturePage
                                  ? colorScheme.primary
                                  : colorScheme.onSurface
                                      .withValues(alpha: 0.3),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 4.h),
                    ],
                  ),
                ),

                // Trial activation section
                SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    child: Column(
                      children: [
                        TrialActivationCard(
                          onCodeSubmit: _handleTrialCodeSubmit,
                          isLoading: _isTrialLoading,
                          errorMessage: _trialErrorMessage,
                          isSuccess: _isTrialSuccess,
                        ),
                        SizedBox(height: 4.h),
                      ],
                    ),
                  ),
                ),

                // Pricing section
                SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Choose Your Plan',
                          style: theme.textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: colorScheme.onSurface,
                          ),
                        ),
                        SizedBox(height: 2.h),
                        PricingCard(
                          title: 'Annual Plan',
                          price: '\$39.99',
                          period: '/year',
                          originalPrice: '\$59.88',
                          savingsText: 'Save 33%',
                          isPopular: true,
                          isLoading: _isAnnualLoading,
                          onTap: _handleAnnualSubscription,
                        ),
                        PricingCard(
                          title: 'Monthly Plan',
                          price: '\$4.99',
                          period: '/month',
                          isLoading: _isMonthlyLoading,
                          onTap: _handleMonthlySubscription,
                        ),
                        SizedBox(height: 4.h),
                      ],
                    ),
                  ),
                ),

                // Feature comparison table
                SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Compare Plans',
                          style: theme.textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: colorScheme.onSurface,
                          ),
                        ),
                        SizedBox(height: 2.h),
                        const FeatureComparisonTable(),
                        SizedBox(height: 4.h),
                      ],
                    ),
                  ),
                ),

                // Testimonials section
                SliverToBoxAdapter(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 4.w),
                        child: Text(
                          'What Users Say',
                          style: theme.textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: colorScheme.onSurface,
                          ),
                        ),
                      ),
                      SizedBox(height: 2.h),
                      SizedBox(
                        height: 25.h,
                        child: PageView.builder(
                          controller: _testimonialPageController,
                          onPageChanged: (index) {
                            setState(() {
                              _currentTestimonialPage = index;
                            });
                          },
                          itemCount: _testimonials.length,
                          itemBuilder: (context, index) {
                            final testimonial = _testimonials[index];
                            return TestimonialCard(
                              name: testimonial['name'],
                              role: testimonial['role'],
                              testimonial: testimonial['testimonial'],
                              rating: testimonial['rating'],
                              avatarUrl: testimonial['avatarUrl'],
                            );
                          },
                        ),
                      ),
                      SizedBox(height: 2.h),
                      // Testimonial indicators
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(
                          _testimonials.length,
                          (index) => Container(
                            width: 8,
                            height: 8,
                            margin: const EdgeInsets.symmetric(horizontal: 4),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: index == _currentTestimonialPage
                                  ? colorScheme.primary
                                  : colorScheme.onSurface
                                      .withValues(alpha: 0.3),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 4.h),
                    ],
                  ),
                ),

                // FAQ section
                SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    child: Column(
                      children: [
                        const FaqSection(),
                        SizedBox(height: 4.h),
                      ],
                    ),
                  ),
                ),

                // Footer
                SliverToBoxAdapter(
                  child: Container(
                    padding: EdgeInsets.all(4.w),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            TextButton(
                              onPressed: () {
                                // Show terms of service
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Terms of Service'),
                                    duration: Duration(seconds: 2),
                                  ),
                                );
                              },
                              child: Text(
                                'Terms of Service',
                                style: theme.textTheme.bodySmall?.copyWith(
                                  color: colorScheme.primary,
                                ),
                              ),
                            ),
                            Container(
                              width: 1,
                              height: 16,
                              color: colorScheme.outline.withValues(alpha: 0.3),
                            ),
                            TextButton(
                              onPressed: () {
                                // Show privacy policy
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Privacy Policy'),
                                    duration: Duration(seconds: 2),
                                  ),
                                );
                              },
                              child: Text(
                                'Privacy Policy',
                                style: theme.textTheme.bodySmall?.copyWith(
                                  color: colorScheme.primary,
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 2.h),
                        Text(
                          'Secure payments processed by your device\'s app store',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: colorScheme.onSurface.withValues(alpha: 0.6),
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: 4.h),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            // Confetti animation overlay
            if (_isTrialSuccess)
              FadeTransition(
                opacity: _fadeAnimation,
                child: Container(
                  width: double.infinity,
                  height: double.infinity,
                  child: CustomPaint(
                    painter: ConfettiPainter(),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// Simple confetti painter for celebration effect
class ConfettiPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;

    // Draw simple confetti particles
    for (int i = 0; i < 20; i++) {
      paint.color = [
        Colors.blue,
        Colors.green,
        Colors.orange,
        Colors.purple,
        Colors.red,
      ][i % 5];

      final x = (i * 37) % size.width.toInt();
      final y = (i * 23) % size.height.toInt();

      canvas.drawCircle(
        Offset(x.toDouble(), y.toDouble()),
        4,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
