import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class FaqSection extends StatefulWidget {
  const FaqSection({super.key});

  @override
  State<FaqSection> createState() => _FaqSectionState();
}

class _FaqSectionState extends State<FaqSection> {
  int? expandedIndex;

  final List<Map<String, String>> faqs = [
    {
      'question': 'How does the free trial work?',
      'answer':
          'Enter the trial code "KUR1SU" to unlock all premium features for 24 hours. No payment required during the trial period.',
    },
    {
      'question': 'Can I cancel my subscription anytime?',
      'answer':
          'Yes, you can cancel your subscription at any time through your device\'s app store settings. You\'ll continue to have access until the end of your billing period.',
    },
    {
      'question': 'What happens to my data if I cancel?',
      'answer':
          'All your data is stored locally on your device. Canceling your subscription won\'t delete any of your focus sessions, analytics, or settings.',
    },
    {
      'question': 'Do you offer refunds?',
      'answer':
          'Refunds are handled through your device\'s app store (Apple App Store or Google Play Store) according to their refund policies.',
    },
    {
      'question': 'How many devices can I use?',
      'answer':
          'Your premium subscription is tied to your app store account and can be used on all devices signed in with the same account.',
    },
    {
      'question': 'Is my data secure?',
      'answer':
          'Yes, all your data is processed and stored locally on your device. We don\'t sync or store any personal information on our servers.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Frequently Asked Questions',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
            color: colorScheme.onSurface,
          ),
        ),
        SizedBox(height: 2.h),
        ...faqs.asMap().entries.map((entry) {
          final index = entry.key;
          final faq = entry.value;
          final isExpanded = expandedIndex == index;

          return Container(
            margin: EdgeInsets.only(bottom: 1.h),
            decoration: BoxDecoration(
              color: colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: colorScheme.outline.withValues(alpha: 0.2),
              ),
            ),
            child: ExpansionTile(
              title: Text(
                faq['question']!,
                style: theme.textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: colorScheme.onSurface,
                ),
              ),
              trailing: AnimatedRotation(
                turns: isExpanded ? 0.5 : 0,
                duration: const Duration(milliseconds: 200),
                child: CustomIconWidget(
                  iconName: 'keyboard_arrow_down',
                  color: colorScheme.onSurface.withValues(alpha: 0.6),
                  size: 24,
                ),
              ),
              onExpansionChanged: (expanded) {
                setState(() {
                  expandedIndex = expanded ? index : null;
                });
              },
              children: [
                Padding(
                  padding: EdgeInsets.fromLTRB(4.w, 0, 4.w, 3.h),
                  child: Text(
                    faq['answer']!,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: colorScheme.onSurface.withValues(alpha: 0.7),
                      height: 1.4,
                    ),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ],
    );
  }
}
