import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class FeatureComparisonTable extends StatelessWidget {
  const FeatureComparisonTable({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final List<Map<String, dynamic>> features = [
      {
        'feature': 'Notification Hub',
        'free': true,
        'premium': true,
      },
      {
        'feature': 'Basic Focus Modes (3)',
        'free': true,
        'premium': true,
      },
      {
        'feature': 'Notification Limit',
        'free': '50/day',
        'premium': 'Unlimited',
      },
      {
        'feature': 'Custom Focus Modes',
        'free': false,
        'premium': true,
      },
      {
        'feature': 'Advanced Analytics',
        'free': false,
        'premium': true,
      },
      {
        'feature': 'Theme Customization',
        'free': false,
        'premium': true,
      },
      {
        'feature': 'Home Screen Widgets',
        'free': false,
        'premium': true,
      },
      {
        'feature': 'Per-App Controls',
        'free': false,
        'premium': true,
      },
    ];

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        children: [
          // Header
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: colorScheme.primary.withValues(alpha: 0.05),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(12),
                topRight: Radius.circular(12),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  flex: 2,
                  child: Text(
                    'Features',
                    style: theme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: colorScheme.onSurface,
                    ),
                  ),
                ),
                Expanded(
                  child: Center(
                    child: Text(
                      'Free',
                      style: theme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: colorScheme.onSurface,
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Center(
                    child: Text(
                      'Premium',
                      style: theme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: colorScheme.primary,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Feature rows
          ...features.asMap().entries.map((entry) {
            final index = entry.key;
            final feature = entry.value;
            final isEven = index % 2 == 0;

            return Container(
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: isEven
                    ? colorScheme.surface
                    : colorScheme.surface.withValues(alpha: 0.5),
              ),
              child: Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: Text(
                      feature['feature'],
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: colorScheme.onSurface,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Center(
                      child: _buildFeatureCell(
                        context,
                        feature['free'],
                        false,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Center(
                      child: _buildFeatureCell(
                        context,
                        feature['premium'],
                        true,
                      ),
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildFeatureCell(
      BuildContext context, dynamic value, bool isPremium) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    if (value is bool) {
      return CustomIconWidget(
        iconName: value ? 'check_circle' : 'cancel',
        color: value
            ? (isPremium ? colorScheme.primary : AppTheme.successLight)
            : colorScheme.onSurface.withValues(alpha: 0.3),
        size: 20,
      );
    } else if (value is String) {
      return Text(
        value,
        style: theme.textTheme.bodySmall?.copyWith(
          color: isPremium ? colorScheme.primary : colorScheme.onSurface,
          fontWeight: isPremium ? FontWeight.w600 : FontWeight.w400,
        ),
        textAlign: TextAlign.center,
      );
    }

    return const SizedBox.shrink();
  }
}
