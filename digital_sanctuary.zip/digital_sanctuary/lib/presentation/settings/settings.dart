import 'package:flutter/material.dart';

import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import './widgets/premium_status_widget.dart';
import './widgets/settings_item_widget.dart';
import './widgets/settings_section_widget.dart';
import './widgets/theme_selector_widget.dart';

/// Settings screen providing comprehensive app configuration
/// Implements platform-native patterns with organized sections
class Settings extends StatefulWidget {
  const Settings({super.key});

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  // Mock user preferences data
  final Map<String, dynamic> _userPreferences = {
    "isPremium": false,
    "subscriptionType": null,
    "expiryDate": null,
    "digestTimes": ["9:00 AM", "12:00 PM", "5:00 PM"],
    "autoCategorization": true,
    "emergencyBypass": true,
    "defaultFocusDuration": 25,
    "autoActivation": false,
    "calendarIntegration": true,
    "currentTheme": "auto",
    "notificationsEnabled": true,
    "biometricAuth": false,
    "dataUsage": "2.3 MB",
    "lastBackup": "2025-08-25",
    "appVersion": "1.2.0",
    "buildNumber": "124",
  };

  // Mock analytics data
  final Map<String, dynamic> _analyticsData = {
    "totalFocusTime": "47 hours",
    "notificationsProcessed": 1247,
    "stressReduction": "23%",
    "weeklyGoalProgress": 0.78,
  };

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: CustomAppBar.settings(),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            children: [
              const SizedBox(height: 8),
              
              // Premium Status Section
              PremiumStatusWidget(
                isPremium: _userPreferences["isPremium"] as bool,
                subscriptionType: _userPreferences["subscriptionType"] as String?,
                expiryDate: _userPreferences["expiryDate"] as DateTime?,
                onUpgradeTap: () => Navigator.pushNamed(context, '/premium-upgrade'),
                onTrialActivation: _handleTrialActivation,
              ),

              // Notification Settings Section
              SettingsSectionWidget(
                title: 'NOTIFICATION SETTINGS',
                children: [
                  SettingsItemWidget.navigation(
                    title: 'Digest Times',
                    subtitle: 'Customize when you receive notification summaries',
                    value: '${(_userPreferences["digestTimes"] as List).length} times',
                    iconName: 'schedule',
                    onTap: _showDigestTimesDialog,
                  ),
                  SettingsItemWidget.toggle(
                    title: 'Auto-categorization',
                    subtitle: 'Automatically sort notifications by importance',
                    iconName: 'auto_awesome',
                    value: _userPreferences["autoCategorization"] as bool,
                    onChanged: (value) => _updatePreference("autoCategorization", value),
                  ),
                  SettingsItemWidget.toggle(
                    title: 'Emergency Bypass',
                    subtitle: 'Allow calls from emergency contacts during focus mode',
                    iconName: 'emergency',
                    value: _userPreferences["emergencyBypass"] as bool,
                    onChanged: (value) => _updatePreference("emergencyBypass", value),
                  ),
                  SettingsItemWidget.navigation(
                    title: 'Notification Permissions',
                    subtitle: 'Manage app notification access',
                    iconName: 'notifications_active',
                    onTap: _openNotificationPermissions,
                  ),
                ],
              ),

              // Focus Modes Section
              SettingsSectionWidget(
                title: 'FOCUS MODES',
                children: [
                  SettingsItemWidget.navigation(
                    title: 'Default Duration',
                    subtitle: 'Set your preferred focus session length',
                    value: '${_userPreferences["defaultFocusDuration"]} min',
                    iconName: 'timer',
                    onTap: _showDurationPicker,
                  ),
                  SettingsItemWidget.toggle(
                    title: 'Auto-activation',
                    subtitle: 'Start focus mode based on calendar events',
                    iconName: 'auto_mode',
                    value: _userPreferences["autoActivation"] as bool,
                    onChanged: (value) => _updatePreference("autoActivation", value),
                  ),
                  SettingsItemWidget.toggle(
                    title: 'Calendar Integration',
                    subtitle: 'Sync with your calendar for smart scheduling',
                    iconName: 'calendar_today',
                    value: _userPreferences["calendarIntegration"] as bool,
                    onChanged: (value) => _updatePreference("calendarIntegration", value),
                  ),
                  SettingsItemWidget.navigation(
                    title: 'Custom Focus Modes',
                    subtitle: _userPreferences["isPremium"] as bool
                        ? 'Create unlimited custom modes'
                        : 'Premium feature - Create custom modes',
                    iconName: 'tune',
                    onTap: () => Navigator.pushNamed(context, '/focus-mode-selection'),
                    isEnabled: _userPreferences["isPremium"] as bool,
                  ),
                ],
              ),

              // Appearance Section
              SettingsSectionWidget(
                title: 'APPEARANCE',
                children: [
                  SettingsItemWidget(
                    title: 'Theme',
                    subtitle: 'Customize your app appearance',
                    iconName: 'palette',
                    value: _getThemeDisplayName(_userPreferences["currentTheme"] as String),
                    showDisclosureIndicator: true,
                    onTap: _showThemeSelector,
                  ),
                  SettingsItemWidget.navigation(
                    title: 'Accessibility',
                    subtitle: 'Voice control and display options',
                    iconName: 'accessibility',
                    onTap: _openAccessibilitySettings,
                  ),
                ],
              ),

              // Privacy & Security Section
              SettingsSectionWidget(
                title: 'PRIVACY & SECURITY',
                children: [
                  SettingsItemWidget(
                    title: 'Data Usage',
                    subtitle: 'All data stored locally on your device',
                    iconName: 'storage',
                    value: _userPreferences["dataUsage"] as String,
                  ),
                  SettingsItemWidget.toggle(
                    title: 'Biometric Authentication',
                    subtitle: 'Secure sensitive settings with biometrics',
                    iconName: 'fingerprint',
                    value: _userPreferences["biometricAuth"] as bool,
                    onChanged: (value) => _updatePreference("biometricAuth", value),
                  ),
                  SettingsItemWidget.navigation(
                    title: 'Permission Management',
                    subtitle: 'Review and manage app permissions',
                    iconName: 'security',
                    onTap: _openPermissionSettings,
                  ),
                  SettingsItemWidget.navigation(
                    title: 'Privacy Policy',
                    subtitle: 'Learn how we protect your data',
                    iconName: 'privacy_tip',
                    onTap: _openPrivacyPolicy,
                  ),
                ],
              ),

              // Analytics & Insights Section
              SettingsSectionWidget(
                title: 'ANALYTICS & INSIGHTS',
                children: [
                  SettingsItemWidget.navigation(
                    title: 'View Analytics',
                    subtitle: 'See your focus time and wellness metrics',
                    iconName: 'analytics',
                    onTap: () => Navigator.pushNamed(context, '/analytics-dashboard'),
                  ),
                  SettingsItemWidget(
                    title: 'Weekly Progress',
                    subtitle: 'Goal completion: ${((_analyticsData["weeklyGoalProgress"] as double) * 100).toInt()}%',
                    iconName: 'trending_up',
                    value: _analyticsData["totalFocusTime"] as String,
                  ),
                  SettingsItemWidget.navigation(
                    title: 'Export Data',
                    subtitle: 'Download your wellness data',
                    iconName: 'download',
                    onTap: _exportUserData,
                    isEnabled: _userPreferences["isPremium"] as bool,
                  ),
                ],
              ),

              // Support & About Section
              SettingsSectionWidget(
                title: 'SUPPORT & ABOUT',
                children: [
                  SettingsItemWidget.navigation(
                    title: 'Help & Support',
                    subtitle: 'Get help with using Digital Sanctuary',
                    iconName: 'help',
                    onTap: _openHelpCenter,
                  ),
                  SettingsItemWidget.navigation(
                    title: 'Send Feedback',
                    subtitle: 'Share your thoughts and suggestions',
                    iconName: 'feedback',
                    onTap: _sendFeedback,
                  ),
                  SettingsItemWidget.navigation(
                    title: 'Rate App',
                    subtitle: 'Help others discover Digital Sanctuary',
                    iconName: 'star_rate',
                    onTap: _rateApp,
                  ),
                  SettingsItemWidget(
                    title: 'Version',
                    subtitle: 'Build ${_userPreferences["buildNumber"]}',
                    iconName: 'info',
                    value: _userPreferences["appVersion"] as String,
                  ),
                ],
              ),

              // Reset Options Section
              SettingsSectionWidget(
                title: 'RESET OPTIONS',
                children: [
                  SettingsItemWidget.navigation(
                    title: 'Reset Preferences',
                    subtitle: 'Restore default settings',
                    iconName: 'restore',
                    onTap: () => _showResetDialog('preferences'),
                  ),
                  SettingsItemWidget.destructive(
                    title: 'Clear All Data',
                    subtitle: 'Remove all app data and preferences',
                    iconName: 'delete_forever',
                    onTap: () => _showResetDialog('all_data'),
                  ),
                ],
              ),

              const SizedBox(height: 100), // Bottom padding for navigation
            ],
          ),
        ),
      ),
      bottomNavigationBar: CustomBottomBar.forSettings(
        onTap: _handleBottomNavigation,
      ),
    );
  }

  void _updatePreference(String key, dynamic value) {
    setState(() {
      _userPreferences[key] = value;
    });
    
    // Show confirmation for important changes
    if (key == "biometricAuth" || key == "emergencyBypass") {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${key == "biometricAuth" ? "Biometric authentication" : "Emergency bypass"} ${value ? "enabled" : "disabled"}'),
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  void _handleTrialActivation() {
    setState(() {
      _userPreferences["isPremium"] = true;
      _userPreferences["subscriptionType"] = "24-Hour Trial";
      _userPreferences["expiryDate"] = DateTime.now().add(const Duration(hours: 24));
    });
  }

  void _handleBottomNavigation(int index) {
    final routes = ['/notification-hub', '/focus-mode-selection', '/analytics-dashboard', '/settings'];
    if (index != 3) { // Don't navigate if already on settings
      Navigator.pushReplacementNamed(context, routes[index]);
    }
  }

  String _getThemeDisplayName(String themeId) {
    switch (themeId) {
      case 'light': return 'Light';
      case 'dark': return 'Dark';
      case 'auto': return 'Auto';
      case 'calm_blue': return 'Calm Blue';
      case 'forest_green': return 'Forest Green';
      case 'sunset_orange': return 'Sunset Orange';
      default: return 'Auto';
    }
  }

  void _showDigestTimesDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Digest Times'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Choose when you want to receive notification summaries:'),
            const SizedBox(height: 16),
            ...((_userPreferences["digestTimes"] as List).map((time) => 
              ListTile(
                leading: const Icon(Icons.schedule),
                title: Text(time),
                trailing: IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () => _editDigestTime(time),
                ),
              ),
            )),
            const SizedBox(height: 8),
            TextButton.icon(
              icon: const Icon(Icons.add),
              label: const Text('Add Time'),
              onPressed: _addDigestTime,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }

  void _showDurationPicker() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Default Focus Duration'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Select your preferred focus session length:'),
            const SizedBox(height: 16),
            ...([15, 25, 30, 45, 60, 90].map((duration) => 
              RadioListTile<int>(
                title: Text('$duration minutes'),
                value: duration,
                groupValue: _userPreferences["defaultFocusDuration"] as int,
                onChanged: (value) {
                  setState(() {
                    _userPreferences["defaultFocusDuration"] = value;
                  });
                  Navigator.pop(context);
                },
              ),
            )),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  void _showThemeSelector() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.only(top: 16, bottom: 32),
        child: ThemeSelectorWidget(
          currentTheme: _userPreferences["currentTheme"] as String,
          isPremium: _userPreferences["isPremium"] as bool,
          onThemeChanged: (theme) {
            setState(() {
              _userPreferences["currentTheme"] = theme;
            });
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Theme changed to ${_getThemeDisplayName(theme)}'),
                duration: const Duration(seconds: 2),
              ),
            );
          },
        ),
      ),
    );
  }

  void _showResetDialog(String type) {
    final String title = type == 'all_data' ? 'Clear All Data' : 'Reset Preferences';
    final String content = type == 'all_data' 
        ? 'This will permanently delete all your data, preferences, and analytics. This action cannot be undone.'
        : 'This will restore all settings to their default values. Your analytics data will be preserved.';

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(content),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _performReset(type);
            },
            style: TextButton.styleFrom(
              foregroundColor: Theme.of(context).colorScheme.error,
            ),
            child: Text(type == 'all_data' ? 'Delete All' : 'Reset'),
          ),
        ],
      ),
    );
  }

  void _performReset(String type) {
    if (type == 'all_data') {
      // Reset everything
      setState(() {
        _userPreferences.clear();
        _userPreferences.addAll({
          "isPremium": false,
          "subscriptionType": null,
          "expiryDate": null,
          "digestTimes": ["9:00 AM", "12:00 PM", "5:00 PM"],
          "autoCategorization": true,
          "emergencyBypass": true,
          "defaultFocusDuration": 25,
          "autoActivation": false,
          "calendarIntegration": true,
          "currentTheme": "auto",
          "notificationsEnabled": true,
          "biometricAuth": false,
          "dataUsage": "0 MB",
          "lastBackup": "Never",
          "appVersion": "1.2.0",
          "buildNumber": "124",
        });
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('All data has been cleared'),
          duration: Duration(seconds: 3),
        ),
      );
    } else {
      // Reset only preferences
      setState(() {
        _userPreferences["digestTimes"] = ["9:00 AM", "12:00 PM", "5:00 PM"];
        _userPreferences["autoCategorization"] = true;
        _userPreferences["emergencyBypass"] = true;
        _userPreferences["defaultFocusDuration"] = 25;
        _userPreferences["autoActivation"] = false;
        _userPreferences["calendarIntegration"] = true;
        _userPreferences["currentTheme"] = "auto";
        _userPreferences["biometricAuth"] = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Preferences have been reset to defaults'),
          duration: Duration(seconds: 3),
        ),
      );
    }
  }

  void _editDigestTime(String currentTime) {
    // Implementation for editing digest time
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Time picker would open here'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _addDigestTime() {
    // Implementation for adding new digest time
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Add new digest time functionality'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _openNotificationPermissions() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Opening system notification settings...'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _openAccessibilitySettings() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Opening accessibility settings...'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _openPermissionSettings() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Opening system permission settings...'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _openPrivacyPolicy() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Opening privacy policy...'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _exportUserData() {
    if (!(_userPreferences["isPremium"] as bool)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Data export requires premium subscription'),
          action: SnackBarAction(
            label: 'Upgrade',
            onPressed: () => Navigator.pushNamed(context, '/premium-upgrade'),
          ),
        ),
      );
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Exporting your data...'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _openHelpCenter() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Opening help center...'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _sendFeedback() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Opening feedback form...'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _rateApp() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Opening app store for rating...'),
        duration: Duration(seconds: 2),
      ),
    );
  }
}