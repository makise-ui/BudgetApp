import 'package:flutter/material.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

/// A widget that displays an individual settings item with various configurations
class SettingsItemWidget extends StatelessWidget {
  final String title;
  final String? subtitle;
  final String? value;
  final String? iconName;
  final Widget? leadingWidget;
  final Widget? trailingWidget;
  final VoidCallback? onTap;
  final bool showDisclosureIndicator;
  final bool isDestructive;
  final bool isEnabled;
  final EdgeInsets? padding;

  const SettingsItemWidget({
    super.key,
    required this.title,
    this.subtitle,
    this.value,
    this.iconName,
    this.leadingWidget,
    this.trailingWidget,
    this.onTap,
    this.showDisclosureIndicator = false,
    this.isDestructive = false,
    this.isEnabled = true,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final Color titleColor = isDestructive
        ? colorScheme.error
        : isEnabled
            ? colorScheme.onSurface
            : colorScheme.onSurface.withValues(alpha: 0.5);

    final Color subtitleColor = isEnabled
        ? colorScheme.onSurface.withValues(alpha: 0.7)
        : colorScheme.onSurface.withValues(alpha: 0.4);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: isEnabled ? onTap : null,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: padding ??
              const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              // Leading icon or widget
              if (leadingWidget != null)
                leadingWidget!
              else if (iconName != null) ...[
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: colorScheme.primary.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Center(
                    child: CustomIconWidget(
                      iconName: iconName!,
                      color: colorScheme.primary,
                      size: 18,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
              ],

              // Title and subtitle
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: theme.textTheme.bodyLarge?.copyWith(
                        color: titleColor,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    if (subtitle != null) ...[
                      const SizedBox(height: 2),
                      Text(
                        subtitle!,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: subtitleColor,
                        ),
                      ),
                    ],
                  ],
                ),
              ),

              // Value or trailing widget
              if (trailingWidget != null)
                trailingWidget!
              else if (value != null) ...[
                const SizedBox(width: 8),
                Text(
                  value!,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: colorScheme.onSurface.withValues(alpha: 0.6),
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],

              // Disclosure indicator
              if (showDisclosureIndicator) ...[
                const SizedBox(width: 8),
                CustomIconWidget(
                  iconName: 'chevron_right',
                  color: colorScheme.onSurface.withValues(alpha: 0.4),
                  size: 20,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  /// Factory constructor for toggle settings
  factory SettingsItemWidget.toggle({
    required String title,
    String? subtitle,
    String? iconName,
    required bool value,
    required ValueChanged<bool> onChanged,
    bool isEnabled = true,
  }) {
    return SettingsItemWidget(
      title: title,
      subtitle: subtitle,
      iconName: iconName,
      isEnabled: isEnabled,
      trailingWidget: Builder(
        builder: (context) => Switch(
          value: value,
          onChanged: isEnabled ? onChanged : null,
        ),
      ),
    );
  }

  /// Factory constructor for navigation settings
  factory SettingsItemWidget.navigation({
    required String title,
    String? subtitle,
    String? value,
    String? iconName,
    required VoidCallback onTap,
    bool isEnabled = true,
  }) {
    return SettingsItemWidget(
      title: title,
      subtitle: subtitle,
      value: value,
      iconName: iconName,
      onTap: onTap,
      showDisclosureIndicator: true,
      isEnabled: isEnabled,
    );
  }

  /// Factory constructor for destructive actions
  factory SettingsItemWidget.destructive({
    required String title,
    String? subtitle,
    String? iconName,
    required VoidCallback onTap,
    bool isEnabled = true,
  }) {
    return SettingsItemWidget(
      title: title,
      subtitle: subtitle,
      iconName: iconName,
      onTap: onTap,
      isDestructive: true,
      isEnabled: isEnabled,
    );
  }
}
