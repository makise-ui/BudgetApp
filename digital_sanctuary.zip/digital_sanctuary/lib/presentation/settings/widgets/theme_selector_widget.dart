import 'package:flutter/material.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

/// A widget that allows users to select app theme preferences
class ThemeSelectorWidget extends StatelessWidget {
  final String currentTheme;
  final ValueChanged<String> onThemeChanged;
  final bool isPremium;

  const ThemeSelectorWidget({
    super.key,
    required this.currentTheme,
    required this.onThemeChanged,
    required this.isPremium,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final List<Map<String, dynamic>> themeOptions = [
      {
        'id': 'light',
        'name': 'Light',
        'description': 'Clean and bright interface',
        'icon': 'light_mode',
        'isPremium': false,
      },
      {
        'id': 'dark',
        'name': 'Dark',
        'description': 'Easy on the eyes in low light',
        'icon': 'dark_mode',
        'isPremium': false,
      },
      {
        'id': 'auto',
        'name': 'Auto',
        'description': 'Follows system preference',
        'icon': 'brightness_auto',
        'isPremium': false,
      },
      {
        'id': 'calm_blue',
        'name': 'Calm Blue',
        'description': 'Soothing blue tones for focus',
        'icon': 'palette',
        'isPremium': true,
      },
      {
        'id': 'forest_green',
        'name': 'Forest Green',
        'description': 'Natural green for wellness',
        'icon': 'palette',
        'isPremium': true,
      },
      {
        'id': 'sunset_orange',
        'name': 'Sunset Orange',
        'description': 'Warm tones for evening use',
        'icon': 'palette',
        'isPremium': true,
      },
    ];

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Theme Selection',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: colorScheme.onSurface,
            ),
          ),
          const SizedBox(height: 12),
          Container(
            decoration: BoxDecoration(
              color: colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: colorScheme.outline.withValues(alpha: 0.2),
                width: 0.5,
              ),
            ),
            child: Column(
              children: [
                for (int i = 0; i < themeOptions.length; i++) ...[
                  _buildThemeOption(
                    context,
                    themeOptions[i],
                    currentTheme == themeOptions[i]['id'],
                  ),
                  if (i < themeOptions.length - 1)
                    Divider(
                      height: 1,
                      thickness: 0.5,
                      color: colorScheme.outline.withValues(alpha: 0.2),
                      indent: 16,
                      endIndent: 16,
                    ),
                ],
              ],
            ),
          ),
          if (!isPremium) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: colorScheme.primary.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: colorScheme.primary.withValues(alpha: 0.3),
                  width: 0.5,
                ),
              ),
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: 'star',
                    color: colorScheme.primary,
                    size: 16,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Unlock premium themes with your subscription',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: colorScheme.primary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildThemeOption(
    BuildContext context,
    Map<String, dynamic> option,
    bool isSelected,
  ) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final bool isAvailable = isPremium || !option['isPremium'];

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: isAvailable
            ? () => onThemeChanged(option['id'])
            : () => _showPremiumRequired(context),
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              // Theme icon
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: isSelected
                      ? colorScheme.primary
                      : colorScheme.outline.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: CustomIconWidget(
                    iconName: option['icon'],
                    color: isSelected
                        ? colorScheme.onPrimary
                        : isAvailable
                            ? colorScheme.onSurface
                            : colorScheme.onSurface.withValues(alpha: 0.4),
                    size: 20,
                  ),
                ),
              ),
              const SizedBox(width: 12),

              // Theme details
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          option['name'],
                          style: theme.textTheme.bodyLarge?.copyWith(
                            fontWeight: FontWeight.w500,
                            color: isAvailable
                                ? colorScheme.onSurface
                                : colorScheme.onSurface.withValues(alpha: 0.4),
                          ),
                        ),
                        if (option['isPremium']) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: colorScheme.primary.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              'PRO',
                              style: theme.textTheme.labelSmall?.copyWith(
                                color: colorScheme.primary,
                                fontWeight: FontWeight.w600,
                                fontSize: 10,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      option['description'],
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: isAvailable
                            ? colorScheme.onSurface.withValues(alpha: 0.7)
                            : colorScheme.onSurface.withValues(alpha: 0.4),
                      ),
                    ),
                  ],
                ),
              ),

              // Selection indicator
              if (isSelected)
                CustomIconWidget(
                  iconName: 'check_circle',
                  color: colorScheme.primary,
                  size: 20,
                )
              else if (!isAvailable)
                CustomIconWidget(
                  iconName: 'lock',
                  color: colorScheme.onSurface.withValues(alpha: 0.4),
                  size: 16,
                ),
            ],
          ),
        ),
      ),
    );
  }

  void _showPremiumRequired(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Premium themes require a subscription'),
        action: SnackBarAction(
          label: 'Upgrade',
          onPressed: () {
            Navigator.pushNamed(context, '/premium-upgrade');
          },
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }
}
