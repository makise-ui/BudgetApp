import 'package:flutter/material.dart';
import '../presentation/settings/settings.dart';
import '../presentation/focus_mode_selection/focus_mode_selection.dart';
import '../presentation/analytics_dashboard/analytics_dashboard.dart';
import '../presentation/notification_hub/notification_hub.dart';
import '../presentation/onboarding_flow/onboarding_flow.dart';
import '../presentation/premium_upgrade/premium_upgrade.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String settings = '/settings';
  static const String focusModeSelection = '/focus-mode-selection';
  static const String analyticsDashboard = '/analytics-dashboard';
  static const String notificationHub = '/notification-hub';
  static const String onboardingFlow = '/onboarding-flow';
  static const String premiumUpgrade = '/premium-upgrade';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const OnboardingFlow(),
    settings: (context) => const Settings(),
    focusModeSelection: (context) => const FocusModeSelection(),
    analyticsDashboard: (context) => const AnalyticsDashboard(),
    notificationHub: (context) => const NotificationHub(),
    onboardingFlow: (context) => const OnboardingFlow(),
    premiumUpgrade: (context) => const PremiumUpgrade(),
    // TODO: Add your other routes here
  };
}
