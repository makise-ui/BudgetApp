import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Custom app bar widget implementing mindful minimalism design principles
/// Provides consistent navigation and branding across the digital wellness app
class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  /// The title to display in the app bar
  final String title;

  /// Whether to show the back button (defaults to true when there's a previous route)
  final bool showBackButton;

  /// Custom leading widget (overrides back button if provided)
  final Widget? leading;

  /// List of action widgets to display on the right side
  final List<Widget>? actions;

  /// Whether to show elevation shadow (defaults to false for flat design)
  final bool showElevation;

  /// Background color override (uses theme color if not provided)
  final Color? backgroundColor;

  /// Text color override (uses theme color if not provided)
  final Color? foregroundColor;

  /// Whether to center the title (defaults to true on iOS, false on Android)
  final bool? centerTitle;

  /// Custom bottom widget (typically used for tabs)
  final PreferredSizeWidget? bottom;

  const CustomAppBar({
    super.key,
    required this.title,
    this.showBackButton = true,
    this.leading,
    this.actions,
    this.showElevation = false,
    this.backgroundColor,
    this.foregroundColor,
    this.centerTitle,
    this.bottom,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    // Determine if we should show back button
    final bool canPop = ModalRoute.of(context)?.canPop ?? false;
    final bool shouldShowBack = showBackButton && canPop && leading == null;

    return AppBar(
      title: Text(
        title,
        style: GoogleFonts.inter(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: foregroundColor ?? colorScheme.onSurface,
          letterSpacing: -0.2,
        ),
      ),
      centerTitle:
          centerTitle ?? Theme.of(context).platform == TargetPlatform.iOS,
      backgroundColor: backgroundColor ?? theme.scaffoldBackgroundColor,
      foregroundColor: foregroundColor ?? colorScheme.onSurface,
      elevation: showElevation ? 2.0 : 0,
      surfaceTintColor: Colors.transparent,
      leading: leading ?? (shouldShowBack ? _buildBackButton(context) : null),
      actions: actions,
      bottom: bottom,
      automaticallyImplyLeading: false,
      iconTheme: IconThemeData(
        color: foregroundColor ?? colorScheme.onSurface,
        size: 24,
      ),
    );
  }

  /// Builds a custom back button with proper navigation
  Widget _buildBackButton(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back_ios_new_rounded),
      onPressed: () => Navigator.of(context).pop(),
      tooltip: 'Back',
      splashRadius: 20,
    );
  }

  /// Creates an app bar for the notification hub with focus mode toggle
  static CustomAppBar notificationHub({
    VoidCallback? onFocusModeToggle,
    bool isFocusModeActive = false,
  }) {
    return CustomAppBar(
      title: 'Notifications',
      showBackButton: false,
      actions: [
        Builder(
          builder: (context) => IconButton(
            icon: Icon(
              isFocusModeActive
                  ? Icons.do_not_disturb_on_rounded
                  : Icons.do_not_disturb_off_rounded,
              color: isFocusModeActive
                  ? Theme.of(context).colorScheme.primary
                  : Theme.of(context).colorScheme.onSurface,
            ),
            onPressed: onFocusModeToggle ??
                () {
                  Navigator.pushNamed(context, '/focus-mode-selection');
                },
            tooltip:
                isFocusModeActive ? 'Focus Mode Active' : 'Enable Focus Mode',
            splashRadius: 20,
          ),
        ),
        Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.settings_rounded),
            onPressed: () => Navigator.pushNamed(context, '/settings'),
            tooltip: 'Settings',
            splashRadius: 20,
          ),
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  /// Creates an app bar for the analytics dashboard with time period selector
  static CustomAppBar analyticsDashboard({
    String timePeriod = 'This Week',
    VoidCallback? onTimePeriodTap,
  }) {
    return CustomAppBar(
      title: 'Analytics',
      showBackButton: false,
      actions: [
        Builder(
          builder: (context) => TextButton.icon(
            icon: const Icon(Icons.calendar_today_rounded, size: 16),
            label: Text(
              timePeriod,
              style: GoogleFonts.inter(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
            onPressed: onTimePeriodTap ??
                () {
                  // Show time period selection bottom sheet
                  _showTimePeriodSelector(context);
                },
            style: TextButton.styleFrom(
              foregroundColor: Theme.of(context).colorScheme.primary,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            ),
          ),
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  /// Creates an app bar for the focus mode selection screen
  static CustomAppBar focusModeSelection() {
    return const CustomAppBar(
      title: 'Focus Mode',
      showBackButton: true,
    );
  }

  /// Creates an app bar for the settings screen
  static CustomAppBar settings() {
    return CustomAppBar(
      title: 'Settings',
      showBackButton: true,
      actions: [
        Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.help_outline_rounded),
            onPressed: () {
              // Show help or support
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Help & Support coming soon'),
                  duration: Duration(seconds: 2),
                ),
              );
            },
            tooltip: 'Help & Support',
            splashRadius: 20,
          ),
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  /// Creates an app bar for the premium upgrade screen
  static CustomAppBar premiumUpgrade() {
    return CustomAppBar(
      title: 'Premium',
      showBackButton: true,
      actions: [
        Builder(
          builder: (context) => TextButton(
            onPressed: () {
              // Handle restore purchases
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Checking for previous purchases...'),
                  duration: Duration(seconds: 2),
                ),
              );
            },
            child: Text(
              'Restore',
              style: GoogleFonts.inter(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  /// Creates an app bar for the onboarding flow
  static CustomAppBar onboarding({
    required int currentStep,
    required int totalSteps,
    VoidCallback? onSkip,
  }) {
    return CustomAppBar(
      title: 'Step $currentStep of $totalSteps',
      showBackButton: currentStep > 1,
      actions: onSkip != null
          ? [
              Builder(
                builder: (context) => TextButton(
                  onPressed: onSkip,
                  child: Text(
                    'Skip',
                    style: GoogleFonts.inter(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
            ]
          : null,
    );
  }

  /// Shows a time period selector bottom sheet
  static void _showTimePeriodSelector(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Select Time Period',
              style: GoogleFonts.inter(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            ...['Today', 'This Week', 'This Month', 'Last 3 Months'].map(
              (period) => ListTile(
                title: Text(
                  period,
                  style: GoogleFonts.inter(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                  // Handle time period selection
                },
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(
        kToolbarHeight + (bottom?.preferredSize.height ?? 0.0),
      );
}
