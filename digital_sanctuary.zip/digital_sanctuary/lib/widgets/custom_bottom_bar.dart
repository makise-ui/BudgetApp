import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Navigation item data for the bottom navigation bar
class BottomNavItem {
  final IconData icon;
  final IconData? activeIcon;
  final String label;
  final String route;

  const BottomNavItem({
    required this.icon,
    this.activeIcon,
    required this.label,
    required this.route,
  });
}

/// Custom bottom navigation bar implementing gesture-first navigation
/// Provides primary navigation between main app sections with calm confidence
class CustomBottomBar extends StatelessWidget {
  /// Current active index
  final int currentIndex;

  /// Callback when a navigation item is tapped
  final ValueChanged<int>? onTap;

  /// Whether to show labels (defaults to true)
  final bool showLabels;

  /// Custom background color
  final Color? backgroundColor;

  /// Custom selected item color
  final Color? selectedItemColor;

  /// Custom unselected item color
  final Color? unselectedItemColor;

  /// Elevation of the bottom bar
  final double elevation;

  /// Navigation items for the bottom bar
  static const List<BottomNavItem> _navItems = [
    BottomNavItem(
      icon: Icons.notifications_outlined,
      activeIcon: Icons.notifications_rounded,
      label: 'Notifications',
      route: '/notification-hub',
    ),
    BottomNavItem(
      icon: Icons.psychology_outlined,
      activeIcon: Icons.psychology_rounded,
      label: 'Focus',
      route: '/focus-mode-selection',
    ),
    BottomNavItem(
      icon: Icons.analytics_outlined,
      activeIcon: Icons.analytics_rounded,
      label: 'Analytics',
      route: '/analytics-dashboard',
    ),
    BottomNavItem(
      icon: Icons.settings_outlined,
      activeIcon: Icons.settings_rounded,
      label: 'Settings',
      route: '/settings',
    ),
  ];

  const CustomBottomBar({
    super.key,
    required this.currentIndex,
    this.onTap,
    this.showLabels = true,
    this.backgroundColor,
    this.selectedItemColor,
    this.unselectedItemColor,
    this.elevation = 8.0,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      decoration: BoxDecoration(
        color: backgroundColor ?? colorScheme.surface,
        boxShadow: elevation > 0
            ? [
                BoxShadow(
                  color: colorScheme.shadow.withValues(alpha: 0.08),
                  offset: const Offset(0, -2),
                  blurRadius: 8,
                  spreadRadius: 0,
                ),
              ]
            : null,
      ),
      child: SafeArea(
        child: Container(
          height: 64,
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: _navItems.asMap().entries.map((entry) {
              final index = entry.key;
              final item = entry.value;
              final isSelected = index == currentIndex;

              return Expanded(
                child: _buildNavItem(
                  context,
                  item,
                  isSelected,
                  index,
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  /// Builds an individual navigation item with micro-feedback animations
  Widget _buildNavItem(
    BuildContext context,
    BottomNavItem item,
    bool isSelected,
    int index,
  ) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final Color itemColor = isSelected
        ? (selectedItemColor ?? colorScheme.primary)
        : (unselectedItemColor ?? colorScheme.onSurface.withValues(alpha: 0.6));

    return GestureDetector(
      onTap: () => _handleNavigation(context, index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeInOut,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected
              ? colorScheme.primary.withValues(alpha: 0.1)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedScale(
              scale: isSelected ? 1.1 : 1.0,
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeInOut,
              child: Icon(
                isSelected && item.activeIcon != null
                    ? item.activeIcon!
                    : item.icon,
                color: itemColor,
                size: 24,
              ),
            ),
            if (showLabels) ...[
              const SizedBox(height: 2),
              AnimatedDefaultTextStyle(
                duration: const Duration(milliseconds: 200),
                style: GoogleFonts.inter(
                  fontSize: isSelected ? 12 : 11,
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                  color: itemColor,
                  height: 1.0,
                ),
                child: Text(
                  item.label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// Handles navigation with proper route management
  void _handleNavigation(BuildContext context, int index) {
    if (index == currentIndex) return;

    // Provide haptic feedback for user confirmation
    _triggerHapticFeedback();

    // Call the onTap callback if provided
    if (onTap != null) {
      onTap!(index);
      return;
    }

    // Default navigation behavior
    final route = _navItems[index].route;

    // Use pushReplacementNamed to replace current route in bottom nav context
    Navigator.pushReplacementNamed(context, route);
  }

  /// Triggers subtle haptic feedback for micro-interactions
  void _triggerHapticFeedback() {
    // Note: In a real app, you would use HapticFeedback.lightImpact()
    // For now, we'll just add a comment as haptic feedback requires platform channels
    // HapticFeedback.lightImpact();
  }

  /// Factory constructor for notification hub screen
  static CustomBottomBar forNotificationHub({
    ValueChanged<int>? onTap,
  }) {
    return CustomBottomBar(
      currentIndex: 0,
      onTap: onTap,
    );
  }

  /// Factory constructor for focus mode selection screen
  static CustomBottomBar forFocusMode({
    ValueChanged<int>? onTap,
  }) {
    return CustomBottomBar(
      currentIndex: 1,
      onTap: onTap,
    );
  }

  /// Factory constructor for analytics dashboard screen
  static CustomBottomBar forAnalytics({
    ValueChanged<int>? onTap,
  }) {
    return CustomBottomBar(
      currentIndex: 2,
      onTap: onTap,
    );
  }

  /// Factory constructor for settings screen
  static CustomBottomBar forSettings({
    ValueChanged<int>? onTap,
  }) {
    return CustomBottomBar(
      currentIndex: 3,
      onTap: onTap,
    );
  }

  /// Gets the current route based on the active index
  static String getCurrentRoute(int index) {
    if (index >= 0 && index < _navItems.length) {
      return _navItems[index].route;
    }
    return '/notification-hub'; // Default route
  }

  /// Gets the index for a given route
  static int getIndexForRoute(String route) {
    for (int i = 0; i < _navItems.length; i++) {
      if (_navItems[i].route == route) {
        return i;
      }
    }
    return 0; // Default to first item
  }

  /// Checks if the bottom bar should be visible for the given route
  static bool shouldShowForRoute(String route) {
    return _navItems.any((item) => item.route == route);
  }
}
