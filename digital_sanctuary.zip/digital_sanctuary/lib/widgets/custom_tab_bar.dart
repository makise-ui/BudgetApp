import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Tab item data for the custom tab bar
class TabItem {
  final String label;
  final IconData? icon;
  final Widget? customIcon;
  final String? badge;

  const TabItem({
    required this.label,
    this.icon,
    this.customIcon,
    this.badge,
  });
}

/// Custom tab bar widget implementing progressive disclosure patterns
/// Used primarily in analytics dashboard and notification categorization
class CustomTabBar extends StatelessWidget implements PreferredSizeWidget {
  /// List of tab items
  final List<TabItem> tabs;

  /// Current selected tab index
  final int selectedIndex;

  /// Callback when a tab is selected
  final ValueChanged<int>? onTabSelected;

  /// Whether tabs are scrollable (defaults to false)
  final bool isScrollable;

  /// Custom background color
  final Color? backgroundColor;

  /// Custom selected tab color
  final Color? selectedColor;

  /// Custom unselected tab color
  final Color? unselectedColor;

  /// Custom indicator color
  final Color? indicatorColor;

  /// Tab bar height
  final double height;

  /// Whether to show icons
  final bool showIcons;

  /// Padding around tabs
  final EdgeInsets padding;

  const CustomTabBar({
    super.key,
    required this.tabs,
    required this.selectedIndex,
    this.onTabSelected,
    this.isScrollable = false,
    this.backgroundColor,
    this.selectedColor,
    this.unselectedColor,
    this.indicatorColor,
    this.height = 48.0,
    this.showIcons = true,
    this.padding = const EdgeInsets.symmetric(horizontal: 16),
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      height: height,
      padding: padding,
      decoration: BoxDecoration(
        color: backgroundColor ?? colorScheme.surface,
        border: Border(
          bottom: BorderSide(
            color: colorScheme.outline.withValues(alpha: 0.2),
            width: 0.5,
          ),
        ),
      ),
      child: isScrollable
          ? _buildScrollableTabs(context)
          : _buildFixedTabs(context),
    );
  }

  /// Builds scrollable tabs for many tab items
  Widget _buildScrollableTabs(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: _buildTabWidgets(context),
      ),
    );
  }

  /// Builds fixed tabs that distribute evenly
  Widget _buildFixedTabs(BuildContext context) {
    return Row(
      children: _buildTabWidgets(context, isFixed: true),
    );
  }

  /// Builds individual tab widgets
  List<Widget> _buildTabWidgets(BuildContext context, {bool isFixed = false}) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return tabs.asMap().entries.map((entry) {
      final index = entry.key;
      final tab = entry.value;
      final isSelected = index == selectedIndex;

      final Color tabColor = isSelected
          ? (selectedColor ?? colorScheme.primary)
          : (unselectedColor ?? colorScheme.onSurface.withValues(alpha: 0.6));

      Widget tabContent = _buildTabContent(context, tab, isSelected, tabColor);

      if (isFixed) {
        tabContent = Expanded(child: tabContent);
      }

      return tabContent;
    }).toList();
  }

  /// Builds the content of an individual tab
  Widget _buildTabContent(
    BuildContext context,
    TabItem tab,
    bool isSelected,
    Color tabColor,
  ) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return GestureDetector(
      onTap: () => _handleTabSelection(context, tabs.indexOf(tab)),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeInOut,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        margin: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: isSelected
              ? colorScheme.primary.withValues(alpha: 0.1)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
          border: isSelected
              ? Border(
                  bottom: BorderSide(
                    color: indicatorColor ?? colorScheme.primary,
                    width: 2,
                  ),
                )
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (showIcons && (tab.icon != null || tab.customIcon != null)) ...[
              if (tab.customIcon != null)
                tab.customIcon!
              else
                Icon(
                  tab.icon,
                  size: 18,
                  color: tabColor,
                ),
              const SizedBox(width: 8),
            ],
            Text(
              tab.label,
              style: GoogleFonts.inter(
                fontSize: 14,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                color: tabColor,
                letterSpacing: 0.1,
              ),
            ),
            if (tab.badge != null) ...[
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: colorScheme.error,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  tab.badge!,
                  style: GoogleFonts.inter(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: colorScheme.onError,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// Handles tab selection with smooth transitions
  void _handleTabSelection(BuildContext context, int index) {
    if (index == selectedIndex) return;

    // Trigger haptic feedback
    _triggerHapticFeedback();

    // Call the callback
    onTabSelected?.call(index);
  }

  /// Triggers subtle haptic feedback
  void _triggerHapticFeedback() {
    // Note: In a real app, you would use HapticFeedback.selectionClick()
    // HapticFeedback.selectionClick();
  }

  /// Factory constructor for analytics dashboard tabs
  static CustomTabBar forAnalytics({
    required int selectedIndex,
    ValueChanged<int>? onTabSelected,
  }) {
    return CustomTabBar(
      tabs: const [
        TabItem(
          label: 'Overview',
          icon: Icons.dashboard_outlined,
        ),
        TabItem(
          label: 'Focus Time',
          icon: Icons.timer_outlined,
        ),
        TabItem(
          label: 'Notifications',
          icon: Icons.notifications_outlined,
        ),
        TabItem(
          label: 'Wellness',
          icon: Icons.favorite_outline,
        ),
      ],
      selectedIndex: selectedIndex,
      onTabSelected: onTabSelected,
      isScrollable: false,
    );
  }

  /// Factory constructor for notification hub category tabs
  static CustomTabBar forNotificationCategories({
    required int selectedIndex,
    ValueChanged<int>? onTabSelected,
    Map<String, int>? categoryBadges,
  }) {
    return CustomTabBar(
      tabs: [
        TabItem(
          label: 'All',
          icon: Icons.inbox_outlined,
          badge: categoryBadges?['all']?.toString(),
        ),
        TabItem(
          label: 'Work',
          icon: Icons.work_outline,
          badge: categoryBadges?['work']?.toString(),
        ),
        TabItem(
          label: 'Social',
          icon: Icons.people_outline,
          badge: categoryBadges?['social']?.toString(),
        ),
        TabItem(
          label: 'News',
          icon: Icons.article_outlined,
          badge: categoryBadges?['news']?.toString(),
        ),
        TabItem(
          label: 'Other',
          icon: Icons.more_horiz,
          badge: categoryBadges?['other']?.toString(),
        ),
      ],
      selectedIndex: selectedIndex,
      onTabSelected: onTabSelected,
      isScrollable: true,
    );
  }

  /// Factory constructor for focus mode type tabs
  static CustomTabBar forFocusModes({
    required int selectedIndex,
    ValueChanged<int>? onTabSelected,
  }) {
    return CustomTabBar(
      tabs: const [
        TabItem(
          label: 'Work',
          icon: Icons.work_outline,
        ),
        TabItem(
          label: 'Study',
          icon: Icons.school_outlined,
        ),
        TabItem(
          label: 'Sleep',
          icon: Icons.bedtime_outlined,
        ),
        TabItem(
          label: 'Personal',
          icon: Icons.person_outline,
        ),
        TabItem(
          label: 'Custom',
          icon: Icons.tune_outlined,
        ),
      ],
      selectedIndex: selectedIndex,
      onTabSelected: onTabSelected,
      isScrollable: true,
    );
  }

  /// Factory constructor for settings category tabs
  static CustomTabBar forSettingsCategories({
    required int selectedIndex,
    ValueChanged<int>? onTabSelected,
  }) {
    return CustomTabBar(
      tabs: const [
        TabItem(
          label: 'General',
          icon: Icons.settings_outlined,
        ),
        TabItem(
          label: 'Notifications',
          icon: Icons.notifications_outlined,
        ),
        TabItem(
          label: 'Privacy',
          icon: Icons.privacy_tip_outlined,
        ),
        TabItem(
          label: 'About',
          icon: Icons.info_outline,
        ),
      ],
      selectedIndex: selectedIndex,
      onTabSelected: onTabSelected,
      isScrollable: false,
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(height);
}
