import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/acknowledgments_card.dart';
import './widgets/app_info_card.dart';
import './widgets/developer_info_card.dart';
import './widgets/quick_actions_card.dart';
import './widgets/settings_section.dart';

class AboutSettings extends StatefulWidget {
  const AboutSettings({super.key});

  @override
  State<AboutSettings> createState() => _AboutSettingsState();
}

class _AboutSettingsState extends State<AboutSettings> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('About & Settings'),
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            color:
                Theme.of(context).appBarTheme.foregroundColor ?? Colors.black,
            size: 24,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () => Navigator.pushNamed(context, '/dashboard'),
            icon: CustomIconWidget(
              iconName: 'home',
              color:
                  Theme.of(context).appBarTheme.foregroundColor ?? Colors.black,
              size: 24,
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 1.h),

              // App Information Card
              AppInfoCard(),

              // Developer Information Card
              DeveloperInfoCard(),

              // Settings Section
              SettingsSection(),

              // Quick Actions Card
              QuickActionsCard(),

              // Acknowledgments Card
              AcknowledgmentsCard(),

              SizedBox(height: 2.h),

              // Navigation Footer
              Container(
                margin: EdgeInsets.symmetric(horizontal: 4.w),
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.primaryContainer
                      .withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    Text(
                      'Quick Navigation',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                    SizedBox(height: 2.h),
                    Wrap(
                      spacing: 2.w,
                      runSpacing: 1.h,
                      children: [
                        _buildNavChip(
                          context,
                          label: 'Dashboard',
                          icon: 'dashboard',
                          route: '/dashboard',
                        ),
                        _buildNavChip(
                          context,
                          label: 'Attendance',
                          icon: 'event_available',
                          route: '/attendance-tracker',
                        ),
                        _buildNavChip(
                          context,
                          label: 'Grades',
                          icon: 'grade',
                          route: '/grades-marks',
                        ),
                        _buildNavChip(
                          context,
                          label: 'Profile',
                          icon: 'person',
                          route: '/student-profile',
                        ),
                        _buildNavChip(
                          context,
                          label: 'Login',
                          icon: 'login',
                          route: '/login-screen',
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              SizedBox(height: 4.h),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavChip(
    BuildContext context, {
    required String label,
    required String icon,
    required String route,
  }) {
    return InkWell(
      onTap: () => Navigator.pushNamed(context, route),
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.3),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomIconWidget(
              iconName: icon,
              color: AppTheme.lightTheme.primaryColor,
              size: 16,
            ),
            SizedBox(width: 1.w),
            Text(
              label,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
