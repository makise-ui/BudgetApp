import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:sizer/sizer.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../../core/app_export.dart';

class QuickActionsCard extends StatelessWidget {
  const QuickActionsCard({super.key});

  Future<void> _rateApp() async {
    const String playStoreUrl =
        'https://play.google.com/store/apps/details?id=com.klu.student.app';
    const String appStoreUrl =
        'https://apps.apple.com/app/klu-student-app/id123456789';

    try {
      // Try to open appropriate store based on platform
      final Uri url = Uri.parse(playStoreUrl); // Default to Play Store
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } catch (e) {
      // Handle error silently
    }
  }

  Future<void> _shareApp() async {
    try {
      await Share.share(
        'Check out the KLU Student App! Download it from the app store to access your academic information on the go.',
        subject: 'KLU Student App',
      );
    } catch (e) {
      // Handle error silently
    }
  }

  Future<void> _reportIssue() async {
    const String email = 'hasanfq6@gmail.com';
    const String subject = 'KLU Student App - Issue Report';
    const String body = 'Please describe the issue you encountered:';

    final Uri emailUri = Uri(
      scheme: 'mailto',
      path: email,
      query:
          'subject=${Uri.encodeComponent(subject)}&body=${Uri.encodeComponent(body)}',
    );

    try {
      await launchUrl(emailUri);
    } catch (e) {
      // Handle error silently
    }
  }

  Future<void> _openPrivacyPolicy() async {
    const String privacyUrl =
        'https://github.com/hasanfq6/KLU-APP/blob/main/PRIVACY.md';

    try {
      await launchUrl(Uri.parse(privacyUrl),
          mode: LaunchMode.externalApplication);
    } catch (e) {
      // Handle error silently
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Quick Actions',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
            SizedBox(height: 2.h),
            GridView.count(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              crossAxisSpacing: 3.w,
              mainAxisSpacing: 2.h,
              childAspectRatio: 2.5,
              children: [
                _buildActionButton(
                  context,
                  icon: 'star',
                  label: 'Rate App',
                  onTap: _rateApp,
                ),
                _buildActionButton(
                  context,
                  icon: 'share',
                  label: 'Share App',
                  onTap: _shareApp,
                ),
                _buildActionButton(
                  context,
                  icon: 'bug_report',
                  label: 'Report Issue',
                  onTap: _reportIssue,
                ),
                _buildActionButton(
                  context,
                  icon: 'privacy_tip',
                  label: 'Privacy Policy',
                  onTap: _openPrivacyPolicy,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton(
    BuildContext context, {
    required String icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
        decoration: BoxDecoration(
          border: Border.all(
            color:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.3),
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: icon,
              color: AppTheme.lightTheme.primaryColor,
              size: 20,
            ),
            SizedBox(width: 2.w),
            Flexible(
              child: Text(
                label,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w500,
                    ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
