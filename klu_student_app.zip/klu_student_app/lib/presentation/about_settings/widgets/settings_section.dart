import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';

class SettingsSection extends StatefulWidget {
  const SettingsSection({super.key});

  @override
  State<SettingsSection> createState() => _SettingsSectionState();
}

class _SettingsSectionState extends State<SettingsSection> {
  String _selectedTheme = 'System';
  bool _notificationsEnabled = true;
  bool _offlineDataEnabled = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _selectedTheme = prefs.getString('theme_mode') ?? 'System';
      _notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;
      _offlineDataEnabled = prefs.getBool('offline_data_enabled') ?? true;
    });
  }

  Future<void> _saveThemePreference(String theme) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('theme_mode', theme);
    setState(() {
      _selectedTheme = theme;
    });
  }

  Future<void> _saveNotificationPreference(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notifications_enabled', enabled);
    setState(() {
      _notificationsEnabled = enabled;
    });
  }

  Future<void> _saveOfflineDataPreference(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('offline_data_enabled', enabled);
    setState(() {
      _offlineDataEnabled = enabled;
    });
  }

  Future<void> _clearCache() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('cached_data');

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Cache cleared successfully'),
          backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
        ),
      );
    }
  }

  void _showThemeDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Choose Theme'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              RadioListTile<String>(
                title: Text('Light'),
                value: 'Light',
                groupValue: _selectedTheme,
                onChanged: (value) {
                  if (value != null) {
                    _saveThemePreference(value);
                    Navigator.pop(context);
                  }
                },
              ),
              RadioListTile<String>(
                title: Text('Dark'),
                value: 'Dark',
                groupValue: _selectedTheme,
                onChanged: (value) {
                  if (value != null) {
                    _saveThemePreference(value);
                    Navigator.pop(context);
                  }
                },
              ),
              RadioListTile<String>(
                title: Text('System'),
                value: 'System',
                groupValue: _selectedTheme,
                onChanged: (value) {
                  if (value != null) {
                    _saveThemePreference(value);
                    Navigator.pop(context);
                  }
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Settings',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
            SizedBox(height: 2.h),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: CustomIconWidget(
                iconName: 'palette',
                color: AppTheme.lightTheme.primaryColor,
                size: 24,
              ),
              title: Text('Theme'),
              subtitle: Text(_selectedTheme),
              trailing: CustomIconWidget(
                iconName: 'arrow_forward_ios',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 16,
              ),
              onTap: _showThemeDialog,
            ),
            Divider(height: 2.h),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: CustomIconWidget(
                iconName: 'notifications',
                color: AppTheme.lightTheme.primaryColor,
                size: 24,
              ),
              title: Text('Notifications'),
              subtitle: Text('Receive app notifications'),
              value: _notificationsEnabled,
              onChanged: _saveNotificationPreference,
            ),
            Divider(height: 2.h),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: CustomIconWidget(
                iconName: 'offline_pin',
                color: AppTheme.lightTheme.primaryColor,
                size: 24,
              ),
              title: Text('Offline Data'),
              subtitle: Text('Store data for offline access'),
              value: _offlineDataEnabled,
              onChanged: _saveOfflineDataPreference,
            ),
            SizedBox(height: 2.h),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _clearCache,
                icon: CustomIconWidget(
                  iconName: 'clear_all',
                  color: AppTheme.warningLight,
                  size: 20,
                ),
                label: Text(
                  'Clear Cache',
                  style: TextStyle(color: AppTheme.warningLight),
                ),
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: AppTheme.warningLight),
                  padding: EdgeInsets.symmetric(vertical: 1.5.h),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
