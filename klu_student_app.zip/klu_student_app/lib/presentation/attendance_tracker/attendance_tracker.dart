import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/attendance_header.dart';
import './widgets/attendance_trend_chart.dart';
import './widgets/projection_calculator_sheet.dart';
import './widgets/semester_filter_chip.dart';
import './widgets/subject_attendance_card.dart';

class AttendanceTracker extends StatefulWidget {
  const AttendanceTracker({Key? key}) : super(key: key);

  @override
  State<AttendanceTracker> createState() => _AttendanceTrackerState();
}

class _AttendanceTrackerState extends State<AttendanceTracker>
    with TickerProviderStateMixin {
  bool isRefreshing = false;
  String selectedSemester = 'Current Semester';
  final ScrollController _scrollController = ScrollController();

  final List<String> semesters = [
    'Current Semester',
    'Semester 7',
    'Semester 6',
    'Semester 5',
  ];

  final List<Map<String, dynamic>> attendanceData = [
    {
      "id": 1,
      "name": "Data Structures and Algorithms",
      "code": "CSE301",
      "attended": 28,
      "total": 32,
      "percentage": 87.5,
      "status": "safe",
      "isFavorite": true,
    },
    {
      "id": 2,
      "name": "Database Management Systems",
      "code": "CSE302",
      "attended": 24,
      "total": 30,
      "percentage": 80.0,
      "status": "safe",
      "isFavorite": false,
    },
    {
      "id": 3,
      "name": "Computer Networks",
      "code": "CSE303",
      "attended": 20,
      "total": 28,
      "percentage": 71.4,
      "status": "warning",
      "isFavorite": true,
    },
    {
      "id": 4,
      "name": "Software Engineering",
      "code": "CSE304",
      "attended": 18,
      "total": 30,
      "percentage": 60.0,
      "status": "critical",
      "isFavorite": false,
    },
    {
      "id": 5,
      "name": "Operating Systems",
      "code": "CSE305",
      "attended": 26,
      "total": 29,
      "percentage": 89.7,
      "status": "safe",
      "isFavorite": true,
    },
    {
      "id": 6,
      "name": "Web Technologies",
      "code": "CSE306",
      "attended": 22,
      "total": 31,
      "percentage": 71.0,
      "status": "warning",
      "isFavorite": false,
    },
  ];

  final List<Map<String, dynamic>> trendData = [
    {"week": "W1", "percentage": 85.0},
    {"week": "W2", "percentage": 82.5},
    {"week": "W3", "percentage": 78.0},
    {"week": "W4", "percentage": 75.5},
    {"week": "W5", "percentage": 77.2},
    {"week": "W6", "percentage": 79.8},
    {"week": "W7", "percentage": 76.4},
    {"week": "W8", "percentage": 74.1},
  ];

  @override
  Widget build(BuildContext context) {
    final totalPresent = attendanceData.fold<int>(
      0,
      (sum, subject) => sum + (subject['attended'] as int),
    );
    final totalClasses = attendanceData.fold<int>(
      0,
      (sum, subject) => sum + (subject['total'] as int),
    );
    final overallPercentage = (totalPresent / totalClasses) * 100;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: RefreshIndicator(
        onRefresh: _handleRefresh,
        color: AppTheme.lightTheme.colorScheme.primary,
        child: CustomScrollView(
          controller: _scrollController,
          slivers: [
            SliverToBoxAdapter(
              child: AttendanceHeader(
                overallPercentage: overallPercentage,
                totalPresent: totalPresent,
                totalClasses: totalClasses,
                isRefreshing: isRefreshing,
                onRefresh: _handleRefresh,
              ),
            ),
            SliverToBoxAdapter(
              child: Container(
                height: 6.h,
                margin: EdgeInsets.symmetric(vertical: 1.h),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: EdgeInsets.symmetric(horizontal: 4.w),
                  itemCount: semesters.length,
                  itemBuilder: (context, index) {
                    return SemesterFilterChip(
                      semester: semesters[index],
                      isSelected: selectedSemester == semesters[index],
                      onTap: () => _onSemesterChanged(semesters[index]),
                    );
                  },
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: AttendanceTrendChart(trendData: trendData),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'subject',
                      color: AppTheme.lightTheme.colorScheme.primary,
                      size: 20,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Subject Attendance',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                    Spacer(),
                    Text(
                      '${attendanceData.length} subjects',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: AppTheme.textMediumEmphasisLight,
                          ),
                    ),
                  ],
                ),
              ),
            ),
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final subject = attendanceData[index];
                  return SubjectAttendanceCard(
                    subject: subject,
                    onTap: () => _onSubjectTap(subject),
                    onViewDetails: () => _onViewDetails(subject),
                    onCalculateProjections: () =>
                        _onCalculateProjections(subject),
                    onSetAlerts: () => _onSetAlerts(subject),
                  );
                },
                childCount: attendanceData.length,
              ),
            ),
            SliverToBoxAdapter(
              child: SizedBox(height: 10.h),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showProjectionCalculator,
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
        foregroundColor: Colors.white,
        icon: CustomIconWidget(
          iconName: 'calculate',
          color: Colors.white,
          size: 20,
        ),
        label: Text(
          'Calculator',
          style: Theme.of(context).textTheme.labelLarge?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
        ),
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  Widget _buildBottomNavigationBar() {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        border: Border(
          top: BorderSide(
            color: AppTheme.dividerLight,
            width: 1,
          ),
        ),
      ),
      child: SafeArea(
        child: Container(
          height: 8.h,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildNavItem('Dashboard', 'dashboard', '/dashboard', false),
              _buildNavItem(
                  'Attendance', 'event_available', '/attendance-tracker', true),
              _buildNavItem('Grades', 'grade', '/grades-marks', false),
              _buildNavItem('Profile', 'person', '/student-profile', false),
              _buildNavItem('Settings', 'settings', '/about-settings', false),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(
      String label, String iconName, String route, bool isSelected) {
    return GestureDetector(
      onTap: () {
        if (!isSelected) {
          Navigator.pushReplacementNamed(context, route);
        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 1.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomIconWidget(
              iconName: iconName,
              color: isSelected
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.neutralLight,
              size: 24,
            ),
            SizedBox(height: 0.5.h),
            Text(
              label,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: isSelected
                        ? AppTheme.lightTheme.colorScheme.primary
                        : AppTheme.neutralLight,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                  ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _handleRefresh() async {
    setState(() => isRefreshing = true);

    // Simulate API call
    await Future.delayed(Duration(seconds: 2));

    setState(() => isRefreshing = false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Attendance data refreshed successfully'),
        backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }

  void _onSemesterChanged(String semester) {
    setState(() => selectedSemester = semester);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Switched to $semester'),
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }

  void _onSubjectTap(Map<String, dynamic> subject) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => ProjectionCalculatorSheet(subject: subject),
    );
  }

  void _onViewDetails(Map<String, dynamic> subject) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(subject['name'] as String),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Subject Code: ${subject['code']}'),
            SizedBox(height: 1.h),
            Text('Classes Attended: ${subject['attended']}'),
            Text('Total Classes: ${subject['total']}'),
            Text(
                'Attendance: ${(subject['percentage'] as num).toStringAsFixed(1)}%'),
            SizedBox(height: 1.h),
            Text(
              'Status: ${subject['status'].toString().toUpperCase()}',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color:
                    _getStatusColor((subject['percentage'] as num).toDouble()),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  void _onCalculateProjections(Map<String, dynamic> subject) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => ProjectionCalculatorSheet(subject: subject),
    );
  }

  void _onSetAlerts(Map<String, dynamic> subject) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Set Alert'),
        content: Text('Set attendance alert for ${subject['name']}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Alert set for ${subject['name']}'),
                  backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
                ),
              );
            },
            child: Text('Set Alert'),
          ),
        ],
      ),
    );
  }

  void _showProjectionCalculator() {
    if (attendanceData.isNotEmpty) {
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (context) =>
            ProjectionCalculatorSheet(subject: attendanceData.first),
      );
    }
  }

  Color _getStatusColor(double percentage) {
    if (percentage >= 75) return AppTheme.lightTheme.colorScheme.secondary;
    if (percentage >= 65) return AppTheme.warningLight;
    return AppTheme.lightTheme.colorScheme.error;
  }
}
