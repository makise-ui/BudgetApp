import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class AttendanceHeader extends StatelessWidget {
  final double overallPercentage;
  final int totalPresent;
  final int totalClasses;
  final bool isRefreshing;
  final VoidCallback? onRefresh;

  const AttendanceHeader({
    Key? key,
    required this.overallPercentage,
    required this.totalPresent,
    required this.totalClasses,
    this.isRefreshing = false,
    this.onRefresh,
  }) : super(key: key);

  Color _getOverallStatusColor(double percentage) {
    if (percentage >= 75) return AppTheme.lightTheme.colorScheme.secondary;
    if (percentage >= 65) return AppTheme.warningLight;
    return AppTheme.lightTheme.colorScheme.error;
  }

  String _getOverallStatusText(double percentage) {
    if (percentage >= 75) return 'Good Standing';
    if (percentage >= 65) return 'Needs Attention';
    return 'Critical Status';
  }

  @override
  Widget build(BuildContext context) {
    final statusColor = _getOverallStatusColor(overallPercentage);
    final statusText = _getOverallStatusText(overallPercentage);

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            statusColor.withValues(alpha: 0.1),
            statusColor.withValues(alpha: 0.05),
          ],
        ),
        border: Border(
          bottom: BorderSide(
            color: AppTheme.dividerLight,
            width: 1,
          ),
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Attendance Tracker',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textHighEmphasisLight,
                        ),
                  ),
                  InkWell(
                    onTap: isRefreshing ? null : onRefresh,
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      padding: EdgeInsets.all(2.w),
                      child: isRefreshing
                          ? SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  AppTheme.lightTheme.colorScheme.primary,
                                ),
                              ),
                            )
                          : CustomIconWidget(
                              iconName: 'refresh',
                              color: AppTheme.lightTheme.colorScheme.primary,
                              size: 24,
                            ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 2.h),
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.shadowLight,
                      blurRadius: 8,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Overall Attendance',
                                style: Theme.of(context)
                                    .textTheme
                                    .titleMedium
                                    ?.copyWith(
                                      color: AppTheme.textMediumEmphasisLight,
                                    ),
                              ),
                              SizedBox(height: 1.h),
                              Text(
                                '${overallPercentage.toStringAsFixed(1)}%',
                                style: Theme.of(context)
                                    .textTheme
                                    .displaySmall
                                    ?.copyWith(
                                      color: statusColor,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 32.sp,
                                    ),
                              ),
                              SizedBox(height: 0.5.h),
                              Text(
                                statusText,
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(
                                      color: statusColor,
                                      fontWeight: FontWeight.w500,
                                    ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: 25.w,
                          height: 25.w,
                          child: Stack(
                            children: [
                              Container(
                                width: double.infinity,
                                height: double.infinity,
                                child: CircularProgressIndicator(
                                  value: overallPercentage / 100,
                                  strokeWidth: 8,
                                  backgroundColor:
                                      statusColor.withValues(alpha: 0.2),
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                      statusColor),
                                ),
                              ),
                              Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      '$totalPresent',
                                      style: Theme.of(context)
                                          .textTheme
                                          .titleLarge
                                          ?.copyWith(
                                            fontWeight: FontWeight.w700,
                                            color: statusColor,
                                          ),
                                    ),
                                    Text(
                                      'of $totalClasses',
                                      style: Theme.of(context)
                                          .textTheme
                                          .labelSmall
                                          ?.copyWith(
                                            color: AppTheme
                                                .textMediumEmphasisLight,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 2.h),
                    Container(
                      width: double.infinity,
                      height: 1,
                      color: AppTheme.dividerLight,
                    ),
                    SizedBox(height: 1.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _buildStatItem(
                          context,
                          'Present',
                          '$totalPresent',
                          AppTheme.lightTheme.colorScheme.secondary,
                        ),
                        Container(
                          width: 1,
                          height: 4.h,
                          color: AppTheme.dividerLight,
                        ),
                        _buildStatItem(
                          context,
                          'Absent',
                          '${totalClasses - totalPresent}',
                          AppTheme.lightTheme.colorScheme.error,
                        ),
                        Container(
                          width: 1,
                          height: 4.h,
                          color: AppTheme.dividerLight,
                        ),
                        _buildStatItem(
                          context,
                          'Total',
                          '$totalClasses',
                          AppTheme.lightTheme.colorScheme.primary,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatItem(
    BuildContext context,
    String label,
    String value,
    Color color,
  ) {
    return Column(
      children: [
        Text(
          value,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                color: color,
                fontWeight: FontWeight.w600,
              ),
        ),
        SizedBox(height: 0.5.h),
        Text(
          label,
          style: Theme.of(context).textTheme.labelMedium?.copyWith(
                color: AppTheme.textMediumEmphasisLight,
              ),
        ),
      ],
    );
  }
}
