import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ProjectionCalculatorSheet extends StatefulWidget {
  final Map<String, dynamic> subject;

  const ProjectionCalculatorSheet({
    Key? key,
    required this.subject,
  }) : super(key: key);

  @override
  State<ProjectionCalculatorSheet> createState() =>
      _ProjectionCalculatorSheetState();
}

class _ProjectionCalculatorSheetState extends State<ProjectionCalculatorSheet> {
  double targetPercentage = 75.0;
  int plannedAbsences = 0;
  bool isTargetMode = true;

  @override
  Widget build(BuildContext context) {
    final currentAttended = widget.subject['attended'] as int;
    final currentTotal = widget.subject['total'] as int;
    final currentPercentage = (widget.subject['percentage'] as num).toDouble();

    return Container(
      height: 70.h,
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          Container(
            width: 12.w,
            height: 0.5.h,
            margin: EdgeInsets.only(top: 1.h),
            decoration: BoxDecoration(
              color: AppTheme.neutralLight,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Attendance Calculator',
                        style:
                            Theme.of(context).textTheme.headlineSmall?.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: CustomIconWidget(
                        iconName: 'close',
                        color: AppTheme.neutralLight,
                        size: 24,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 1.h),
                Text(
                  widget.subject['name'] as String,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: AppTheme.textMediumEmphasisLight,
                      ),
                ),
                SizedBox(height: 2.h),
                Container(
                  padding: EdgeInsets.all(3.w),
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.primary
                        .withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'info',
                        color: AppTheme.lightTheme.colorScheme.primary,
                        size: 20,
                      ),
                      SizedBox(width: 2.w),
                      Expanded(
                        child: Text(
                          'Current: ${currentPercentage.toStringAsFixed(1)}% ($currentAttended/$currentTotal)',
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium
                              ?.copyWith(
                                color: AppTheme.lightTheme.colorScheme.primary,
                                fontWeight: FontWeight.w500,
                              ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 3.h),
                Container(
                  decoration: BoxDecoration(
                    color: AppTheme.neutralLight.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: () => setState(() => isTargetMode = true),
                          child: Container(
                            padding: EdgeInsets.symmetric(vertical: 1.5.h),
                            decoration: BoxDecoration(
                              color: isTargetMode
                                  ? AppTheme.lightTheme.colorScheme.primary
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              'Target Mode',
                              textAlign: TextAlign.center,
                              style: Theme.of(context)
                                  .textTheme
                                  .labelLarge
                                  ?.copyWith(
                                    color: isTargetMode
                                        ? Colors.white
                                        : AppTheme.textMediumEmphasisLight,
                                    fontWeight: FontWeight.w500,
                                  ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: GestureDetector(
                          onTap: () => setState(() => isTargetMode = false),
                          child: Container(
                            padding: EdgeInsets.symmetric(vertical: 1.5.h),
                            decoration: BoxDecoration(
                              color: !isTargetMode
                                  ? AppTheme.lightTheme.colorScheme.primary
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              'Impact Mode',
                              textAlign: TextAlign.center,
                              style: Theme.of(context)
                                  .textTheme
                                  .labelLarge
                                  ?.copyWith(
                                    color: !isTargetMode
                                        ? Colors.white
                                        : AppTheme.textMediumEmphasisLight,
                                    fontWeight: FontWeight.w500,
                                  ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: isTargetMode
                  ? _buildTargetMode(
                      currentAttended, currentTotal, currentPercentage)
                  : _buildImpactMode(
                      currentAttended, currentTotal, currentPercentage),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTargetMode(
      int currentAttended, int currentTotal, double currentPercentage) {
    final requiredClasses = _calculateRequiredClasses(
      currentAttended,
      currentTotal,
      targetPercentage,
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 2.h),
        Text(
          'Target Percentage',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w500,
              ),
        ),
        SizedBox(height: 1.h),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.dividerLight),
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '${targetPercentage.toInt()}%',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          color: AppTheme.lightTheme.colorScheme.primary,
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  Text(
                    'Target',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: AppTheme.textMediumEmphasisLight,
                        ),
                  ),
                ],
              ),
              SizedBox(height: 1.h),
              Slider(
                value: targetPercentage,
                min: 50,
                max: 100,
                divisions: 50,
                onChanged: (value) => setState(() => targetPercentage = value),
              ),
            ],
          ),
        ),
        SizedBox(height: 3.h),
        Container(
          width: double.infinity,
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: requiredClasses['color'] as Color,
              width: 1,
            ),
          ),
          child: Column(
            children: [
              CustomIconWidget(
                iconName: requiredClasses['icon'] as String,
                color: requiredClasses['color'] as Color,
                size: 32,
              ),
              SizedBox(height: 1.h),
              Text(
                requiredClasses['title'] as String,
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: requiredClasses['color'] as Color,
                      fontWeight: FontWeight.w600,
                    ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 0.5.h),
              Text(
                requiredClasses['subtitle'] as String,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: AppTheme.textMediumEmphasisLight,
                    ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
        SizedBox(height: 2.h),
      ],
    );
  }

  Widget _buildImpactMode(
      int currentAttended, int currentTotal, double currentPercentage) {
    final impact =
        _calculateImpact(currentAttended, currentTotal, plannedAbsences);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 2.h),
        Text(
          'Planned Absences',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w500,
              ),
        ),
        SizedBox(height: 1.h),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.dividerLight),
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '$plannedAbsences',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          color: AppTheme.lightTheme.colorScheme.primary,
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  Text(
                    'Classes',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: AppTheme.textMediumEmphasisLight,
                        ),
                  ),
                ],
              ),
              SizedBox(height: 1.h),
              Slider(
                value: plannedAbsences.toDouble(),
                min: 0,
                max: 20,
                divisions: 20,
                onChanged: (value) =>
                    setState(() => plannedAbsences = value.toInt()),
              ),
            ],
          ),
        ),
        SizedBox(height: 3.h),
        Container(
          width: double.infinity,
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: impact['color'] as Color,
              width: 1,
            ),
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'New Percentage',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: AppTheme.textMediumEmphasisLight,
                            ),
                      ),
                      Text(
                        '${impact['percentage']}%',
                        style: Theme.of(context)
                            .textTheme
                            .headlineMedium
                            ?.copyWith(
                              color: impact['color'] as Color,
                              fontWeight: FontWeight.w700,
                            ),
                      ),
                    ],
                  ),
                  CustomIconWidget(
                    iconName: impact['icon'] as String,
                    color: impact['color'] as Color,
                    size: 32,
                  ),
                ],
              ),
              SizedBox(height: 2.h),
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: (impact['color'] as Color).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  impact['message'] as String,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: impact['color'] as Color,
                        fontWeight: FontWeight.w500,
                      ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 2.h),
      ],
    );
  }

  Map<String, dynamic> _calculateRequiredClasses(
    int currentAttended,
    int currentTotal,
    double targetPercentage,
  ) {
    if (targetPercentage <= (currentAttended / currentTotal) * 100) {
      return {
        'title': 'Target Already Achieved!',
        'subtitle': 'You can miss some classes and still maintain your target',
        'icon': 'check_circle',
        'color': AppTheme.lightTheme.colorScheme.secondary,
      };
    }

    final requiredAttended = (targetPercentage / 100) * (currentTotal + 1);
    int additionalClasses = 0;
    int totalClasses = currentTotal;
    int attendedClasses = currentAttended;

    while ((attendedClasses / totalClasses) * 100 < targetPercentage) {
      totalClasses++;
      attendedClasses++;
      additionalClasses++;
    }

    if (additionalClasses <= 5) {
      return {
        'title': 'Attend Next $additionalClasses Classes',
        'subtitle': 'Easy to achieve your target percentage',
        'icon': 'trending_up',
        'color': AppTheme.lightTheme.colorScheme.secondary,
      };
    } else if (additionalClasses <= 15) {
      return {
        'title': 'Attend Next $additionalClasses Classes',
        'subtitle': 'Moderate effort required to reach target',
        'icon': 'schedule',
        'color': AppTheme.warningLight,
      };
    } else {
      return {
        'title': 'Attend Next $additionalClasses Classes',
        'subtitle': 'High commitment needed to achieve target',
        'icon': 'warning',
        'color': AppTheme.lightTheme.colorScheme.error,
      };
    }
  }

  Map<String, dynamic> _calculateImpact(
    int currentAttended,
    int currentTotal,
    int plannedAbsences,
  ) {
    final newTotal = currentTotal + plannedAbsences;
    final newPercentage = (currentAttended / newTotal) * 100;

    Color color;
    String icon;
    String message;

    if (newPercentage >= 75) {
      color = AppTheme.lightTheme.colorScheme.secondary;
      icon = 'check_circle';
      message = 'Safe zone - You can afford these absences';
    } else if (newPercentage >= 65) {
      color = AppTheme.warningLight;
      icon = 'warning';
      message = 'Warning zone - Consider attending more classes';
    } else {
      color = AppTheme.lightTheme.colorScheme.error;
      icon = 'error';
      message = 'Critical zone - Avoid these absences';
    }

    return {
      'percentage': newPercentage.toStringAsFixed(1),
      'color': color,
      'icon': icon,
      'message': message,
    };
  }
}
