import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SubjectAttendanceCard extends StatelessWidget {
  final Map<String, dynamic> subject;
  final VoidCallback? onTap;
  final VoidCallback? onViewDetails;
  final VoidCallback? onCalculateProjections;
  final VoidCallback? onSetAlerts;

  const SubjectAttendanceCard({
    Key? key,
    required this.subject,
    this.onTap,
    this.onViewDetails,
    this.onCalculateProjections,
    this.onSetAlerts,
  }) : super(key: key);

  Color _getStatusColor(double percentage) {
    if (percentage >= 75) return AppTheme.lightTheme.colorScheme.secondary;
    if (percentage >= 65) return AppTheme.warningLight;
    return AppTheme.lightTheme.colorScheme.error;
  }

  String _getStatusText(double percentage) {
    if (percentage >= 75) return 'Safe';
    if (percentage >= 65) return 'Warning';
    return 'Critical';
  }

  @override
  Widget build(BuildContext context) {
    final percentage = (subject['percentage'] as num).toDouble();
    final attended = subject['attended'] as int;
    final total = subject['total'] as int;
    final statusColor = _getStatusColor(percentage);
    final statusText = _getStatusText(percentage);

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: statusColor.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: EdgeInsets.all(4.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          subject['name'] as String,
                          style:
                              Theme.of(context).textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(height: 0.5.h),
                        Text(
                          subject['code'] as String,
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: AppTheme.neutralLight,
                                  ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                    decoration: BoxDecoration(
                      color: statusColor.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: statusColor.withValues(alpha: 0.3),
                        width: 1,
                      ),
                    ),
                    child: Text(
                      statusText,
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                            color: statusColor,
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 2.h),
              Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${percentage.toStringAsFixed(1)}%',
                          style: Theme.of(context)
                              .textTheme
                              .headlineSmall
                              ?.copyWith(
                                color: statusColor,
                                fontWeight: FontWeight.w700,
                              ),
                        ),
                        SizedBox(height: 0.5.h),
                        Text(
                          '$attended / $total classes',
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: AppTheme.neutralLight,
                                  ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 3,
                    child: Column(
                      children: [
                        LinearProgressIndicator(
                          value: percentage / 100,
                          backgroundColor: statusColor.withValues(alpha: 0.2),
                          valueColor:
                              AlwaysStoppedAnimation<Color>(statusColor),
                          minHeight: 1.h,
                        ),
                        SizedBox(height: 1.h),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _buildActionButton(
                              context,
                              'Details',
                              CustomIconWidget(
                                iconName: 'info_outline',
                                color: AppTheme.lightTheme.colorScheme.primary,
                                size: 16,
                              ),
                              onViewDetails,
                            ),
                            _buildActionButton(
                              context,
                              'Calculate',
                              CustomIconWidget(
                                iconName: 'calculate',
                                color: AppTheme.lightTheme.colorScheme.primary,
                                size: 16,
                              ),
                              onCalculateProjections,
                            ),
                            _buildActionButton(
                              context,
                              'Alerts',
                              CustomIconWidget(
                                iconName: 'notifications_outlined',
                                color: AppTheme.lightTheme.colorScheme.primary,
                                size: 16,
                              ),
                              onSetAlerts,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton(
    BuildContext context,
    String label,
    Widget icon,
    VoidCallback? onPressed,
  ) {
    return InkWell(
      onTap: onPressed,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            icon,
            SizedBox(height: 0.3.h),
            Text(
              label,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.primary,
                    fontSize: 9.sp,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
