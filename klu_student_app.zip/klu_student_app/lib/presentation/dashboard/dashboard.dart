import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/attendance_summary_card_widget.dart';
import './widgets/dashboard_tab_bar_widget.dart';
import './widgets/greeting_header_widget.dart';
import './widgets/quick_actions_card_widget.dart';
import './widgets/recent_grades_card_widget.dart';
import './widgets/upcoming_events_card_widget.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({Key? key}) : super(key: key);

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> with TickerProviderStateMixin {
  late TabController _tabController;
  bool _isDarkMode = false;
  bool _isLoading = false;
  DateTime _lastSynced = DateTime.now();

  // Mock data
  final Map<String, dynamic> _studentData = {
    "name": "Arjun Krishnan",
    "semester": "Semester 7 - B.Tech CSE",
    "rollNumber": "99220041234",
    "attendancePercentage": 87.5,
    "attendanceTrend": "up",
  };

  final List<Map<String, dynamic>> _recentGrades = [
    {
      "subject": "Machine Learning",
      "examType": "Mid Term",
      "grade": "A",
      "marks": 85,
      "totalMarks": 100,
      "date": DateTime.now().subtract(const Duration(days: 3)),
    },
    {
      "subject": "Database Systems",
      "examType": "Assignment 2",
      "grade": "B+",
      "marks": 78,
      "totalMarks": 100,
      "date": DateTime.now().subtract(const Duration(days: 7)),
    },
    {
      "subject": "Software Engineering",
      "examType": "Quiz 3",
      "grade": "A+",
      "marks": 95,
      "totalMarks": 100,
      "date": DateTime.now().subtract(const Duration(days: 10)),
    },
  ];

  final List<Map<String, dynamic>> _upcomingEvents = [
    {
      "title": "Machine Learning Final Exam",
      "type": "exam",
      "date": DateTime.now().add(const Duration(days: 5)),
      "location": "Main Block - Room 301",
    },
    {
      "title": "Database Project Submission",
      "type": "assignment",
      "date": DateTime.now().add(const Duration(days: 8)),
      "location": "Online Portal",
    },
    {
      "title": "Tech Fest 2024",
      "type": "event",
      "date": DateTime.now().add(const Duration(days: 15)),
      "location": "University Campus",
    },
  ];

  final List<Map<String, dynamic>> _quickActions = [
    {
      "title": "Attendance Calculator",
      "icon": "calculate",
      "type": "attendance",
      "route": "/attendance-tracker",
    },
    {
      "title": "View Grades",
      "icon": "grade",
      "type": "grades",
      "route": "/grades-marks",
    },
    {
      "title": "Student Profile",
      "icon": "person",
      "type": "profile",
      "route": "/student-profile",
    },
    {
      "title": "Settings",
      "icon": "settings",
      "type": "settings",
      "route": "/about-settings",
    },
  ];

  final List<Map<String, dynamic>> _tabData = [
    {"label": "Dashboard", "icon": "dashboard"},
    {"label": "Attendance", "icon": "calendar_today"},
    {"label": "Grades", "icon": "grade"},
    {"label": "Profile", "icon": "person"},
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _tabData.length, vsync: this);
    _loadInitialData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadInitialData() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate API call
    await Future.delayed(const Duration(seconds: 1));

    setState(() {
      _isLoading = false;
      _lastSynced = DateTime.now();
    });
  }

  Future<void> _refreshData() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate refresh API call
    await Future.delayed(const Duration(seconds: 2));

    setState(() {
      _isLoading = false;
      _lastSynced = DateTime.now();
    });
  }

  void _toggleTheme() {
    setState(() {
      _isDarkMode = !_isDarkMode;
    });
  }

  void _navigateToAttendanceCalculator() {
    Navigator.pushNamed(context, '/attendance-tracker');
  }

  void _navigateToGrades() {
    Navigator.pushNamed(context, '/grades-marks');
  }

  void _navigateToProfile() {
    Navigator.pushNamed(context, '/student-profile');
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // Greeting Header
            GreetingHeaderWidget(
              studentName: (_studentData["name"] as String?) ?? "Student",
              currentSemester:
                  (_studentData["semester"] as String?) ?? "Current Semester",
              onThemeToggle: _toggleTheme,
              isDarkMode: _isDarkMode,
            ),

            // Tab Bar
            DashboardTabBarWidget(
              tabController: _tabController,
              tabs: _tabData,
            ),

            // Tab Bar View
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildDashboardTab(),
                  _buildAttendanceTab(),
                  _buildGradesTab(),
                  _buildProfileTab(),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: _tabController.index == 0
          ? FloatingActionButton(
              onPressed: _navigateToAttendanceCalculator,
              backgroundColor: theme.colorScheme.primary,
              child: CustomIconWidget(
                iconName: 'calculate',
                color: Colors.white,
                size: 6.w,
              ),
            )
          : null,
    );
  }

  Widget _buildDashboardTab() {
    final theme = Theme.of(context);

    return RefreshIndicator(
      onRefresh: _refreshData,
      color: theme.colorScheme.primary,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Last synced info
            if (!_isLoading) ...[
              Row(
                children: [
                  CustomIconWidget(
                    iconName: 'sync',
                    color: theme.colorScheme.onSurfaceVariant,
                    size: 4.w,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Last synced: ${_formatLastSynced(_lastSynced)}',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 3.h),
            ],

            // Loading indicator
            if (_isLoading) ...[
              Center(
                child: Column(
                  children: [
                    CircularProgressIndicator(
                      color: theme.colorScheme.primary,
                    ),
                    SizedBox(height: 2.h),
                    Text(
                      'Syncing data...',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 4.h),
            ],

            // Attendance Summary Card
            AttendanceSummaryCardWidget(
              attendancePercentage:
                  (_studentData["attendancePercentage"] as num?)?.toDouble() ??
                      0.0,
              trendIndicator:
                  (_studentData["attendanceTrend"] as String?) ?? "flat",
              onTap: _navigateToAttendanceCalculator,
            ),

            SizedBox(height: 3.h),

            // Recent Grades Card
            RecentGradesCardWidget(
              recentGrades: _recentGrades,
              onTap: _navigateToGrades,
            ),

            SizedBox(height: 3.h),

            // Upcoming Events Card
            UpcomingEventsCardWidget(
              upcomingEvents: _upcomingEvents,
              onTap: () {
                // Navigate to events/calendar page
              },
            ),

            SizedBox(height: 3.h),

            // Quick Actions Card
            QuickActionsCardWidget(
              quickActions: _quickActions,
            ),

            SizedBox(height: 10.h), // Extra space for FAB
          ],
        ),
      ),
    );
  }

  Widget _buildAttendanceTab() {
    final theme = Theme.of(context);

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'calendar_today',
            color: theme.colorScheme.primary,
            size: 15.w,
          ),
          SizedBox(height: 2.h),
          Text(
            'Attendance Tracker',
            style: theme.textTheme.headlineSmall?.copyWith(
              color: theme.colorScheme.onSurface,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Track your attendance and calculate projections',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 3.h),
          ElevatedButton(
            onPressed: _navigateToAttendanceCalculator,
            child: const Text('Open Attendance Tracker'),
          ),
        ],
      ),
    );
  }

  Widget _buildGradesTab() {
    final theme = Theme.of(context);

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'grade',
            color: theme.colorScheme.secondary,
            size: 15.w,
          ),
          SizedBox(height: 2.h),
          Text(
            'Grades & Marks',
            style: theme.textTheme.headlineSmall?.copyWith(
              color: theme.colorScheme.onSurface,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'View your academic performance and grades',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 3.h),
          ElevatedButton(
            onPressed: _navigateToGrades,
            child: const Text('View Grades'),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileTab() {
    final theme = Theme.of(context);

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'person',
            color: theme.colorScheme.tertiary,
            size: 15.w,
          ),
          SizedBox(height: 2.h),
          Text(
            'Student Profile',
            style: theme.textTheme.headlineSmall?.copyWith(
              color: theme.colorScheme.onSurface,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'View and manage your profile information',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 3.h),
          ElevatedButton(
            onPressed: _navigateToProfile,
            child: const Text('View Profile'),
          ),
        ],
      ),
    );
  }

  String _formatLastSynced(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }
}
