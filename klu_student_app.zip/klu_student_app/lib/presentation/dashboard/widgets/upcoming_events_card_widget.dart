import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class UpcomingEventsCardWidget extends StatelessWidget {
  final List<Map<String, dynamic>> upcomingEvents;
  final VoidCallback onTap;

  const UpcomingEventsCardWidget({
    Key? key,
    required this.upcomingEvents,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: theme.cardColor,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: theme.colorScheme.shadow.withValues(alpha: 0.08),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.tertiary.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: CustomIconWidget(
                    iconName: 'event',
                    color: theme.colorScheme.tertiary,
                    size: 5.w,
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Upcoming Events',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: theme.colorScheme.onSurface,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        'Academic Calendar',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                CustomIconWidget(
                  iconName: 'arrow_forward_ios',
                  color: theme.colorScheme.onSurfaceVariant,
                  size: 4.w,
                ),
              ],
            ),
            SizedBox(height: 3.h),
            upcomingEvents.isEmpty
                ? Container(
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(vertical: 3.h),
                    child: Column(
                      children: [
                        CustomIconWidget(
                          iconName: 'event_available',
                          color: theme.colorScheme.onSurfaceVariant
                              .withValues(alpha: 0.5),
                          size: 8.w,
                        ),
                        SizedBox(height: 1.h),
                        Text(
                          'No upcoming events',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  )
                : Column(
                    children: (upcomingEvents.take(3).toList())
                        .map((event) => _buildEventItem(context, event))
                        .toList(),
                  ),
          ],
        ),
      ),
    );
  }

  Widget _buildEventItem(BuildContext context, Map<String, dynamic> event) {
    final theme = Theme.of(context);
    final eventDate = event["date"] as DateTime?;
    final daysUntil =
        eventDate != null ? eventDate.difference(DateTime.now()).inDays : 0;

    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      child: Row(
        children: [
          Container(
            width: 12.w,
            height: 12.w,
            decoration: BoxDecoration(
              color: _getEventTypeColor(event["type"] as String? ?? "general")
                  .withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  eventDate?.day.toString() ?? "?",
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: _getEventTypeColor(
                        event["type"] as String? ?? "general"),
                  ),
                ),
                Text(
                  _getMonthAbbreviation(eventDate?.month ?? 1),
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: _getEventTypeColor(
                        event["type"] as String? ?? "general"),
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  (event["title"] as String?) ?? "Unknown Event",
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                    color: theme.colorScheme.onSurface,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
                SizedBox(height: 0.5.h),
                Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'access_time',
                      color: theme.colorScheme.onSurfaceVariant,
                      size: 3.w,
                    ),
                    SizedBox(width: 1.w),
                    Expanded(
                      child: Text(
                        daysUntil == 0
                            ? 'Today'
                            : daysUntil == 1
                                ? 'Tomorrow'
                                : daysUntil > 0
                                    ? 'In $daysUntil days'
                                    : 'Past event',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
            decoration: BoxDecoration(
              color: _getEventTypeColor(event["type"] as String? ?? "general")
                  .withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              _getEventTypeLabel(event["type"] as String? ?? "general"),
              style: theme.textTheme.bodySmall?.copyWith(
                color:
                    _getEventTypeColor(event["type"] as String? ?? "general"),
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _getEventTypeColor(String type) {
    switch (type.toLowerCase()) {
      case 'exam':
        return Colors.red;
      case 'assignment':
        return Colors.orange;
      case 'holiday':
        return Colors.green;
      case 'event':
        return Colors.blue;
      default:
        return Colors.purple;
    }
  }

  String _getEventTypeLabel(String type) {
    switch (type.toLowerCase()) {
      case 'exam':
        return 'Exam';
      case 'assignment':
        return 'Assignment';
      case 'holiday':
        return 'Holiday';
      case 'event':
        return 'Event';
      default:
        return 'General';
    }
  }

  String _getMonthAbbreviation(int month) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return months[month - 1];
  }
}
