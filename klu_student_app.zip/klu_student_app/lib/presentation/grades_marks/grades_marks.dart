import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/analytics_modal_widget.dart';
import './widgets/semester_selector_widget.dart';
import './widgets/subject_card_widget.dart';
import './widgets/summary_card_widget.dart';

class GradesMarks extends StatefulWidget {
  const GradesMarks({Key? key}) : super(key: key);

  @override
  State<GradesMarks> createState() => _GradesMarksState();
}

class _GradesMarksState extends State<GradesMarks> {
  bool _isLoading = false;
  String _selectedSemester = 'Semester 6';
  final Set<int> _selectedSubjects = <int>{};
  bool _isMultiSelectMode = false;
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();

  // Mock data for semesters
  final List<Map<String, dynamic>> _semesters = [
    {
      'name': 'Semester 1',
      'year': '2022-23',
      'isActive': false,
      'gpa': 8.2,
      'credits': 24,
    },
    {
      'name': 'Semester 2',
      'year': '2022-23',
      'isActive': false,
      'gpa': 8.5,
      'credits': 26,
    },
    {
      'name': 'Semester 3',
      'year': '2023-24',
      'isActive': false,
      'gpa': 8.8,
      'credits': 25,
    },
    {
      'name': 'Semester 4',
      'year': '2023-24',
      'isActive': false,
      'gpa': 9.1,
      'credits': 24,
    },
    {
      'name': 'Semester 5',
      'year': '2024-25',
      'isActive': false,
      'gpa': 8.9,
      'credits': 26,
    },
    {
      'name': 'Semester 6',
      'year': '2024-25',
      'isActive': true,
      'gpa': 9.2,
      'credits': 25,
    },
  ];

  // Mock data for subjects
  final List<Map<String, dynamic>> _subjects = [
    {
      'id': 1,
      'name': 'Advanced Database Management Systems',
      'code': 'CS601',
      'credits': 4,
      'grade': 'A+',
      'gpa': 10.0,
      'internalMarks': 48,
      'externalMarks': 92,
      'assignmentScores': [9, 8, 10, 9],
      'attendanceCorrelation': 95.5,
    },
    {
      'id': 2,
      'name': 'Machine Learning',
      'code': 'CS602',
      'credits': 4,
      'grade': 'A',
      'gpa': 9.0,
      'internalMarks': 45,
      'externalMarks': 85,
      'assignmentScores': [8, 9, 8, 9],
      'attendanceCorrelation': 88.2,
    },
    {
      'id': 3,
      'name': 'Software Engineering',
      'code': 'CS603',
      'credits': 3,
      'grade': 'A+',
      'gpa': 10.0,
      'internalMarks': 47,
      'externalMarks': 90,
      'assignmentScores': [10, 9, 10, 8],
      'attendanceCorrelation': 92.8,
    },
    {
      'id': 4,
      'name': 'Computer Networks',
      'code': 'CS604',
      'credits': 4,
      'grade': 'B+',
      'gpa': 8.0,
      'internalMarks': 42,
      'externalMarks': 78,
      'assignmentScores': [7, 8, 8, 7],
      'attendanceCorrelation': 82.1,
    },
    {
      'id': 5,
      'name': 'Artificial Intelligence',
      'code': 'CS605',
      'credits': 4,
      'grade': 'A',
      'gpa': 9.0,
      'internalMarks': 46,
      'externalMarks': 87,
      'assignmentScores': [9, 8, 9, 8],
      'attendanceCorrelation': 90.3,
    },
    {
      'id': 6,
      'name': 'Mobile Application Development',
      'code': 'CS606',
      'credits': 3,
      'grade': 'A+',
      'gpa': 10.0,
      'internalMarks': 49,
      'externalMarks': 94,
      'assignmentScores': [10, 10, 9, 10],
      'attendanceCorrelation': 96.7,
    },
    {
      'id': 7,
      'name': 'Cyber Security',
      'code': 'CS607',
      'credits': 3,
      'grade': 'B+',
      'gpa': 8.0,
      'internalMarks': 41,
      'externalMarks': 76,
      'assignmentScores': [8, 7, 8, 7],
      'attendanceCorrelation': 79.4,
    },
  ];

  List<Map<String, dynamic>> get _filteredSubjects {
    if (_searchQuery.isEmpty) {
      return _subjects;
    }
    return _subjects.where((subject) {
      final name = (subject['name'] as String).toLowerCase();
      final code = (subject['code'] as String).toLowerCase();
      final query = _searchQuery.toLowerCase();
      return name.contains(query) || code.contains(query);
    }).toList();
  }

  double get _cumulativeGPA {
    double totalGradePoints = 0;
    int totalCredits = 0;

    for (final subject in _subjects) {
      final gpa = subject['gpa'] as double;
      final credits = subject['credits'] as int;
      totalGradePoints += gpa * credits;
      totalCredits += credits;
    }

    return totalCredits > 0 ? totalGradePoints / totalCredits : 0.0;
  }

  double get _semesterGPA {
    final currentSemester = _semesters.firstWhere(
      (sem) => sem['name'] == _selectedSemester,
      orElse: () => _semesters.last,
    );
    return (currentSemester['gpa'] as double?) ?? 0.0;
  }

  String get _academicStanding {
    if (_cumulativeGPA >= 9.0) return 'Distinction';
    if (_cumulativeGPA >= 8.0) return 'First Class';
    if (_cumulativeGPA >= 7.0) return 'Second Class';
    if (_cumulativeGPA >= 6.0) return 'Pass';
    return 'Needs Improvement';
  }

  Future<void> _refreshGrades() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate API call
    await Future.delayed(const Duration(seconds: 2));

    setState(() {
      _isLoading = false;
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Grades updated successfully'),
          backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
        ),
      );
    }
  }

  void _toggleSubjectSelection(int subjectId) {
    setState(() {
      if (_selectedSubjects.contains(subjectId)) {
        _selectedSubjects.remove(subjectId);
      } else {
        _selectedSubjects.add(subjectId);
      }

      if (_selectedSubjects.isEmpty) {
        _isMultiSelectMode = false;
      }
    });
  }

  void _enterMultiSelectMode(int subjectId) {
    setState(() {
      _isMultiSelectMode = true;
      _selectedSubjects.add(subjectId);
    });
  }

  void _exitMultiSelectMode() {
    setState(() {
      _isMultiSelectMode = false;
      _selectedSubjects.clear();
    });
  }

  void _showAnalyticsModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => AnalyticsModalWidget(
        semesterData: _semesters,
        subjectData: _subjects,
      ),
    );
  }

  void _shareGrade(Map<String, dynamic> subject) {
    final name = subject['name'] as String;
    final grade = subject['grade'] as String;
    final gpa = subject['gpa'] as double;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            'Sharing grade for $name: $grade (${gpa.toStringAsFixed(2)} GPA)'),
        action: SnackBarAction(
          label: 'Share',
          onPressed: () {
            // Implement actual sharing functionality
          },
        ),
      ),
    );
  }

  void _viewTrends(Map<String, dynamic> subject) {
    final name = subject['name'] as String;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Viewing trends for $name'),
      ),
    );
  }

  void _setGoals(Map<String, dynamic> subject) {
    final name = subject['name'] as String;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Set Improvement Goal'),
        content: Text('Set improvement goals for $name'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Goal set successfully')),
              );
            },
            child: const Text('Set Goal'),
          ),
        ],
      ),
    );
  }

  void _bulkExport() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Exporting ${_selectedSubjects.length} subjects'),
        action: SnackBarAction(
          label: 'Export',
          onPressed: () {
            _exitMultiSelectMode();
          },
        ),
      ),
    );
  }

  void _bulkCompare() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Comparing ${_selectedSubjects.length} subjects'),
        action: SnackBarAction(
          label: 'Compare',
          onPressed: () {
            _exitMultiSelectMode();
          },
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline,
        ),
      ),
      child: TextField(
        controller: _searchController,
        decoration: InputDecoration(
          hintText: 'Search subjects...',
          prefixIcon: Padding(
            padding: EdgeInsets.all(3.w),
            child: CustomIconWidget(
              iconName: 'search',
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 20,
            ),
          ),
          suffixIcon: _searchQuery.isNotEmpty
              ? IconButton(
                  onPressed: () {
                    _searchController.clear();
                    setState(() {
                      _searchQuery = '';
                    });
                  },
                  icon: CustomIconWidget(
                    iconName: 'clear',
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    size: 20,
                  ),
                )
              : null,
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
        ),
        onChanged: (value) {
          setState(() {
            _searchQuery = value;
          });
        },
      ),
    );
  }

  Widget _buildMultiSelectActions() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.primaryContainer
            .withValues(alpha: 0.1),
        border: Border(
          top: BorderSide(
            color: AppTheme.lightTheme.colorScheme.outline,
          ),
        ),
      ),
      child: Row(
        children: [
          Text(
            '${_selectedSubjects.length} selected',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const Spacer(),
          TextButton.icon(
            onPressed: _bulkExport,
            icon: CustomIconWidget(
              iconName: 'file_download',
              color: AppTheme.lightTheme.colorScheme.primary,
              size: 18,
            ),
            label: const Text('Export'),
          ),
          SizedBox(width: 2.w),
          TextButton.icon(
            onPressed: _bulkCompare,
            icon: CustomIconWidget(
              iconName: 'compare_arrows',
              color: AppTheme.lightTheme.colorScheme.primary,
              size: 18,
            ),
            label: const Text('Compare'),
          ),
          SizedBox(width: 2.w),
          IconButton(
            onPressed: _exitMultiSelectMode,
            icon: CustomIconWidget(
              iconName: 'close',
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 20,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final totalCredits = _semesters.fold<int>(
      0,
      (sum, semester) => sum + (semester['credits'] as int),
    );
    final completedCredits = _semesters
        .where((sem) => sem['name'] != _selectedSemester)
        .fold<int>(0, (sum, semester) => sum + (semester['credits'] as int));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Grades & Marks'),
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            color: AppTheme.lightTheme.colorScheme.onSurface,
            size: 24,
          ),
        ),
        actions: [
          if (!_isMultiSelectMode)
            IconButton(
              onPressed: () => Navigator.pushNamed(context, '/dashboard'),
              icon: CustomIconWidget(
                iconName: 'home',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          // Semester Selector (Sticky Header)
          SemesterSelectorWidget(
            semesters: _semesters,
            selectedSemester: _selectedSemester,
            onSemesterChanged: (semester) {
              setState(() {
                _selectedSemester = semester;
                _exitMultiSelectMode();
              });
            },
          ),

          // Search Bar
          if (!_isMultiSelectMode) _buildSearchBar(),

          // Multi-select Actions
          if (_isMultiSelectMode) _buildMultiSelectActions(),

          // Content
          Expanded(
            child: RefreshIndicator(
              onRefresh: _refreshGrades,
              child: _isLoading
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircularProgressIndicator(
                            color: AppTheme.lightTheme.colorScheme.primary,
                          ),
                          SizedBox(height: 2.h),
                          Text(
                            'Loading grades...',
                            style: AppTheme.lightTheme.textTheme.bodyMedium,
                          ),
                        ],
                      ),
                    )
                  : CustomScrollView(
                      slivers: [
                        // Summary Card
                        SliverToBoxAdapter(
                          child: SummaryCardWidget(
                            cumulativeGPA: _cumulativeGPA,
                            semesterGPA: _semesterGPA,
                            academicStanding: _academicStanding,
                            totalCredits: totalCredits,
                            completedCredits: completedCredits,
                          ),
                        ),

                        // Subject Cards
                        SliverList(
                          delegate: SliverChildBuilderDelegate(
                            (context, index) {
                              final subject = _filteredSubjects[index];
                              final subjectId = subject['id'] as int;

                              return SubjectCardWidget(
                                subject: subject,
                                isSelected:
                                    _selectedSubjects.contains(subjectId),
                                onTap: _isMultiSelectMode
                                    ? () => _toggleSubjectSelection(subjectId)
                                    : null,
                                onLongPress: _isMultiSelectMode
                                    ? null
                                    : () => _enterMultiSelectMode(subjectId),
                                onShare: () => _shareGrade(subject),
                                onViewTrends: () => _viewTrends(subject),
                                onSetGoals: () => _setGoals(subject),
                              );
                            },
                            childCount: _filteredSubjects.length,
                          ),
                        ),

                        // Bottom Padding
                        SliverToBoxAdapter(
                          child: SizedBox(height: 10.h),
                        ),
                      ],
                    ),
            ),
          ),
        ],
      ),
      floatingActionButton: _isMultiSelectMode
          ? null
          : FloatingActionButton(
              onPressed: _showAnalyticsModal,
              child: CustomIconWidget(
                iconName: 'analytics',
                color: Colors.white,
                size: 24,
              ),
            ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
