import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SubjectCardWidget extends StatefulWidget {
  final Map<String, dynamic> subject;
  final VoidCallback? onTap;
  final VoidCallback? onShare;
  final VoidCallback? onViewTrends;
  final VoidCallback? onSetGoals;
  final bool isSelected;
  final VoidCallback? onLongPress;

  const SubjectCardWidget({
    Key? key,
    required this.subject,
    this.onTap,
    this.onShare,
    this.onViewTrends,
    this.onSetGoals,
    this.isSelected = false,
    this.onLongPress,
  }) : super(key: key);

  @override
  State<SubjectCardWidget> createState() => _SubjectCardWidgetState();
}

class _SubjectCardWidgetState extends State<SubjectCardWidget>
    with SingleTickerProviderStateMixin {
  bool _isExpanded = false;
  late AnimationController _animationController;
  late Animation<double> _expandAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _expandAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Color _getGradeColor(String grade) {
    switch (grade.toUpperCase()) {
      case 'A+':
      case 'A':
        return AppTheme.lightTheme.colorScheme.secondary;
      case 'B+':
      case 'B':
        return AppTheme.lightTheme.colorScheme.primary;
      case 'C+':
      case 'C':
        return Colors.orange;
      case 'D':
      case 'F':
        return AppTheme.lightTheme.colorScheme.error;
      default:
        return AppTheme.lightTheme.colorScheme.onSurfaceVariant;
    }
  }

  Widget _buildGradeIndicator() {
    final grade = widget.subject['grade'] as String? ?? 'N/A';
    final gpa = widget.subject['gpa'] as double? ?? 0.0;

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: _getGradeColor(grade).withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: _getGradeColor(grade),
          width: 1,
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            grade,
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              color: _getGradeColor(grade),
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 0.5.h),
          Text(
            gpa.toStringAsFixed(2),
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: _getGradeColor(grade),
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildExpandedContent() {
    final internalMarks = widget.subject['internalMarks'] as int? ?? 0;
    final externalMarks = widget.subject['externalMarks'] as int? ?? 0;
    final assignmentScores = widget.subject['assignmentScores'] as List? ?? [];
    final attendanceCorrelation =
        widget.subject['attendanceCorrelation'] as double? ?? 0.0;

    return AnimatedBuilder(
      animation: _expandAnimation,
      builder: (context, child) {
        return SizeTransition(
          sizeFactor: _expandAnimation,
          child: Container(
            padding: EdgeInsets.all(4.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Divider(color: AppTheme.lightTheme.colorScheme.outline),
                SizedBox(height: 2.h),

                // Marks Breakdown
                Text(
                  'Marks Breakdown',
                  style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 1.h),

                Row(
                  children: [
                    Expanded(
                      child: _buildMarkItem('Internal', internalMarks, 50),
                    ),
                    SizedBox(width: 4.w),
                    Expanded(
                      child: _buildMarkItem('External', externalMarks, 100),
                    ),
                  ],
                ),

                SizedBox(height: 2.h),

                // Assignment Scores
                if (assignmentScores.isNotEmpty) ...[
                  Text(
                    'Assignment Scores',
                    style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 1.h),
                  Wrap(
                    spacing: 2.w,
                    runSpacing: 1.h,
                    children:
                        (assignmentScores).asMap().entries.map((entry) {
                      final index = entry.key;
                      final score = entry.value as int;
                      return Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 2.w, vertical: 0.5.h),
                        decoration: BoxDecoration(
                          color:
                              AppTheme.lightTheme.colorScheme.primaryContainer,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          'A${index + 1}: $score/10',
                          style: AppTheme.lightTheme.textTheme.bodySmall,
                        ),
                      );
                    }).toList(),
                  ),
                  SizedBox(height: 2.h),
                ],

                // Attendance Correlation
                Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'trending_up',
                      color: attendanceCorrelation >= 75
                          ? AppTheme.lightTheme.colorScheme.secondary
                          : AppTheme.lightTheme.colorScheme.error,
                      size: 16,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Attendance Impact: ${attendanceCorrelation.toStringAsFixed(1)}%',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: attendanceCorrelation >= 75
                            ? AppTheme.lightTheme.colorScheme.secondary
                            : AppTheme.lightTheme.colorScheme.error,
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 2.h),

                // Action Buttons
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildActionButton(
                      icon: 'share',
                      label: 'Share',
                      onTap: widget.onShare,
                    ),
                    _buildActionButton(
                      icon: 'trending_up',
                      label: 'Trends',
                      onTap: widget.onViewTrends,
                    ),
                    _buildActionButton(
                      icon: 'flag',
                      label: 'Goals',
                      onTap: widget.onSetGoals,
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildMarkItem(String label, int marks, int total) {
    final percentage = (marks / total * 100);

    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 0.5.h),
          Text(
            '$marks/$total',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 0.5.h),
          LinearProgressIndicator(
            value: marks / total,
            backgroundColor:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
            valueColor: AlwaysStoppedAnimation<Color>(
              percentage >= 80
                  ? AppTheme.lightTheme.colorScheme.secondary
                  : percentage >= 60
                      ? AppTheme.lightTheme.colorScheme.primary
                      : AppTheme.lightTheme.colorScheme.error,
            ),
          ),
          SizedBox(height: 0.5.h),
          Text(
            '${percentage.toStringAsFixed(1)}%',
            style: AppTheme.lightTheme.textTheme.bodySmall,
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton({
    required String icon,
    required String label,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomIconWidget(
              iconName: icon,
              color: AppTheme.lightTheme.colorScheme.primary,
              size: 20,
            ),
            SizedBox(height: 0.5.h),
            Text(
              label,
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.primary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final subjectName = widget.subject['name'] as String? ?? 'Unknown Subject';
    final credits = widget.subject['credits'] as int? ?? 0;
    final code = widget.subject['code'] as String? ?? '';

    return GestureDetector(
      onTap: () {
        setState(() {
          _isExpanded = !_isExpanded;
          if (_isExpanded) {
            _animationController.forward();
          } else {
            _animationController.reverse();
          }
        });
        widget.onTap?.call();
      },
      onLongPress: widget.onLongPress,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        decoration: BoxDecoration(
          color: widget.isSelected
              ? AppTheme.lightTheme.colorScheme.primaryContainer
                  .withValues(alpha: 0.3)
              : AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: widget.isSelected
                ? AppTheme.lightTheme.colorScheme.primary
                : AppTheme.lightTheme.colorScheme.outline,
            width: widget.isSelected ? 2 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: AppTheme.lightTheme.colorScheme.shadow,
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.all(4.w),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          subjectName,
                          style: AppTheme.lightTheme.textTheme.titleMedium
                              ?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        if (code.isNotEmpty) ...[
                          SizedBox(height: 0.5.h),
                          Text(
                            code,
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                        SizedBox(height: 1.h),
                        Row(
                          children: [
                            CustomIconWidget(
                              iconName: 'school',
                              color: AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                              size: 16,
                            ),
                            SizedBox(width: 1.w),
                            Text(
                              '$credits Credits',
                              style: AppTheme.lightTheme.textTheme.bodySmall
                                  ?.copyWith(
                                color: AppTheme
                                    .lightTheme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 4.w),
                  _buildGradeIndicator(),
                  SizedBox(width: 2.w),
                  CustomIconWidget(
                    iconName: _isExpanded ? 'expand_less' : 'expand_more',
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    size: 24,
                  ),
                ],
              ),
            ),
            if (_isExpanded) _buildExpandedContent(),
          ],
        ),
      ),
    );
  }
}
