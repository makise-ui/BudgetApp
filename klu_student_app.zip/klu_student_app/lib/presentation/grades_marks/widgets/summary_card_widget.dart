import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SummaryCardWidget extends StatelessWidget {
  final double cumulativeGPA;
  final double semesterGPA;
  final String academicStanding;
  final int totalCredits;
  final int completedCredits;

  const SummaryCardWidget({
    Key? key,
    required this.cumulativeGPA,
    required this.semesterGPA,
    required this.academicStanding,
    required this.totalCredits,
    required this.completedCredits,
  }) : super(key: key);

  Color _getStandingColor(String standing) {
    switch (standing.toLowerCase()) {
      case 'excellent':
      case 'distinction':
        return AppTheme.lightTheme.colorScheme.secondary;
      case 'good':
      case 'first class':
        return AppTheme.lightTheme.colorScheme.primary;
      case 'satisfactory':
      case 'second class':
        return Colors.orange;
      case 'needs improvement':
      case 'pass':
        return AppTheme.lightTheme.colorScheme.error;
      default:
        return AppTheme.lightTheme.colorScheme.onSurfaceVariant;
    }
  }

  Widget _buildGPAIndicator(String label, double gpa, {bool isMain = false}) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: isMain
            ? AppTheme.lightTheme.colorScheme.primaryContainer
                .withValues(alpha: 0.1)
            : AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isMain
              ? AppTheme.lightTheme.colorScheme.primary
              : AppTheme.lightTheme.colorScheme.outline,
          width: isMain ? 2 : 1,
        ),
      ),
      child: Column(
        children: [
          Text(
            label,
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              fontWeight: FontWeight.w500,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 1.h),
          Text(
            gpa.toStringAsFixed(2),
            style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
              color: isMain
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.onSurface,
              fontWeight: FontWeight.w700,
            ),
          ),
          SizedBox(height: 0.5.h),
          Text(
            '/ 10.0',
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 1.h),
          LinearProgressIndicator(
            value: gpa / 10.0,
            backgroundColor:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
            valueColor: AlwaysStoppedAnimation<Color>(
              gpa >= 8.5
                  ? AppTheme.lightTheme.colorScheme.secondary
                  : gpa >= 7.0
                      ? AppTheme.lightTheme.colorScheme.primary
                      : gpa >= 6.0
                          ? Colors.orange
                          : AppTheme.lightTheme.colorScheme.error,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressIndicator() {
    final progress = completedCredits / totalCredits;

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Credit Progress',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                '$completedCredits / $totalCredits',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.primary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          LinearProgressIndicator(
            value: progress,
            backgroundColor:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
            valueColor: AlwaysStoppedAnimation<Color>(
              AppTheme.lightTheme.colorScheme.primary,
            ),
            minHeight: 8,
          ),
          SizedBox(height: 1.h),
          Text(
            '${(progress * 100).toStringAsFixed(1)}% Complete',
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(4.w),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.lightTheme.colorScheme.shadow,
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'analytics',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 24,
              ),
              SizedBox(width: 3.w),
              Text(
                'Academic Summary',
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),

          // GPA Indicators
          Row(
            children: [
              Expanded(
                child: _buildGPAIndicator('Cumulative GPA', cumulativeGPA,
                    isMain: true),
              ),
              SizedBox(width: 4.w),
              Expanded(
                child: _buildGPAIndicator('Semester GPA', semesterGPA),
              ),
            ],
          ),

          SizedBox(height: 3.h),

          // Academic Standing
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: _getStandingColor(academicStanding).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: _getStandingColor(academicStanding),
              ),
            ),
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'emoji_events',
                  color: _getStandingColor(academicStanding),
                  size: 20,
                ),
                SizedBox(width: 3.w),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Academic Standing',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    Text(
                      academicStanding,
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        color: _getStandingColor(academicStanding),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          SizedBox(height: 3.h),

          // Credit Progress
          _buildProgressIndicator(),
        ],
      ),
    );
  }
}
