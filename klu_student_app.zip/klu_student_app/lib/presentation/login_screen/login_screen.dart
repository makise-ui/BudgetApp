import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../theme/app_theme.dart';
import '../../widgets/custom_icon_widget.dart';
import '../../widgets/custom_image_widget.dart';
import '../../services/klu_auth_service.dart';
import './widgets/biometric_prompt_widget.dart';
import './widgets/endpoint_selector_widget.dart';
import './widgets/login_form_widget.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with TickerProviderStateMixin {
  // Controllers
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final FocusNode _usernameFocus = FocusNode();
  final FocusNode _passwordFocus = FocusNode();

  // State variables
  bool _isPasswordVisible = false;
  bool _rememberMe = false;
  bool _isLoading = false;
  bool _showAdvancedOptions = false;
  bool _showBiometricPrompt = false;
  LoginEndpoint _selectedEndpoint = LoginEndpoint.primary;

  // Animation controllers
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // Services
  final KLUAuthService _authService = KLUAuthService();

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _loadSavedCredentials();
    _checkBiometricAvailability();
    _checkAutoLogin();
  }

  void _initializeAnimations() {
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic),
    );

    _fadeController.forward();
    _slideController.forward();
  }

  Future<void> _loadSavedCredentials() async {
    try {
      final credentials = await _authService.getSavedCredentials();
      if (credentials != null && mounted) {
        setState(() {
          _usernameController.text = credentials['username'] ?? '';
          _rememberMe = true;
        });
      }
    } catch (e) {
      print('Error loading saved credentials: $e');
    }
  }

  void _checkBiometricAvailability() {
    // Check if biometric authentication should be shown
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        setState(() {
          _showBiometricPrompt = false; // Will be shown after successful login
        });
      }
    });
  }

  Future<void> _checkAutoLogin() async {
    try {
      final isLoggedIn = await _authService.isLoggedIn();
      if (isLoggedIn && mounted) {
        // Check if we should attempt auto-login
        final result = await _authService.autoLogin();
        if (result.success) {
          _navigateToDashboard();
        }
      }
    } catch (e) {
      print('Auto login check error: $e');
    }
  }

  Future<void> _handleLogin() async {
    if (_isLoading) return;

    // Validate input
    final username = _usernameController.text.trim();
    final password = _passwordController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      _showErrorMessage('Please enter both username and password');
      return;
    }

    // Dismiss keyboard
    FocusScope.of(context).unfocus();

    setState(() {
      _isLoading = true;
    });

    try {
      // Show connectivity test in debug mode
      final connectivity = await _authService.testEndpointsConnectivity();
      print('Endpoint connectivity: $connectivity');

      // Attempt login with real authentication
      final result = await _authService.login(
        username: username,
        password: password,
        endpoint: _selectedEndpoint,
        autoFallback: true,
      );

      if (result.success) {
        // Success - trigger haptic feedback
        HapticFeedback.vibrate();

        // Save credentials if remember me is checked
        if (_rememberMe) {
          // Credentials are automatically saved by auth service
          print('Credentials saved successfully');
        }

        // Show success message with student data
        if (result.studentData != null) {
          _showSuccessMessage('Welcome, ${result.studentData!.name}!');
        }

        // Show biometric prompt for first-time users
        await Future.delayed(const Duration(seconds: 1));
        if (!_showBiometricPrompt && mounted) {
          setState(() {
            _showBiometricPrompt = true;
          });
          return;
        }

        // Navigate to dashboard
        _navigateToDashboard();
      } else {
        // Login failed
        HapticFeedback.vibrate();
        _showErrorMessage(
          result.error ?? 'Login failed. Please check your credentials.',
        );
      }
    } catch (e) {
      // Network or other error
      HapticFeedback.vibrate();
      _showErrorMessage('Network error: ${e.toString()}');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showErrorMessage(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: AppTheme.lightTheme.colorScheme.error,
      textColor: Colors.white,
      fontSize: 14.sp,
    );
  }

  void _showSuccessMessage(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.green,
      textColor: Colors.white,
      fontSize: 14.sp,
    );
  }

  void _handleForgotPassword() {
    // Open institutional password recovery
    final message =
        _selectedEndpoint == LoginEndpoint.primary
            ? 'Please visit sis.kalasalingam.ac.in to reset your password'
            : 'Please visit student.kalasalingam.ac.in to reset your password';

    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _handleBiometricSetup() {
    // Setup biometric authentication
    HapticFeedback.lightImpact();
    setState(() {
      _showBiometricPrompt = false;
    });
    _navigateToDashboard();
  }

  void _skipBiometricSetup() {
    setState(() {
      _showBiometricPrompt = false;
    });
    _navigateToDashboard();
  }

  void _navigateToDashboard() {
    Navigator.pushReplacementNamed(context, '/dashboard');
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    _usernameFocus.dispose();
    _passwordFocus.dispose();
    _fadeController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Stack(
          children: [
            // Main Login Content
            GestureDetector(
              onTap: () => FocusScope.of(context).unfocus(),
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 6.w),
                child: FadeTransition(
                  opacity: _fadeAnimation,
                  child: SlideTransition(
                    position: _slideAnimation,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        SizedBox(height: 8.h),

                        // KLU Logo
                        Center(
                          child: Container(
                            width: 30.w,
                            height: 30.w,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(4.w),
                              boxShadow: [
                                BoxShadow(
                                  color: AppTheme.lightTheme.colorScheme.shadow
                                      .withValues(alpha: 0.1),
                                  blurRadius: 12,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(4.w),
                              child: CustomImageWidget(
                                imageUrl:
                                    'https://i.ibb.co/tMV2FVBx/logo-1.png',
                                width: 30.w,
                                height: 30.w,
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 4.h),

                        // Welcome Text
                        Text(
                          'Welcome to KLU',
                          style: Theme.of(
                            context,
                          ).textTheme.headlineMedium?.copyWith(
                            fontWeight: FontWeight.w700,
                            color: AppTheme.lightTheme.colorScheme.onSurface,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: 1.h),
                        Text(
                          'Sign in to access your student portal',
                          style: Theme.of(
                            context,
                          ).textTheme.bodyLarge?.copyWith(
                            color:
                                AppTheme
                                    .lightTheme
                                    .colorScheme
                                    .onSurfaceVariant,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: 5.h),

                        // Login Form
                        LoginFormWidget(
                          usernameController: _usernameController,
                          passwordController: _passwordController,
                          isPasswordVisible: _isPasswordVisible,
                          rememberMe: _rememberMe,
                          isLoading: _isLoading,
                          onPasswordVisibilityToggle: () {
                            setState(() {
                              _isPasswordVisible = !_isPasswordVisible;
                            });
                          },
                          onRememberMeChanged: (value) {
                            setState(() {
                              _rememberMe = value ?? false;
                            });
                          },
                          onLogin: _handleLogin,
                          onForgotPassword: _handleForgotPassword,
                        ),
                        SizedBox(height: 3.h),

                        // Endpoint Selector
                        EndpointSelectorWidget(
                          selectedEndpoint: _selectedEndpoint,
                          showAdvancedOptions: _showAdvancedOptions,
                          onEndpointChanged: (endpoint) {
                            setState(() {
                              _selectedEndpoint = endpoint;
                            });
                          },
                          onToggleAdvancedOptions: () {
                            setState(() {
                              _showAdvancedOptions = !_showAdvancedOptions;
                            });
                          },
                        ),
                        SizedBox(height: 4.h),

                        // Connection Status Info
                        Container(
                          padding: EdgeInsets.all(4.w),
                          decoration: BoxDecoration(
                            color: AppTheme
                                .lightTheme
                                .colorScheme
                                .primaryContainer
                                .withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(2.w),
                            border: Border.all(
                              color: AppTheme.lightTheme.primaryColor
                                  .withValues(alpha: 0.2),
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  CustomIconWidget(
                                    iconName: 'info',
                                    color: AppTheme.lightTheme.primaryColor,
                                    size: 4.w,
                                  ),
                                  SizedBox(width: 2.w),
                                  Text(
                                    'Real KLU Authentication',
                                    style: Theme.of(
                                      context,
                                    ).textTheme.titleSmall?.copyWith(
                                      color: AppTheme.lightTheme.primaryColor,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 1.h),
                              Text(
                                'This app connects to the real KLU student information systems. Use your official KLU Student ID and password to login.',
                                style: Theme.of(
                                  context,
                                ).textTheme.bodySmall?.copyWith(
                                  color: AppTheme.lightTheme.primaryColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 4.h),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            // Biometric Prompt Overlay
            if (_showBiometricPrompt)
              Container(
                color: Colors.black.withValues(alpha: 0.5),
                child: Center(
                  child: BiometricPromptWidget(
                    isAvailable: true,
                    onEnableBiometric: _handleBiometricSetup,
                    onSkip: _skipBiometricSetup,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}