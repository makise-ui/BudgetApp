import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../services/klu_auth_service.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

enum LoginEndpoint { primary, fallback }

class EndpointSelectorWidget extends StatelessWidget {
  final LoginEndpoint selectedEndpoint;
  final ValueChanged<LoginEndpoint> onEndpointChanged;
  final bool showAdvancedOptions;
  final VoidCallback onToggleAdvancedOptions;

  const EndpointSelectorWidget({
    Key? key,
    required this.selectedEndpoint,
    required this.onEndpointChanged,
    required this.showAdvancedOptions,
    required this.onToggleAdvancedOptions,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Advanced Options Toggle
        TextButton.icon(
          onPressed: onToggleAdvancedOptions,
          icon: CustomIconWidget(
            iconName: showAdvancedOptions ? 'expand_less' : 'expand_more',
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 4.w,
          ),
          label: Text(
            'Advanced Options',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
        ),

        // Endpoint Selection (shown when advanced options are expanded)
        if (showAdvancedOptions) ...[
          SizedBox(height: 1.h),
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(2.w),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline.withValues(
                  alpha: 0.2,
                ),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Login Endpoint',
                  style: Theme.of(
                    context,
                  ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
                ),
                SizedBox(height: 1.h),

                // Primary Endpoint Option
                RadioListTile<LoginEndpoint>(
                  value: LoginEndpoint.primary,
                  groupValue: selectedEndpoint,
                  onChanged: (value) {
                    if (value != null) {
                      onEndpointChanged(value);
                    }
                  },
                  title: Text(
                    'SIS Portal (Primary)',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  subtitle: Text(
                    'sis.kalasalingam.ac.in',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                ),

                // Fallback Endpoint Option
                RadioListTile<LoginEndpoint>(
                  value: LoginEndpoint.fallback,
                  groupValue: selectedEndpoint,
                  onChanged: (value) {
                    if (value != null) {
                      onEndpointChanged(value);
                    }
                  },
                  title: Text(
                    'Student Portal (Fallback)',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  subtitle: Text(
                    'student.kalasalingam.ac.in',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                ),

                SizedBox(height: 1.h),
                Container(
                  padding: EdgeInsets.all(3.w),
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.primaryContainer
                        .withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(1.w),
                  ),
                  child: Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'info',
                        color: AppTheme.lightTheme.primaryColor,
                        size: 4.w,
                      ),
                      SizedBox(width: 2.w),
                      Expanded(
                        child: Text(
                          'Auto-fallback is enabled by default. Manual selection is for advanced users only.',
                          style: Theme.of(
                            context,
                          ).textTheme.bodySmall?.copyWith(
                            color: AppTheme.lightTheme.primaryColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}
