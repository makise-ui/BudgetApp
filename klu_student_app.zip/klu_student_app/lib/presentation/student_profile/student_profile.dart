import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/photo_options_bottom_sheet.dart';
import './widgets/profile_header_widget.dart';
import './widgets/profile_info_card_widget.dart';
import './widgets/quick_actions_widget.dart';

class StudentProfile extends StatefulWidget {
  const StudentProfile({Key? key}) : super(key: key);

  @override
  State<StudentProfile> createState() => _StudentProfileState();
}

class _StudentProfileState extends State<StudentProfile> {
  bool _isLoading = false;
  bool _isOfflineMode = false;

  // Mock student data
  final Map<String, dynamic> _studentData = {
    "name": "Arjun Krishnamurthy",
    "studentId": "KLU2021CS001",
    "program": "B.Tech Computer Science",
    "batch": "2021-2025",
    "profilePhoto":
        "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400",
    "email": "arjun.krishnamurthy@klu.ac.in",
    "phone": "+91 9876543210",
    "address": "123 Tech Street, Anantapur, Andhra Pradesh 515003",
    "department": "Computer Science & Engineering",
    "advisor": "Dr. Priya Sharma",
    "enrollmentStatus": "Active",
    "emergencyContact1": "Rajesh Krishnamurthy - +91 9876543211",
    "emergencyContact2": "Meera Krishnamurthy - +91 9876543212",
    "dateOfBirth": "15/08/2003",
    "bloodGroup": "O+",
    "nationality": "Indian",
    "category": "General",
    "admissionYear": "2021",
    "currentSemester": "6th Semester",
    "cgpa": "8.75",
    "lastUpdated": "26/08/2025 10:10 AM"
  };

  @override
  void initState() {
    super.initState();
    _loadProfileData();
  }

  Future<void> _loadProfileData() async {
    setState(() => _isLoading = true);

    // Simulate API call
    await Future.delayed(Duration(seconds: 1));

    setState(() {
      _isLoading = false;
      _isOfflineMode = false; // Set to true if offline
    });
  }

  Future<void> _refreshProfile() async {
    await _loadProfileData();
  }

  void _showPhotoOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => PhotoOptionsBottomSheet(
        hasPhoto: (_studentData['profilePhoto'] as String?)?.isNotEmpty == true,
        onTakePhoto: _takePhoto,
        onChooseFromGallery: _chooseFromGallery,
        onRemovePhoto: _removePhoto,
      ),
    );
  }

  void _takePhoto() {
    // Camera functionality would be implemented here
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Camera functionality will be implemented')),
    );
  }

  void _chooseFromGallery() {
    // Gallery selection would be implemented here
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Gallery selection will be implemented')),
    );
  }

  void _removePhoto() {
    setState(() {
      _studentData['profilePhoto'] = '';
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Profile photo removed')),
    );
  }

  void _downloadIdCard() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            ),
            SizedBox(width: 4.w),
            Text('Downloading ID Card...'),
          ],
        ),
      ),
    );
  }

  void _downloadTranscript() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            ),
            SizedBox(width: 4.w),
            Text('Downloading Academic Transcript...'),
          ],
        ),
      ),
    );
  }

  void _downloadFeeReceipt() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            ),
            SizedBox(width: 4.w),
            Text('Downloading Fee Receipt...'),
          ],
        ),
      ),
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Logout'),
        content: Text('Are you sure you want to logout from your account?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushNamedAndRemoveUntil(
                context,
                '/login-screen',
                (route) => false,
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: Text('Logout', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  List<Map<String, dynamic>> _getPersonalDetailsFields() {
    return [
      {
        'label': 'Full Name',
        'value': _studentData['name'] as String? ?? 'N/A',
        'editable': false,
      },
      {
        'label': 'Student ID',
        'value': _studentData['studentId'] as String? ?? 'N/A',
        'editable': false,
      },
      {
        'label': 'Date of Birth',
        'value': _studentData['dateOfBirth'] as String? ?? 'N/A',
        'editable': false,
      },
      {
        'label': 'Blood Group',
        'value': _studentData['bloodGroup'] as String? ?? 'N/A',
        'editable': false,
      },
      {
        'label': 'Nationality',
        'value': _studentData['nationality'] as String? ?? 'N/A',
        'editable': false,
      },
      {
        'label': 'Category',
        'value': _studentData['category'] as String? ?? 'N/A',
        'editable': false,
      },
    ];
  }

  List<Map<String, dynamic>> _getContactInfoFields() {
    return [
      {
        'label': 'Email',
        'value': _studentData['email'] as String? ?? 'N/A',
        'editable': true,
      },
      {
        'label': 'Phone',
        'value': _studentData['phone'] as String? ?? 'N/A',
        'editable': true,
      },
      {
        'label': 'Address',
        'value': _studentData['address'] as String? ?? 'N/A',
        'editable': true,
      },
    ];
  }

  List<Map<String, dynamic>> _getAcademicDetailsFields() {
    return [
      {
        'label': 'Program',
        'value': _studentData['program'] as String? ?? 'N/A',
        'editable': false,
      },
      {
        'label': 'Batch',
        'value': _studentData['batch'] as String? ?? 'N/A',
        'editable': false,
      },
      {
        'label': 'Department',
        'value': _studentData['department'] as String? ?? 'N/A',
        'editable': false,
      },
      {
        'label': 'Academic Advisor',
        'value': _studentData['advisor'] as String? ?? 'N/A',
        'editable': false,
      },
      {
        'label': 'Current Semester',
        'value': _studentData['currentSemester'] as String? ?? 'N/A',
        'editable': false,
      },
      {
        'label': 'CGPA',
        'value': _studentData['cgpa'] as String? ?? 'N/A',
        'editable': false,
      },
      {
        'label': 'Enrollment Status',
        'value': _studentData['enrollmentStatus'] as String? ?? 'N/A',
        'editable': false,
      },
    ];
  }

  List<Map<String, dynamic>> _getEmergencyContactsFields() {
    return [
      {
        'label': 'Primary Contact',
        'value': _studentData['emergencyContact1'] as String? ?? 'N/A',
        'editable': true,
      },
      {
        'label': 'Secondary Contact',
        'value': _studentData['emergencyContact2'] as String? ?? 'N/A',
        'editable': true,
      },
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text('Student Profile'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          if (_isOfflineMode)
            Container(
              margin: EdgeInsets.only(right: 2.w),
              child: CustomIconWidget(
                iconName: 'cloud_off',
                color: Colors.orange,
                size: 6.w,
              ),
            ),
          PopupMenuButton<String>(
            onSelected: (value) {
              switch (value) {
                case 'privacy':
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                        content: Text('Privacy settings will be implemented')),
                  );
                  break;
                case 'logout':
                  _showLogoutDialog();
                  break;
              }
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                value: 'privacy',
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'privacy_tip',
                      color: AppTheme.lightTheme.primaryColor,
                      size: 5.w,
                    ),
                    SizedBox(width: 3.w),
                    Text('Privacy Controls'),
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'logout',
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'logout',
                      color: Colors.red,
                      size: 5.w,
                    ),
                    SizedBox(width: 3.w),
                    Text('Logout', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: _isLoading
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 2.h),
                  Text('Loading profile data...'),
                ],
              ),
            )
          : RefreshIndicator(
              onRefresh: _refreshProfile,
              child: SingleChildScrollView(
                physics: AlwaysScrollableScrollPhysics(),
                child: Column(
                  children: [
                    ProfileHeaderWidget(
                      studentData: _studentData,
                      onPhotoTap: _showPhotoOptions,
                    ),
                    SizedBox(height: 2.h),
                    if (_isOfflineMode)
                      Container(
                        margin: EdgeInsets.symmetric(horizontal: 4.w),
                        padding: EdgeInsets.all(3.w),
                        decoration: BoxDecoration(
                          color: Colors.orange.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.orange),
                        ),
                        child: Row(
                          children: [
                            CustomIconWidget(
                              iconName: 'info',
                              color: Colors.orange,
                              size: 5.w,
                            ),
                            SizedBox(width: 3.w),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Offline Mode',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      color: Colors.orange[800],
                                    ),
                                  ),
                                  Text(
                                    'Showing cached data. Last updated: ${_studentData['lastUpdated']}',
                                    style: TextStyle(
                                      fontSize: 12.sp,
                                      color: Colors.orange[700],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    SizedBox(height: 2.h),
                    QuickActionsWidget(
                      onDownloadIdCard: _downloadIdCard,
                      onDownloadTranscript: _downloadTranscript,
                      onDownloadFeeReceipt: _downloadFeeReceipt,
                    ),
                    ProfileInfoCardWidget(
                      title: 'Personal Details',
                      fields: _getPersonalDetailsFields(),
                      isExpandable: true,
                    ),
                    ProfileInfoCardWidget(
                      title: 'Contact Information',
                      fields: _getContactInfoFields(),
                      isExpandable: true,
                    ),
                    ProfileInfoCardWidget(
                      title: 'Academic Details',
                      fields: _getAcademicDetailsFields(),
                      isExpandable: true,
                    ),
                    ProfileInfoCardWidget(
                      title: 'Emergency Contacts',
                      fields: _getEmergencyContactsFields(),
                      isExpandable: true,
                    ),
                    SizedBox(height: 4.h),
                  ],
                ),
              ),
            ),
    );
  }
}
