import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ProfileInfoCardWidget extends StatefulWidget {
  final String title;
  final List<Map<String, dynamic>> fields;
  final bool isExpandable;

  const ProfileInfoCardWidget({
    Key? key,
    required this.title,
    required this.fields,
    this.isExpandable = false,
  }) : super(key: key);

  @override
  State<ProfileInfoCardWidget> createState() => _ProfileInfoCardWidgetState();
}

class _ProfileInfoCardWidgetState extends State<ProfileInfoCardWidget>
    with SingleTickerProviderStateMixin {
  bool _isExpanded = true;
  late AnimationController _animationController;
  late Animation<double> _expandAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );
    _expandAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    if (_isExpanded) {
      _animationController.forward();
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _toggleExpansion() {
    setState(() {
      _isExpanded = !_isExpanded;
      if (_isExpanded) {
        _animationController.forward();
      } else {
        _animationController.reverse();
      }
    });
  }

  void _showContextMenu(BuildContext context, String value) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        margin: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.cardColor,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              margin: EdgeInsets.only(top: 2.h),
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 2.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'copy',
                color: AppTheme.lightTheme.primaryColor,
                size: 6.w,
              ),
              title: Text('Copy'),
              onTap: () {
                Clipboard.setData(ClipboardData(text: value));
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Copied to clipboard')),
                );
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'share',
                color: AppTheme.lightTheme.primaryColor,
                size: 6.w,
              ),
              title: Text('Share'),
              onTap: () {
                Navigator.pop(context);
                // Share functionality would be implemented here
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          InkWell(
            onTap: widget.isExpandable ? _toggleExpansion : null,
            borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
                borderRadius: widget.isExpandable
                    ? BorderRadius.vertical(top: Radius.circular(12))
                    : BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: _getIconForTitle(widget.title),
                    color: AppTheme.lightTheme.primaryColor,
                    size: 6.w,
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Text(
                      widget.title,
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: AppTheme.lightTheme.primaryColor,
                      ),
                    ),
                  ),
                  if (widget.isExpandable)
                    AnimatedRotation(
                      turns: _isExpanded ? 0.5 : 0,
                      duration: Duration(milliseconds: 300),
                      child: CustomIconWidget(
                        iconName: 'keyboard_arrow_down',
                        color: AppTheme.lightTheme.primaryColor,
                        size: 6.w,
                      ),
                    ),
                ],
              ),
            ),
          ),
          if (widget.isExpandable)
            SizeTransition(
              sizeFactor: _expandAnimation,
              child: _buildFieldsList(),
            )
          else
            _buildFieldsList(),
        ],
      ),
    );
  }

  Widget _buildFieldsList() {
    return Container(
      padding: EdgeInsets.all(4.w),
      child: Column(
        children: widget.fields.map((field) {
          return GestureDetector(
            onLongPress: () =>
                _showContextMenu(context, field['value'] as String),
            child: Container(
              margin: EdgeInsets.only(bottom: 3.h),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    flex: 2,
                    child: Text(
                      field['label'] as String,
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: Colors.grey[600],
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  SizedBox(width: 4.w),
                  Expanded(
                    flex: 3,
                    child: Text(
                      field['value'] as String,
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  if (field['editable'] == true)
                    GestureDetector(
                      onTap: () => _showEditDialog(context, field),
                      child: CustomIconWidget(
                        iconName: 'edit',
                        color: AppTheme.lightTheme.primaryColor,
                        size: 5.w,
                      ),
                    ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  void _showEditDialog(BuildContext context, Map<String, dynamic> field) {
    final TextEditingController controller = TextEditingController(
      text: field['value'] as String,
    );

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit ${field['label']}'),
        content: TextField(
          controller: controller,
          decoration: InputDecoration(
            labelText: field['label'] as String,
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              // Update functionality would be implemented here
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('${field['label']} updated')),
              );
            },
            child: Text('Save'),
          ),
        ],
      ),
    );
  }

  String _getIconForTitle(String title) {
    switch (title.toLowerCase()) {
      case 'personal details':
        return 'person';
      case 'contact information':
        return 'contact_phone';
      case 'academic details':
        return 'school';
      case 'emergency contacts':
        return 'emergency';
      default:
        return 'info';
    }
  }
}
