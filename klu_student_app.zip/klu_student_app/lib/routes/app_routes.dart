import 'package:flutter/material.dart';
import '../presentation/attendance_tracker/attendance_tracker.dart';
import '../presentation/student_profile/student_profile.dart';
import '../presentation/about_settings/about_settings.dart';
import '../presentation/grades_marks/grades_marks.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/dashboard/dashboard.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String attendanceTracker = '/attendance-tracker';
  static const String studentProfile = '/student-profile';
  static const String aboutSettings = '/about-settings';
  static const String gradesMarks = '/grades-marks';
  static const String login = '/login-screen';
  static const String dashboard = '/dashboard';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const LoginScreen(),
    attendanceTracker: (context) => const AttendanceTracker(),
    studentProfile: (context) => const StudentProfile(),
    aboutSettings: (context) => const AboutSettings(),
    gradesMarks: (context) => const GradesMarks(),
    login: (context) => const LoginScreen(),
    dashboard: (context) => const Dashboard(),
    // TODO: Add your other routes here
  };
}
