import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:dio_cookie_manager/dio_cookie_manager.dart';
import 'package:cookie_jar/cookie_jar.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:html/parser.dart' show parse;
import 'package:html/dom.dart' as dom;

enum LoginEndpoint { primary, fallback }

class AuthenticationResult {
  final bool success;
  final String? error;
  final StudentData? studentData;
  final String? sessionToken;

  AuthenticationResult({
    required this.success,
    this.error,
    this.studentData,
    this.sessionToken,
  });
}

class StudentData {
  final String name;
  final String studentId;
  final String email;
  final String? profileImageUrl;
  final String? semester;
  final String? branch;

  StudentData({
    required this.name,
    required this.studentId,
    required this.email,
    this.profileImageUrl,
    this.semester,
    this.branch,
  });

  Map<String, dynamic> toJson() => {
    'name': name,
    'studentId': studentId,
    'email': email,
    'profileImageUrl': profileImageUrl,
    'semester': semester,
    'branch': branch,
  };

  factory StudentData.fromJson(Map<String, dynamic> json) => StudentData(
    name: json['name'] ?? '',
    studentId: json['studentId'] ?? '',
    email: json['email'] ?? '',
    profileImageUrl: json['profileImageUrl'],
    semester: json['semester'],
    branch: json['branch'],
  );
}

class KLUAuthService {
  static final KLUAuthService _instance = KLUAuthService._internal();
  factory KLUAuthService() => _instance;
  KLUAuthService._internal();

  static const String _primaryBaseUrl = 'https://sis.kalasalingam.ac.in';
  static const String _fallbackBaseUrl = 'https://student.kalasalingam.ac.in';
  static const FlutterSecureStorage _secureStorage = FlutterSecureStorage(
    aOptions: AndroidOptions(
      encryptedSharedPreferences: true,
    ),
    iOptions: IOSOptions(
      accessibility: KeychainAccessibility.first_unlock_this_device,
    ),
  );

  late final Dio _dio;
  late final CookieJar _cookieJar;
  String? _currentBaseUrl;
  String? _csrfToken;
  StudentData? _currentStudent;

  Future<void> initialize() async {
    _cookieJar = CookieJar();
    _dio = Dio();
    
    // Add cookie manager
    _dio.interceptors.add(CookieManager(_cookieJar));
    
    // Configure Dio
    _dio.options.connectTimeout = const Duration(seconds: 10);
    _dio.options.receiveTimeout = const Duration(seconds: 10);
    _dio.options.headers['User-Agent'] = 'KLU Student App/1.0.0';
    
    // Add response interceptor for debugging
    _dio.interceptors.add(InterceptorsWrapper(
      onResponse: (response, handler) {
        print('Response [${response.statusCode}]: ${response.requestOptions.uri}');
        handler.next(response);
      },
      onError: (error, handler) {
        print('Error [${error.response?.statusCode}]: ${error.requestOptions.uri}');
        print('Error message: ${error.message}');
        handler.next(error);
      },
    ));
  }

  Future<AuthenticationResult> login({
    required String username,
    required String password,
    LoginEndpoint endpoint = LoginEndpoint.primary,
    bool autoFallback = true,
  }) async {
    try {
      await initialize();
      
      // Try primary endpoint first
      String baseUrl = endpoint == LoginEndpoint.primary ? _primaryBaseUrl : _fallbackBaseUrl;
      
      AuthenticationResult result = await _attemptLogin(baseUrl, username, password);
      
      // If primary fails and auto-fallback is enabled, try fallback
      if (!result.success && autoFallback && endpoint == LoginEndpoint.primary) {
        print('Primary login failed, attempting fallback...');
        result = await _attemptLogin(_fallbackBaseUrl, username, password);
      }
      
      // Save credentials if login successful
      if (result.success && result.studentData != null) {
        await _saveSecureCredentials(username, password, result.studentData!);
        _currentStudent = result.studentData;
      }
      
      return result;
    } catch (e) {
      print('Login error: $e');
      return AuthenticationResult(
        success: false,
        error: 'Network error: ${e.toString()}',
      );
    }
  }

  Future<AuthenticationResult> _attemptLogin(String baseUrl, String username, String password) async {
    try {
      _currentBaseUrl = baseUrl;
      
      // Step 1: Get login page to extract CSRF token
      final loginPageResponse = await _dio.get('$baseUrl/login');
      
      if (loginPageResponse.statusCode != 200) {
        return AuthenticationResult(
          success: false,
          error: 'Failed to load login page',
        );
      }
      
      // Step 2: Parse HTML to extract CSRF token
      final document = parse(loginPageResponse.data);
      _csrfToken = _extractCSRFToken(document);
      
      if (_csrfToken == null) {
        return AuthenticationResult(
          success: false,
          error: 'Could not extract CSRF token',
        );
      }
      
      print('CSRF Token extracted: $_csrfToken');
      
      // Step 3: Prepare login data
      final loginData = FormData.fromMap({
        'username': username.trim(),
        'password': password,
        '_token': _csrfToken,
        'login': 'Login', // Some forms require this
      });
      
      // Step 4: Submit login
      final loginResponse = await _dio.post(
        '$baseUrl/login',
        data: loginData,
        options: Options(
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Referer': '$baseUrl/login',
            'X-CSRF-TOKEN': _csrfToken,
          },
          followRedirects: false,
          validateStatus: (status) => status != null && status < 400,
        ),
      );
      
      // Step 5: Check if login was successful
      if (loginResponse.statusCode == 302 || loginResponse.statusCode == 200) {
        // Check if we're redirected to dashboard or still on login page
        final location = loginResponse.headers['location']?.first;
        
        if (location != null && !location.contains('/login')) {
          // Successful login - fetch student data
          final studentData = await _fetchStudentData();
          
          if (studentData != null) {
            return AuthenticationResult(
              success: true,
              studentData: studentData,
              sessionToken: _extractSessionToken(),
            );
          }
        }
      }
      
      // If we reach here, login failed - check for error message
      final errorMessage = await _extractLoginError(loginResponse);
      
      return AuthenticationResult(
        success: false,
        error: errorMessage ?? 'Invalid credentials',
      );
      
    } catch (e) {
      print('Login attempt error: $e');
      return AuthenticationResult(
        success: false,
        error: 'Connection error: ${e.toString()}',
      );
    }
  }

  String? _extractCSRFToken(dom.Document document) {
    // Try multiple methods to extract CSRF token
    
    // Method 1: Look for hidden input with name="_token"
    final tokenInput = document.querySelector('input[name="_token"]');
    if (tokenInput != null) {
      return tokenInput.attributes['value'];
    }
    
    // Method 2: Look for meta tag with name="csrf-token"
    final csrfMeta = document.querySelector('meta[name="csrf-token"]');
    if (csrfMeta != null) {
      return csrfMeta.attributes['content'];
    }
    
    // Method 3: Look for meta tag with name="_token"
    final tokenMeta = document.querySelector('meta[name="_token"]');
    if (tokenMeta != null) {
      return tokenMeta.attributes['content'];
    }
    
    // Method 4: Look in script tags for token
    final scripts = document.querySelectorAll('script');
    for (final script in scripts) {
      final content = script.text;
      
      // Look for various token patterns
      final patterns = [
        RegExp(r'_token["\']?\s*[:=]\s*["\']([^"\']+)["\']'),
        RegExp(r'csrf_token["\']?\s*[:=]\s*["\']([^"\']+)["\']'),
        RegExp(r'window\.Laravel\.csrfToken\s*=\s*["\']([^"\']+)["\']'),
      ];
      
      for (final pattern in patterns) {
        final match = pattern.firstMatch(content);
        if (match != null && match.group(1) != null) {
          return match.group(1);
        }
      }
    }
    
    return null;
  }

  String? _extractSessionToken() {
    // Extract session token from cookies if available
    return null; // Will be handled by cookie manager
  }

  Future<String?> _extractLoginError(Response response) async {
    try {
      if (response.data is String) {
        final document = parse(response.data);
        
        // Look for common error message selectors
        final errorSelectors = [
          '.alert-danger',
          '.error',
          '.login-error',
          '[class*="error"]',
          '.invalid-feedback',
        ];
        
        for (final selector in errorSelectors) {
          final errorElement = document.querySelector(selector);
          if (errorElement != null) {
            final errorText = errorElement.text.trim();
            if (errorText.isNotEmpty) {
              return errorText;
            }
          }
        }
      }
    } catch (e) {
      print('Error extracting login error: $e');
    }
    
    return null;
  }

  Future<StudentData?> _fetchStudentData() async {
    try {
      // Try to fetch dashboard or profile page
      final dashboardPaths = ['/dashboard', '/student-dashboard', '/home', '/profile'];
      
      for (final path in dashboardPaths) {
        try {
          final response = await _dio.get('$_currentBaseUrl$path');
          
          if (response.statusCode == 200) {
            final studentData = _parseStudentDataFromHTML(response.data);
            if (studentData != null) {
              return studentData;
            }
          }
        } catch (e) {
          print('Failed to fetch $path: $e');
          continue;
        }
      }
      
      return null;
    } catch (e) {
      print('Error fetching student data: $e');
      return null;
    }
  }

  StudentData? _parseStudentDataFromHTML(String html) {
    try {
      final document = parse(html);
      
      // Extract student information using common selectors
      String name = '';
      String studentId = '';
      String email = '';
      String? profileImageUrl;
      String? semester;
      String? branch;
      
      // Try to find student name
      final nameSelectors = [
        '.student-name',
        '.user-name',
        '[class*="name"]',
        'h1, h2, h3',
      ];
      
      for (final selector in nameSelectors) {
        final element = document.querySelector(selector);
        if (element != null) {
          final text = element.text.trim();
          if (text.isNotEmpty && !text.toLowerCase().contains('welcome')) {
            name = text;
            break;
          }
        }
      }
      
      // Try to find student ID
      final idSelectors = [
        '.student-id',
        '.user-id',
        '[class*="id"]',
      ];
      
      for (final selector in idSelectors) {
        final element = document.querySelector(selector);
        if (element != null) {
          final text = element.text.trim();
          final idMatch = RegExp(r'\b\d{11}\b').firstMatch(text);
          if (idMatch != null) {
            studentId = idMatch.group(0)!;
            break;
          }
        }
      }
      
      // Try to find email
      final emailMatch = RegExp(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b').firstMatch(html);
      if (emailMatch != null) {
        email = emailMatch.group(0)!;
      }
      
      // If we couldn't extract basic info, use fallback
      if (name.isEmpty) {
        name = 'KLU Student';
      }
      
      if (studentId.isEmpty) {
        // Generate a temporary ID based on current timestamp
        studentId = DateTime.now().millisecondsSinceEpoch.toString();
      }
      
      if (email.isEmpty) {
        email = '$studentId@klu.ac.in';
      }
      
      return StudentData(
        name: name,
        studentId: studentId,
        email: email,
        profileImageUrl: profileImageUrl,
        semester: semester,
        branch: branch,
      );
      
    } catch (e) {
      print('Error parsing student data: $e');
      return null;
    }
  }

  Future<void> _saveSecureCredentials(String username, String password, StudentData studentData) async {
    try {
      await _secureStorage.write(key: 'username', value: username);
      await _secureStorage.write(key: 'password', value: password);
      await _secureStorage.write(key: 'student_data', value: jsonEncode(studentData.toJson()));
      await _secureStorage.write(key: 'last_login', value: DateTime.now().toIso8601String());
    } catch (e) {
      print('Error saving credentials: $e');
    }
  }

  Future<StudentData?> getSavedStudentData() async {
    try {
      final studentDataJson = await _secureStorage.read(key: 'student_data');
      if (studentDataJson != null) {
        return StudentData.fromJson(jsonDecode(studentDataJson));
      }
    } catch (e) {
      print('Error reading saved student data: $e');
    }
    return null;
  }

  Future<Map<String, String>?> getSavedCredentials() async {
    try {
      final username = await _secureStorage.read(key: 'username');
      final password = await _secureStorage.read(key: 'password');
      
      if (username != null && password != null) {
        return {
          'username': username,
          'password': password,
        };
      }
    } catch (e) {
      print('Error reading saved credentials: $e');
    }
    return null;
  }

  Future<bool> isLoggedIn() async {
    final studentData = await getSavedStudentData();
    return studentData != null;
  }

  Future<void> logout() async {
    try {
      // Clear cookies
      await _cookieJar.deleteAll();
      
      // Clear secure storage
      await _secureStorage.deleteAll();
      
      // Reset current data
      _currentStudent = null;
      _csrfToken = null;
      _currentBaseUrl = null;
      
    } catch (e) {
      print('Error during logout: $e');
    }
  }

  StudentData? get currentStudent => _currentStudent;
  
  Future<AuthenticationResult> autoLogin() async {
    try {
      final credentials = await getSavedCredentials();
      if (credentials != null) {
        return await login(
          username: credentials['username']!,
          password: credentials['password']!,
        );
      }
    } catch (e) {
      print('Auto login error: $e');
    }
    
    return AuthenticationResult(
      success: false,
      error: 'No saved credentials',
    );
  }

  // Test connectivity to both endpoints
  Future<Map<String, bool>> testEndpointsConnectivity() async {
    final results = <String, bool>{};
    
    for (final endpoint in [_primaryBaseUrl, _fallbackBaseUrl]) {
      try {
        final response = await _dio.get(endpoint, options: Options(
          receiveTimeout: const Duration(seconds: 5),
        ));
        results[endpoint] = response.statusCode == 200;
      } catch (e) {
        results[endpoint] = false;
      }
    }
    
    return results;
  }
}